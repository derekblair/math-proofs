import EdgeMasks

namespace IU.Eliminate

def PaintTree.fastGood (n p q : Nat) : PaintTree → Prop
  | .leaf c => c.Pairwise (fun a b => edgeFast n p q a b = false)
  | .fork _ l r => l.fastGood n p q ∧ r.fastGood n p q

def PaintTree.fastGoodDec (n p q : Nat) : (t : PaintTree) → Decidable (t.fastGood n p q)
  | .leaf c => by unfold PaintTree.fastGood; infer_instance
  | .fork _ l r => by
    unfold PaintTree.fastGood
    letI := l.fastGoodDec n p q
    letI := r.fastGoodDec n p q
    infer_instance

instance (t : PaintTree) (n p q : Nat) : Decidable (t.fastGood n p q) :=
  t.fastGoodDec n p q

theorem PaintTree.fast_sound (t : PaintTree) (n p q : Nat)
    (H : t.fastGood n p q) : t.good n p q := by
  induction t with
  | leaf c =>
    change c.Pairwise (fun a b => edgeFast n p q a b=false) at H
    change c.Pairwise (fun a b => edge n p q a b=false)
    simpa [edge_fast] using H
  | fork s l r hl hr =>
    exact ⟨hl H.1,hr H.2⟩

end IU.Eliminate
