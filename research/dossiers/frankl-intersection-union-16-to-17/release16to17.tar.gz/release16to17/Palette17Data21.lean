import Palette17Data20

namespace IU.IU17
open IU.Eliminate
set_option maxRecDepth 18000
set_option maxHeartbeats 0
def p17194_17330 : PaintTree := .fork 68 p17194_17262 p17262_17330
def p17330_17467 : PaintTree := .fork 68 p17330_17398 p17398_17467
def p16921_17194 : PaintTree := .fork 136 p16921_17057 p17057_17194
def p17194_17467 : PaintTree := .fork 136 p17194_17330 p17330_17467
def p16375_16921 : PaintTree := .fork 273 p16375_16648 p16648_16921
def p16921_17467 : PaintTree := .fork 273 p16921_17194 p17194_17467
def p15283_16375 : PaintTree := .fork 546 p15283_15829 p15829_16375
def p16375_17467 : PaintTree := .fork 546 p16375_16921 p16921_17467
def p13100_15283 : PaintTree := .fork 1091 p13100_14191 p14191_15283
def p15283_17467 : PaintTree := .fork 1092 p15283_16375 p16375_17467
def p8733_13100 : PaintTree := .fork 2183 p8733_10916 p10916_13100
def p13100_17467 : PaintTree := .fork 2183 p13100_15283 p15283_17467
def p0_8733 : PaintTree := .fork 4366 p0_4366 p4366_8733
def p8733_17467 : PaintTree := .fork 4367 p8733_13100 p13100_17467
def root : PaintTree := .fork 8733 p0_8733 p8733_17467
end IU.IU17
