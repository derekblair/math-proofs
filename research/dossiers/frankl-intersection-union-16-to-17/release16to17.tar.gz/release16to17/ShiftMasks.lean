import StrictRows

namespace IU.Eliminate

def notMaskFast (n m : Nat) : Nat := ((1 <<< (1 <<< n))-1) ^^^ m

theorem shift_one (n : Nat) : (1 : Nat) <<< n = 2^n := by
  rw [Nat.shiftLeft_eq,Nat.one_mul]

theorem not_mask_fast_eq (n m : Nat) : notMaskFast n m=notMask n m := by
  simp only [notMaskFast,notMask,shift_one]

end IU.Eliminate
namespace IU.Eliminate

def prune (A B : Nat) : Nat := A ^^^ (A &&& B)

theorem row_of_removed_masks {T : Nat→Nat→Nat} {colors : Fin k → List Nat}
    {n p q m : Nat} {row : Row k} {stamp : Nat→Nat} {prev : Nat}
    (T_ok : ∀ w≤n, ∀ j≤w, T w j=pmask w j)
    (within : ∀ i∈row.miss, ∀ b∈colors i, b<2^n)
    (distinct : row.miss.Nodup) (count : k - row.miss.length < m)
    (prev_ok : ∀ b<2^n, prev.testBit b = decide (stamp b < stamp row.a))
    (eq : prune (missMask colors row &&& edgeMask T n p q row.a)
      (prev ||| (1 <<< row.a))=0) :
    rowOk n p q m colors stamp row := by
  refine ⟨distinct,count,?_⟩
  intro i im b bm
  by_cases ns : b=row.a
  · exact Or.inl ns
  by_cases earlier : stamp b<stamp row.a
  · exact Or.inr (Or.inl earlier)
  apply Or.inr
  apply Or.inr
  apply Bool.eq_false_iff.mpr
  intro E
  have L : (missMask colors row).testBit b=true :=
    (any_mask _ _).mpr ⟨packed (colors i),
      List.mem_map.mpr ⟨colors i,List.mem_map.mpr ⟨i,im,rfl⟩,rfl⟩,
      (packed_mem _ _).mpr bm⟩
  have bl := within i im b bm
  have R : (edgeMask T n p q row.a).testBit b=true := by
    rw [edge_mask_bit T_ok]
    exact decide_eq_true ⟨bl,E⟩
  have N : (prev ||| (1 <<< row.a)).testBit b=false := by
    rw [Nat.testBit_or,prev_ok b bl,shift_one,Nat.testBit_two_pow]
    simp [earlier,Ne.symm ns]
  have bad := congrArg (fun u => u.testBit b) eq
  simp [prune,L,R,N] at bad

#print axioms row_of_removed_masks
end IU.Eliminate
