import RunEnd

namespace IU.Eliminate

theorem anyMask_append (A B : List Nat) : anyMask (A++B)=anyMask A ||| anyMask B := by
  induction A with
  | nil => simp [anyMask]
  | cons a A ih => simp [anyMask,ih,Nat.or_assoc]

theorem chunks_mask {k : Nat} (colors : Fin k→List Nat) (parts : List (List (Fin k))) (u : Nat) :
    missMask colors ⟨u,parts.flatten⟩ =
      anyMask (parts.map (fun part=>anyMask ((part.map colors).map packed))) := by
  induction parts with
  | nil => rfl
  | cons part parts ih =>
    simp only [missMask,List.flatten_cons,List.map_append,anyMask_append,List.map_cons,anyMask]
    exact congrArg (fun x => anyMask ((part.map colors).map packed) ||| x) ih

end IU.Eliminate
