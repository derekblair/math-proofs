import Palette17Cert63
import WeightData17

namespace IU.IU17
open IU.Eliminate
set_option maxRecDepth 18000
set_option maxHeartbeats 0
def colors (i : Fin 17467) : List Nat := root.lookup i.val
theorem mask_exact : vertexMask IU.IUW17.tab 17 2 2 = rootMaskLit := by decide +kernel
theorem color_bound {i : Fin 17467} {a : Nat} (h : a∈colors i) : a<2^17 := by
  have z := root.lookup_mask h
  rw [rootMaskEq, ←mask_exact, vertex_mask_bit IU.IUW17.tab_ok] at z
  exact (of_decide_eq_true z).1
theorem paint_cover {a : Nat} (v : a∈admissible 17 2 2) : root.mask.testBit a=true := by
  have z := vertex_mask_bit (T:=IU.IUW17.tab) (n:=17) (p:=2) (q:=2) (a:=a) IU.IUW17.tab_ok
  rw [mask_exact,←rootMaskEq] at z
  obtain ⟨l,h⟩ := List.mem_filter.mp v
  rw [z]
  exact decide_eq_true ⟨List.mem_range.mp l,h⟩
end IU.IU17
