import MaskChunks
import Mathlib.Data.List.Chain

namespace IU.Eliminate

def strictColors {k : Nat} : List (Fin k) → Bool
  | a::b::L => decide (a<b) && strictColors (b::L)
  | _ => true

theorem strict_chain {k : Nat} :
    ∀ {L : List (Fin k)}, strictColors L=true → List.IsChain (· < ·) L
  | [], _ => List.isChain_nil
  | [a], _ => List.isChain_singleton _
  | a::b::L, h => by
    have Q := Bool.and_eq_true_iff.mp h
    exact List.isChain_cons_cons.mpr ⟨of_decide_eq_true Q.1,strict_chain Q.2⟩

theorem strict_nodup {k : Nat} {L : List (Fin k)} (h : strictColors L=true) : L.Nodup := by
  have chain := strict_chain h
  rw [List.isChain_iff_pairwise] at chain
  exact chain.imp ne_of_lt

end IU.Eliminate
