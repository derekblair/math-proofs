import EdgeMasks
import EliminateStages

namespace IU.Eliminate

def notMask (n m : Nat) : Nat := (2^(2^n)-1) ^^^ m

theorem not_mask_bit {n m b : Nat} (h : b<2^n) :
    (notMask n m).testBit b = !(m.testBit b) := by
  simp [notMask,Nat.testBit_xor,h]

def allMask (n : Nat) : List Nat → Nat
  | [] => 2^(2^n)-1
  | m::L => m &&& allMask n L

theorem all_mask {n b : Nat} (h : b<2^n) (L : List Nat) :
    (allMask n L).testBit b=true ↔ ∀ m∈L, m.testBit b=true := by
  induction L with
  | nil => simp [allMask,h]
  | cons m L ih =>
    simp only [allMask,Nat.testBit_and,Bool.and_eq_true,ih,List.mem_cons]
    constructor
    · rintro ⟨H,G⟩ u (rfl|mem)
      · exact H
      · exact G u mem
    · intro F
      exact ⟨F m (Or.inl rfl),fun b B => F b (Or.inr B)⟩

def domMask (T : Nat→Nat→Nat) (n a : Nat) : Nat :=
  (T n (rank a n)) &&& allMask n ((List.range (n+1)).map (fun t =>
    notMask n (atLeastPrefix T n t (rank a t + 1))))

theorem dom_mask_bit {T : Nat→Nat→Nat} {n a b : Nat}
    (T_ok : ∀ w≤n, ∀ k≤w, T w k = pmask w k) (h : b<2^n) :
    (domMask T n a).testBit b = decide (Dominates n a b) := by
  apply Bool.eq_iff_iff.mpr
  rw [decide_eq_true_eq,domMask,Nat.testBit_and,Bool.and_eq_true,T_ok _ le_rfl _ (rank_le_length a n),pmask_bit,
    decide_eq_true_eq,all_mask h]
  constructor
  · rintro ⟨⟨_,eq⟩,masks⟩
    refine ⟨eq,?_⟩
    intro t ht
    have tn : t≤n := by have := List.mem_range.mp ht; omega
    have v := masks _ (List.mem_map.mpr ⟨t,ht,rfl⟩)
    rw [not_mask_bit h,prefix_mask_bits tn (T_ok t tn)] at v
    have V : rank b t < rank a t + 1 := by simpa [h] using v
    omega
  · rintro ⟨eq,gr⟩
    refine ⟨⟨h,eq⟩,?_⟩
    intro u um
    obtain ⟨t,ht,rfl⟩ := List.mem_map.mp um
    have tn : t≤n := by have := List.mem_range.mp ht; omega
    rw [not_mask_bit h,prefix_mask_bits tn (T_ok t tn)]
    have g := gr t ht
    simp [h,show ¬rank a t+1≤rank b t by omega]

theorem findIdx_le_of_member {p : Nat→Bool} {n s : Nat}
    (h : s<n) (hs : p s = true) : (List.range n).findIdx p≤s := by
  by_contra H
  have F := List.not_of_lt_findIdx (p:=p) (xs:=List.range n) (i:=s) (by omega)
  simpa [hs] using F

def earlierMask {k : Nat} (T : Nat → Nat → Nat) (n s : Nat)
    (bank : Nat → Nat → List (Row k)) : Nat :=
  anyMask ((((List.range s).flatMap fun i =>
    (List.range (n+1)).flatMap (bank i))).map fun row => domMask T n row.a)

theorem earlier_mask_bit {k n s steps a : Nat}
    {T : Nat→Nat→Nat} {bank : Nat→Nat→List (Row k)}
    (le : s≤steps) (T_ok : ∀ w≤n, ∀ j≤w, T w j = pmask w j)
    (well : ∀ j<steps, ∀ w≤n, ∀ r∈bank j w, rank r.a n=w)
    (aN : a<2^n) :
    (earlierMask T n s bank).testBit a=decide (outsideStage n steps bank a<s) := by
  apply Bool.eq_iff_iff.mpr
  rw [decide_eq_true_eq,earlierMask,any_mask]
  constructor
  · rintro ⟨m,hm,hb⟩
    obtain ⟨r,rm,rfl⟩ := List.mem_map.mp hm
    obtain ⟨i,im,rm⟩ := List.mem_flatMap.mp rm
    obtain ⟨w,wm,rm⟩ := List.mem_flatMap.mp rm
    have il := List.mem_range.mp im
    have wl : w≤n := by have := List.mem_range.mp wm; omega
    have ww := well i (by omega) w wl r rm
    rw [dom_mask_bit T_ok aN,decide_eq_true_eq] at hb
    have M := findIdx_le_of_member (p:=fun j => contained n (bank j (rank a n)) a)
      (show i<steps by omega) (decide_eq_true ⟨r,(hb.1.trans ww).symm ▸ rm,hb⟩)
    unfold outsideStage
    omega
  · intro h
    obtain ⟨r,rm,H⟩ := at_stage (lt_of_lt_of_le h le)
    refine ⟨domMask T n r.a,List.mem_map.mpr ⟨r,?_ ,rfl⟩,?_⟩
    · apply List.mem_flatMap.mpr
      refine ⟨outsideStage n steps bank a,List.mem_range.mpr h,List.mem_flatMap.mpr ?_⟩
      exact ⟨rank a n,List.mem_range.mpr (by have := rank_le_length a n; omega),rm⟩
    · rw [dom_mask_bit T_ok aN]
      exact decide_eq_true H

/-- A covered label is safe whenever the AND of its color-neighbor masks,
    with earlier stages pruned, is supported only at the distinctness-exempt
    center. This avoids checking each omitted label separately. -/
theorem row_of_pruned_masks {T : Nat→Nat→Nat} {colors : Fin k → List Nat}
    {n p q m : Nat} {row : Row k} {stamp : Nat→Nat} {prev : Nat}
    (T_ok : ∀ w≤n, ∀ j≤w, T w j=pmask w j)
    (within : ∀ i∈row.miss, ∀ b∈colors i, b<2^n)
    (distinct : row.miss.Nodup) (count : k - row.miss.length < m)
    (prev_ok : ∀ b<2^n, prev.testBit b = decide (stamp b < stamp row.a))
    (eq : missMask colors row &&& edgeMask T n p q row.a &&& notMask n prev =
      (if (missMask colors row).testBit row.a then 2^row.a else 0)) :
    rowOk n p q m colors stamp row := by
  refine ⟨distinct,count,?_⟩
  intro i im b bm
  by_cases ns : b=row.a
  · exact Or.inl ns
  by_cases earlier : stamp b<stamp row.a
  · exact Or.inr (Or.inl earlier)
  apply Or.inr
  apply Or.inr
  apply Bool.eq_false_iff.mpr
  intro E
  have L : (missMask colors row).testBit b=true :=
    (any_mask _ _).mpr ⟨packed (colors i),
      List.mem_map.mpr ⟨colors i,List.mem_map.mpr ⟨i,im,rfl⟩,rfl⟩,
      (packed_mem _ _).mpr bm⟩
  have bl := within i im b bm
  have R : (edgeMask T n p q row.a).testBit b=true := by
    rw [edge_mask_bit T_ok]
    exact decide_eq_true ⟨bl,E⟩
  have NE : (notMask n prev).testBit b=true := by
    rw [not_mask_bit bl,prev_ok b bl]
    simp [earlier]
  have bad := congrArg (fun u => u.testBit b) eq
  simp only [Nat.testBit_and,L,R,NE,Bool.and_self] at bad
  split at bad
  · have k : (2^row.a : Nat).testBit b=false := Nat.testBit_two_pow_of_ne (by exact Ne.symm ns)
    rw [k] at bad
    contradiction
  · simp at bad

#print axioms row_of_pruned_masks
end IU.Eliminate
