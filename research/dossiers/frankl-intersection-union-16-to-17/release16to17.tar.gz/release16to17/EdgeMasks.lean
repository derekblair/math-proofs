import WeightMasks
import PaintTree

namespace IU.Eliminate

def weightEdgeMask (T : Nat → Nat → Nat) (n p q a k : Nat) : Nat :=
  T n k &&& anyMask ((List.range (n+1)).map (fun w =>
    atLeastPrefix T n w (max p (rank a n+k-(n-q)) + w - rank a w)))

def edgeMask (T : Nat → Nat → Nat) (n p q a : Nat) : Nat :=
  anyMask ((List.range (n+1)).map (weightEdgeMask T n p q a))

theorem edge_mask_bit {T : Nat→Nat→Nat} {n p q a b : Nat}
    (T_ok : ∀ w≤n, ∀ k≤w, T w k = pmask w k) :
    (edgeMask T n p q a).testBit b = decide (b<2^n ∧ edge n p q a b=true) := by
  apply Bool.eq_iff_iff.mpr
  rw [decide_eq_true_eq,edgeMask,any_mask]
  constructor
  · rintro ⟨m,hM,hB⟩
    obtain ⟨k,kw,rfl⟩ := List.mem_map.mp hM
    have kn : k≤n := by have := List.mem_range.mp kw; omega
    rw [weightEdgeMask,Nat.testBit_and,Bool.and_eq_true,T_ok n le_rfl k kn,pmask_bit,decide_eq_true_eq,any_mask] at hB
    obtain ⟨⟨bN,bK⟩,m,hm,hW⟩ := hB
    obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hm
    have wn : w≤n := by have := List.mem_range.mp hw; omega
    rw [prefix_mask_bits wn (T_ok w wn),decide_eq_true_eq] at hW
    refine ⟨bN, List.any_eq_true.mpr ⟨w,hw,?_⟩⟩
    rw [decide_eq_true_eq,bK]
    have sw := hW.2
    omega
  · rintro ⟨bN,va⟩
    let k := rank b n
    have kn : k≤n := rank_le_length b n
    refine ⟨weightEdgeMask T n p q a k,List.mem_map.mpr ⟨k,List.mem_range.mpr (by omega),rfl⟩,?_⟩
    rw [weightEdgeMask,Nat.testBit_and,Bool.and_eq_true,T_ok n le_rfl k kn,pmask_bit,decide_eq_true_eq,any_mask]
    refine ⟨⟨bN,rfl⟩,?_⟩
    obtain ⟨w,hw,ec⟩ := List.any_eq_true.mp va
    have wn : w≤n := by have := List.mem_range.mp hw; omega
    refine ⟨_,List.mem_map.mpr ⟨w,hw,rfl⟩,?_⟩
    rw [prefix_mask_bits wn (T_ok w wn),decide_eq_true_eq]
    refine ⟨bN,?_⟩
    have z := of_decide_eq_true ec
    change max p (rank a n+k-(n-q))+w≤rank a w+rank b w at z
    omega

theorem PaintTree.lookup_mask {t : PaintTree} {i b : Nat} (h : b∈t.lookup i) :
    t.mask.testBit b=true := by
  induction t generalizing i with
  | leaf c => exact (packed_mem c b).mpr h
  | fork s l r il ir =>
    change b ∈ (if i<s then l.lookup i else r.lookup (i-s)) at h
    change (l.mask ||| r.mask).testBit b=true
    rw [Nat.testBit_or,Bool.or_eq_true]
    split at h
    · exact Or.inl (il h)
    · exact Or.inr (ir h)

def missMask {k : Nat} (colors : Fin k → List Nat) (row : Row k) : Nat :=
  anyMask ((row.miss.map colors).map packed)

theorem row_of_masks {T : Nat→Nat→Nat} {colors : Fin k → List Nat} {stamp : Nat→Nat}
    {n p q m : Nat} {row : Row k} {early : List Nat}
    (T_ok : ∀ w≤n, ∀ j≤w, T w j=pmask w j)
    (within : ∀ i∈row.miss, ∀ b∈colors i, b<2^n)
    (distinct : row.miss.Nodup) (count : k - row.miss.length < m)
    (eq : missMask colors row &&& edgeMask T n p q row.a = packed early)
    (safe : ∀ b∈early, b = row.a ∨ stamp b < stamp row.a) :
    rowOk n p q m colors stamp row := by
  refine ⟨distinct,count,?_⟩
  intro i hi b hb
  cases E : edge n p q row.a b with
  | false => exact Or.inr (Or.inr rfl)
  | true =>
    have l := (any_mask _ _).mpr ⟨packed (colors i),
      List.mem_map.mpr ⟨colors i,List.mem_map.mpr ⟨i,hi,rfl⟩,rfl⟩,
      (packed_mem _ _).mpr hb⟩
    have r : (edgeMask T n p q row.a).testBit b=true := by
      rw [edge_mask_bit T_ok]
      exact decide_eq_true ⟨within i hi b hb,E⟩
    have eq' := congrArg (fun u => u.testBit b) eq
    rw [Nat.testBit_and,missMask,l,r] at eq'
    have M := (packed_mem early b).mp eq'.symm
    exact (safe b M).imp_right Or.inl

#print axioms row_of_masks
end IU.Eliminate
