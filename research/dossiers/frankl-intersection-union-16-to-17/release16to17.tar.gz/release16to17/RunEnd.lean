import DomMasks

namespace IU.Eliminate

/-- Ends of maximal runs of ones of the left operand, with zero allowed. -/
def IsRunEnd (a n i : Nat) : Prop :=
  i=0 ∨ (0<i ∧ a.testBit (i-1)=true ∧ (i=n ∨ a.testBit i=false))

instance (a n i : Nat) : Decidable (IsRunEnd a n i) := by unfold IsRunEnd; infer_instance

theorem walk_back {a b z : Nat} (i : Nat)
    (ok : z+i≤rank a i+rank b i) :
    ∃ j≤i, (j=0 ∨ (0<j ∧ a.testBit (j-1)=true)) ∧ z+j≤rank a j+rank b j := by
  induction i with
  | zero => exact ⟨0,le_rfl,Or.inl rfl,ok⟩
  | succ i ih =>
    by_cases bit : a.testBit i=true
    · exact ⟨i+1,le_rfl,Or.inr ⟨by omega,by simpa⟩,ok⟩
    have no : a.testBit i=false := Bool.eq_false_iff.mpr bit
    have h : z+i≤rank a i+rank b i := by
      rw [rank_succ',rank_succ'] at ok
      by_cases B : b.testBit i=true <;> simp [no,B] at ok <;> omega
    obtain ⟨j,ji,done,h⟩ := ih h
    exact ⟨j,by omega,done,h⟩

theorem walk_forward {a b z : Nat} (d i : Nat)
    (pos : 0<i) (before : a.testBit (i-1)=true)
    (ok : z+i≤rank a i+rank b i) :
    ∃ j≤i+d, IsRunEnd a (i+d) j ∧ z+j≤rank a j+rank b j := by
  induction d generalizing i with
  | zero => exact ⟨i,by omega,Or.inr ⟨pos,before,Or.inl (by omega)⟩,ok⟩
  | succ d ih =>
    by_cases bit : a.testBit i=true
    · have h : z+(i+1)≤rank a (i+1)+rank b (i+1) := by
        rw [rank_succ',rank_succ']
        by_cases B : b.testBit i=true <;> simp [bit,B] <;> omega
      obtain ⟨j,jn,g,H⟩ := ih (i+1) (by omega) (by simpa using bit) h
      have eq : i+1+d=i+(d+1) := by omega
      rw [eq] at g
      exact ⟨j,by omega,g,H⟩
    · exact ⟨i,by omega,Or.inr ⟨pos,before,Or.inr (Bool.eq_false_iff.mpr bit)⟩,ok⟩

theorem at_run_end {a b z n i : Nat} (ni : i≤n)
    (ok : z+i≤rank a i+rank b i) :
    ∃ j≤n, IsRunEnd a n j ∧ z+j≤rank a j+rank b j := by
  obtain ⟨t,ti,good,h⟩ := walk_back (a:=a) (b:=b) i ok
  rcases good with e | ⟨pos,before⟩
  · exact ⟨t,ti.trans ni,Or.inl e,h⟩
  · have E : t+(n-t)=n := Nat.add_sub_of_le (ti.trans ni)
    simpa [E] using walk_forward (n-t) t pos before h

def endCuts (a n : Nat) : List Nat :=
  (List.range (n+1)).filter (fun t => decide (IsRunEnd a n t))

theorem edge_run_ends (a b n p q : Nat) :
    edge n p q a b=true ↔ ∃ t∈endCuts a n,
      max p (rank a n+rank b n-(n-q))+t≤rank a t+rank b t := by
  rw [edge,List.any_eq_true]
  constructor
  · rintro ⟨i,il,hit⟩
    obtain ⟨j,jn,isj,js⟩ := at_run_end (n:=n) (a:=a) (b:=b) (by have := List.mem_range.mp il; omega) (of_decide_eq_true hit)
    exact ⟨j,List.mem_filter.mpr ⟨List.mem_range.mpr (by omega),decide_eq_true isj⟩,js⟩
  · rintro ⟨i,iL,ih⟩
    exact ⟨i,(List.mem_filter.mp iL).1,decide_eq_true ih⟩

#print axioms edge_run_ends
def weightEdgeRunMask (T : Nat → Nat → Nat) (n p q a k : Nat) : Nat :=
  T n k &&& anyMask ((endCuts a n).map (fun w =>
    atLeastPrefix T n w (max p (rank a n+k-(n-q)) + w - rank a w)))

def edgeRunMask (T : Nat → Nat → Nat) (n p q a : Nat) : Nat :=
  anyMask ((List.range (n+1)).map (weightEdgeRunMask T n p q a))

theorem edge_run_mask_bit {T : Nat→Nat→Nat} {n p q a b : Nat}
    (T_ok : ∀ w≤n, ∀ k≤w, T w k = pmask w k) :
    (edgeRunMask T n p q a).testBit b = decide (b<2^n ∧ edge n p q a b=true) := by
  apply Bool.eq_iff_iff.mpr
  rw [decide_eq_true_eq,edgeRunMask,any_mask]
  constructor
  · rintro ⟨m,hM,hB⟩
    obtain ⟨k,kw,rfl⟩ := List.mem_map.mp hM
    have kn : k≤n := by have := List.mem_range.mp kw; omega
    rw [weightEdgeRunMask,Nat.testBit_and,Bool.and_eq_true,T_ok n le_rfl k kn,pmask_bit,decide_eq_true_eq,any_mask] at hB
    obtain ⟨⟨bN,bK⟩,m,hm,hW⟩ := hB
    obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hm
    have wn : w≤n := by have := List.mem_range.mp (List.mem_filter.mp hw).1; omega
    rw [prefix_mask_bits wn (T_ok w wn),decide_eq_true_eq] at hW
    refine ⟨bN, (edge_run_ends a b n p q).mpr ⟨w,hw,?_⟩⟩
    rw [bK]
    have sw := hW.2
    omega
  · rintro ⟨bN,va⟩
    let k := rank b n
    have kn : k≤n := rank_le_length b n
    refine ⟨weightEdgeRunMask T n p q a k,List.mem_map.mpr ⟨k,List.mem_range.mpr (by omega),rfl⟩,?_⟩
    rw [weightEdgeRunMask,Nat.testBit_and,Bool.and_eq_true,T_ok n le_rfl k kn,pmask_bit,decide_eq_true_eq,any_mask]
    refine ⟨⟨bN,rfl⟩,?_⟩
    obtain ⟨w,hw,ec⟩ := (edge_run_ends a b n p q).mp va
    have wn : w≤n := by have := List.mem_range.mp (List.mem_filter.mp hw).1; omega
    refine ⟨_,List.mem_map.mpr ⟨w,hw,rfl⟩,?_⟩
    rw [prefix_mask_bits wn (T_ok w wn),decide_eq_true_eq]
    refine ⟨bN,?_⟩
    have z := ec
    change max p (rank a n+k-(n-q))+w≤rank a w+rank b w at z
    omega

theorem edge_run_mask_eq {T : Nat→Nat→Nat} {n p q a : Nat}
    (T_ok : ∀ w≤n, ∀ k≤w, T w k=pmask w k) :
    edgeRunMask T n p q a=edgeMask T n p q a := by
  apply Nat.eq_of_testBit_eq
  intro b
  rw [edge_run_mask_bit T_ok,edge_mask_bit T_ok]

#print axioms edge_run_mask_eq
end IU.Eliminate
