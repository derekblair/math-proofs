import Rows17Cert0
import Rows17Cert1
import Rows17Cert2
import Rows17Cert3
import Rows17Cert4
import Rows17Cert5
import Rows17Cert6
import Rows17Cert7
import Rows17Cert8
import Rows17Cert9
import Rows17Cert10
import Rows17Cert11
import Rows17Cert12
import Rows17Cert13
import Rows17Cert14
import Rows17Cert15
import Rows17Cert16
import Rows17Cert17
import Rows17Cert18
import Rows17Cert19
import Rows17Cert20
import Rows17Cert21
import Rows17Cert22
import Rows17Cert23
import Rows17Cert24
import Rows17Cert25
import Rows17Cert26
import Rows17Cert27
import Rows17Cert28
import Rows17Cert29
import Rows17Cert30
import Rows17Cert31
import Rows17Cert32
import Rows17Cert33
import Rows17Cert34
import Rows17Cert35
import Rows17Cert36
import Rows17Cert37
import Rows17Cert38
import Rows17Cert39
import Rows17Cert40
import Rows17Cert41
import Rows17Cert42
import Rows17Cert43
import Rows17Cert44
import Rows17Cert45

namespace IU.IU17
open IU.Eliminate
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem row_is_sound (i : I) :
    coarse (row i).a=(info i).1 ∧ rowOk 17 2 2 17298 colors coarse (row i) := by
  fin_cases i
  · exact ⟨r0Stage,ok0⟩
  · exact ⟨r1Stage,ok1⟩
  · exact ⟨r2Stage,ok2⟩
  · exact ⟨r3Stage,ok3⟩
  · exact ⟨r4Stage,ok4⟩
  · exact ⟨r5Stage,ok5⟩
  · exact ⟨r6Stage,ok6⟩
  · exact ⟨r7Stage,ok7⟩
  · exact ⟨r8Stage,ok8⟩
  · exact ⟨r9Stage,ok9⟩
  · exact ⟨r10Stage,ok10⟩
  · exact ⟨r11Stage,ok11⟩
  · exact ⟨r12Stage,ok12⟩
  · exact ⟨r13Stage,ok13⟩
  · exact ⟨r14Stage,ok14⟩
  · exact ⟨r15Stage,ok15⟩
  · exact ⟨r16Stage,ok16⟩
  · exact ⟨r17Stage,ok17⟩
  · exact ⟨r18Stage,ok18⟩
  · exact ⟨r19Stage,ok19⟩
  · exact ⟨r20Stage,ok20⟩
  · exact ⟨r21Stage,ok21⟩
  · exact ⟨r22Stage,ok22⟩
  · exact ⟨r23Stage,ok23⟩
  · exact ⟨r24Stage,ok24⟩
  · exact ⟨r25Stage,ok25⟩
  · exact ⟨r26Stage,ok26⟩
  · exact ⟨r27Stage,ok27⟩
  · exact ⟨r28Stage,ok28⟩
  · exact ⟨r29Stage,ok29⟩
  · exact ⟨r30Stage,ok30⟩
  · exact ⟨r31Stage,ok31⟩
  · exact ⟨r32Stage,ok32⟩
  · exact ⟨r33Stage,ok33⟩
  · exact ⟨r34Stage,ok34⟩
  · exact ⟨r35Stage,ok35⟩
  · exact ⟨r36Stage,ok36⟩
  · exact ⟨r37Stage,ok37⟩
  · exact ⟨r38Stage,ok38⟩
  · exact ⟨r39Stage,ok39⟩
  · exact ⟨r40Stage,ok40⟩
  · exact ⟨r41Stage,ok41⟩
  · exact ⟨r42Stage,ok42⟩
  · exact ⟨r43Stage,ok43⟩
  · exact ⟨r44Stage,ok44⟩
  · exact ⟨r45Stage,ok45⟩
theorem full_rows (s : Nat) (_ : s<3) (w : Nat) (r : Row 17467) (hr : r∈bank s w) :
    rank r.a 17=w ∧ coarse r.a=s ∧ rowOk 17 2 2 17298 colors coarse r := by
  obtain ⟨i,ii,rfl⟩ := member_bank hr
  exact ⟨well hr,by simpa [ii] using (row_is_sound i).1,(row_is_sound i).2⟩
end IU.IU17
