import EliminateDom
import Mathlib.Data.List.Basic

namespace IU.Eliminate

def contained {k : Nat} (n : Nat) (rows : List (Row k)) (a : Nat) : Bool :=
  decide (∃ r∈rows, Dominates n r.a a)

def outsideStage {k : Nat} (n steps : Nat) (bank : Nat → Nat → List (Row k)) (a : Nat) : Nat :=
  (List.range steps).findIdx (fun s => contained n (bank s (rank a n)) a)

theorem stage_le {k : Nat} {n steps : Nat} {bank : Nat → Nat → List (Row k)}
    {a : Nat} : outsideStage n steps bank a ≤ steps := by
  unfold outsideStage
  simpa using (List.findIdx_le_length (xs:=List.range steps)
    (p:=fun s => contained n (bank s (rank a n)) a))

theorem at_stage {k : Nat} {n steps : Nat} {bank : Nat → Nat → List (Row k)}
    {a : Nat} (h : outsideStage n steps bank a < steps) :
    ∃ r∈bank (outsideStage n steps bank a) (rank a n), Dominates n r.a a := by
  have z : (List.range steps).findIdx (fun s => contained n (bank s (rank a n)) a) < (List.range steps).length := by
    simpa [outsideStage] using h
  have e := List.findIdx_getElem (xs:=List.range steps)
    (p:=fun s => contained n (bank s (rank a n)) a) (w:=z)
  simpa [contained,outsideStage] using e

theorem has_stage {k : Nat} {n steps : Nat} {bank : Nat → Nat → List (Row k)}
    {a : Nat} (h : ∃ s<steps, ∃ r∈bank s (rank a n), Dominates n r.a a) :
    outsideStage n steps bank a < steps := by
  obtain ⟨s,hs,r,hr,d⟩ := h
  unfold outsideStage
  simpa using (List.findIdx_lt_length_of_exists (xs:=List.range steps)
    (p:=fun s => contained n (bank s (rank a n)) a)
    ⟨s,List.mem_range.mpr hs,decide_eq_true ⟨r,hr,d⟩⟩)

def chosen {k : Nat} (n steps : Nat) (bank : Nat → Nat → List (Row k)) (a : Nat) : Bool :=
  ((bank (outsideStage n steps bank a) (rank a n)).map Row.a).contains a

def phased {k : Nat} (n steps : Nat) (bank : Nat → Nat → List (Row k)) (a : Nat) : Nat :=
  2*outsideStage n steps bank a + if chosen n steps bank a then 0 else 1

theorem outside_stage_of_phased {k : Nat} {n steps : Nat} {bank : Nat → Nat → List (Row k)} {a : Nat}
    (h : phased n steps bank a < 2*steps) : outsideStage n steps bank a < steps := by
  unfold phased at h
  split at h <;> omega

theorem miss_of_stage {k n p q steps m : Nat}
    {colors : Fin k → List Nat} {bank : Nat → Nat → List (Row k)}
    (cert : ∀ s<steps, ∀ w, ∀ row∈bank s w,
      rank row.a n=w ∧ outsideStage n steps bank row.a=s ∧
        rowOk n p q m colors (outsideStage n steps bank) row)
    {a : Nat} (h : outsideStage n steps bank a<steps) :
    ∃ miss : Finset (Fin k), k - miss.card < m ∧
      ∀ i∈miss, ∀ b∈colors i, b≠a → phased n steps bank a≤phased n steps bank b →
        edge n p q a b=false := by
  let s := outsideStage n steps bank a
  let w := rank a n
  have existsGood : ∃ row∈bank s w, Dominates n row.a a ∧ (chosen n steps bank a=true → row.a=a) := by
    by_cases hA : chosen n steps bank a=true
    · have u : a∈(bank s w).map Row.a := List.contains_iff_mem.mp hA
      obtain ⟨r,hr,R⟩ := List.mem_map.mp u
      refine ⟨r,hr,?_,fun _=>R⟩
      rw [R]
      exact ⟨rfl,fun _ _=>le_rfl⟩
    · obtain ⟨r,hr,D⟩ := at_stage h
      exact ⟨r,hr,D,fun z => False.elim (hA z)⟩
  obtain ⟨r,rm,D,Uniq⟩ := existsGood
  obtain ⟨rs,ss,ok⟩ := cert s h w r rm
  have rchosen : chosen n steps bank r.a=true := by
    unfold chosen
    rw [rs,ss,List.contains_iff_mem]
    exact List.mem_map.mpr ⟨r,rm,rfl⟩
  apply certificate_of_dom ok D
  intro b nb le
  have st : s≤outsideStage n steps bank b := by
    unfold phased at le
    dsimp [s]
    split at le <;> (split at le <;> omega)
  refine ⟨?_,ss ▸ st⟩
  intro eq
  by_cases az : chosen n steps bank a=true
  · exact nb (eq.trans (Uniq az))
  have az' := Bool.eq_false_iff.mpr az
  rw [eq] at le
  unfold phased at le
  rw [ss] at le
  simp only [rchosen,az',ite_true,Bool.false_eq_true,ite_false] at le
  dsimp [s] at le
  omega

#print axioms miss_of_stage
end IU.Eliminate
