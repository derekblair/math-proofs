import Trace5Part29
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step480 : NodeGood bank Hit (144115992557080840,713045677315194896,0) := by
  apply use_pivot bank Hit sym noLoop 144115992557080840 713045677315194896 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 144115992557080840 713045677315194896 0 ([40] : List (Fin n))=[(144117092068708616,713044577803567120,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step479
theorem step481 : NodeGood bank Hit (144115442801266952,713046227071008784,0) := by
  apply use_pivot bank Hit sym noLoop 144115442801266952 713046227071008784 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 144115442801266952 713046227071008784 0 ([39] : List (Fin n))=[(144115992557080840,713045677315194896,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step480
theorem step482 : NodeGood bank Hit (254725411080,857935471601692371,0) := by
  apply use_pivot bank Hit sym noLoop 254725411080 857935471601692371 0 6 [6,57] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725411080 857935471601692371 0 ([6,57] : List (Fin n))=[(254725411144,713820283525836435,0),(144115442801266952,713046227071008784,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step447
  · subst C; exact step481
theorem step483 : NodeGood bank Hit (3431813281844646144,0,0) := by
  exact leaf bank Hit 3431813281844646144 0 ⟨3431813281844646144,by decide +kernel,rfl⟩
theorem step484 : NodeGood bank Hit (3432094481943449856,0,0) := by
  exact leaf bank Hit 3432094481943449856 0 ⟨3432094481943449856,by decide +kernel,rfl⟩
theorem step485 : NodeGood bank Hit (3431813006966739200,281749854617600,0) := by
  apply use_pivot bank Hit sym noLoop 3431813006966739200 281749854617600 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3431813006966739200 281749854617600 0 ([38,48] : List (Fin n))=[(3431813281844646144,0,0),(3432094481943449856,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step483
  · subst C; exact step484
theorem step486 : NodeGood bank Hit (3433220364670423296,0,0) := by
  exact leaf bank Hit 3433220364670423296 0 ⟨3433220364670423296,by decide +kernel,rfl⟩
theorem step487 : NodeGood bank Hit (3432938889693712640,281474976710656,0) := by
  apply use_pivot bank Hit sym noLoop 3432938889693712640 281474976710656 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3432938889693712640 281474976710656 0 ([48] : List (Fin n))=[(3433220364670423296,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step486
theorem step488 : NodeGood bank Hit (3431812989786870016,1407666941329408,0) := by
  apply use_pivot bank Hit sym noLoop 3431812989786870016 1407666941329408 0 34 [34,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3431812989786870016 1407666941329408 0 ([34,50] : List (Fin n))=[(3431813006966739200,281749854617600,0),(3432938889693712640,281474976710656,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step485
  · subst C; exact step487
theorem step489 : NodeGood bank Hit (3451234763163128064,0,0) := by
  exact leaf bank Hit 3451234763163128064 0 ⟨3451234763163128064,by decide +kernel,rfl⟩
theorem step490 : NodeGood bank Hit (3450108863256285440,1125899906842624,0) := by
  apply use_pivot bank Hit sym noLoop 3450108863256285440 1125899906842624 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3450108863256285440 1125899906842624 0 ([50] : List (Fin n))=[(3451234763163128064,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step489
theorem step491 : NodeGood bank Hit (3449827388279574784,1407374883553280,0) := by
  apply use_pivot bank Hit sym noLoop 3449827388279574784 1407374883553280 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3449827388279574784 1407374883553280 0 ([48] : List (Fin n))=[(3450108863256285440,1125899906842624,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step490
theorem step492 : NodeGood bank Hit (3431812989770092800,19422065467588608,0) := by
  apply use_pivot bank Hit sym noLoop 3431812989770092800 19422065467588608 0 24 [24,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3431812989770092800 19422065467588608 0 ([24,54] : List (Fin n))=[(3431812989786870016,1407666941329408,0),(3449827388279574784,1407374883553280,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step488
  · subst C; exact step491
theorem step493 : NodeGood bank Hit (1125969980556398848,2325265074681282560,0) := by
  apply use_pivot bank Hit sym noLoop 1125969980556398848 2325265074681282560 0 61 [61] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1125969980556398848 2325265074681282560 0 ([61] : List (Fin n))=[(3431812989770092800,19422065467588608,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step492
theorem step494 : NodeGood bank Hit (549509228252975360,2901725826984706048,0) := by
  apply use_pivot bank Hit sym noLoop 549509228252975360 2901725826984706048 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 549509228252975360 2901725826984706048 0 ([59] : List (Fin n))=[(1125969980556398848,2325265074681282560,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step493
theorem step495 : NodeGood bank Hit (405394040177119488,3045841015060561920,0) := by
  apply use_pivot bank Hit sym noLoop 405394040177119488 3045841015060561920 0 57 [57] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 405394040177119488 3045841015060561920 0 ([57] : List (Fin n))=[(549509228252975360,2901725826984706048,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step494
end IU.Trace5
