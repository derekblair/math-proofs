import Mathlib.Data.Finset.Card

namespace BK
open Finset

def Clique {α} (E : α → α → Prop) (S : Finset α) : Prop :=
  ∀ x∈S, ∀ y∈S, x≠y → E x y

def MaxClique {α} (E : α → α → Prop) (S : Finset α) : Prop :=
  Clique E S ∧ ∀ T : Finset α, Clique E T → S⊆T → T⊆S

theorem insert_clique {α} [DecidableEq α] {E : α → α → Prop} (sym : Symmetric E)
    {S : Finset α} (cl : Clique E S) (v : α) (adj : ∀ w∈S, E v w) :
    Clique E (insert v S) := by
  intro x hx y hy ne
  rcases mem_insert.mp hx with same|inside
  · subst x
    exact adj _ ((mem_insert.mp hy).resolve_left (Ne.symm ne))
  · rcases mem_insert.mp hy with same|other
    · subst y
      exact sym (adj _ inside)
    · exact cl _ inside _ other ne

theorem pivot_branch {α} [DecidableEq α] {E : α → α → Prop}
    (sym : Symmetric E) (noLoop : ∀ x, ¬ E x x)
    {Q R P : Finset α} (maxQ : MaxClique E Q)
    (sub : Q⊆R∪P) {v : α} (vR : ∀ w∈R, E v w) :
    ∃ w∈Q, w∈P ∧ ¬ E v w := by
  classical
  by_contra! bad
  have vNear : ∀ w∈Q, E v w := by
    intro w hw
    rcases mem_union.mp (sub hw) with h|h
    · exact vR _ h
    · exact bad _ hw h
  have vQ : v∈Q := maxQ.2 _ (insert_clique sym maxQ.1 v vNear) (subset_insert _ _) (mem_insert_self _ _)
  exact noLoop v (vNear _ vQ)

theorem child_cover {α} [DecidableEq α] {E : α → α → Prop} [DecidableRel E]
    {Q R P X : Finset α} (cl : Clique E Q) (sub : Q⊆R∪P)
    (inc : R⊆Q) (dis : Disjoint Q X) {v : α} (vv : v∈Q) :
    insert v R⊆Q ∧
    Q⊆insert v R ∪ P.filter (E v) ∧ Disjoint Q (X.filter (E v)) := by
  refine ⟨insert_subset vv inc,?_ ,disjoint_of_subset_right (filter_subset _ _) dis⟩
  intro a ha
  by_cases h : a=v
  · subst a
    exact mem_union.mpr (Or.inl (mem_insert_self _ _))
  rcases mem_union.mp (sub ha) with hR|hP
  · exact mem_union.mpr (Or.inl (mem_insert_of_mem hR))
  · exact mem_union.mpr (Or.inr (mem_filter.mpr ⟨hP,cl _ vv _ ha (fun e => h e.symm)⟩))

/-- Excluding a set of vertices outside the target clique does not change
its coverage by the pinned prefix plus potential vertices. -/
theorem drop_not_in_target {α} [DecidableEq α]
    {Q R P D : Finset α} (h : Q⊆R∪P) (dis : Disjoint Q D) :
    Q⊆R∪(P\D) := by
  intro a ha
  rcases mem_union.mp (h ha) with hr|hp
  · exact mem_union.mpr (Or.inl hr)
  · exact mem_union.mpr (Or.inr (mem_sdiff.mpr ⟨hp,fun d => disjoint_left.mp dis ha d⟩))

#print axioms pivot_branch
#print axioms child_cover
end BK
