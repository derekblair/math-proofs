import Sharp5Grid0Compare13
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot56 : ∀ i j : Fin 8, dot data histograms[56]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare56 : ∀ i j : Fin 8, sumTable data 46444175655269336 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts56, hist_sound data _ _ counts6] <;> exact dot56 i j
theorem dot57 : ∀ i j : Fin 8, dot data histograms[57]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare57 : ∀ i j : Fin 8, sumTable data 47006575853040600 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts57, hist_sound data _ _ counts6] <;> exact dot57 i j
theorem dot58 : ∀ i j : Fin 8, dot data histograms[58]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare58 : ∀ i j : Fin 8, sumTable data 48695971173987096 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts58, hist_sound data _ _ counts6] <;> exact dot58 i j
theorem dot59 : ∀ i j : Fin 8, dot data histograms[59]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare59 : ∀ i j : Fin 8, sumTable data 49258371371758360 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts59, hist_sound data _ _ counts6] <;> exact dot59 i j
end IU.Sharp5.Cone0
