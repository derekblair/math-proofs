import Trace5Part10
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step176 : NodeGood bank Hit (254742362072,45880438652405763,0) := by
  apply use_pivot bank Hit sym noLoop 254742362072 45880438652405763 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254742362072 45880438652405763 0 ([11] : List (Fin n))=[(254742364120,45880438652403715,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step175
theorem step177 : NodeGood bank Hit (47006575853040600,0,0) := by
  exact leaf bank Hit 47006575853040600 0 ⟨47006575853040600,by decide +kernel,rfl⟩
theorem step178 : NodeGood bank Hit (10977778834076632,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 10977778834076632 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10977778834076632 36028797018963968 0 ([55] : List (Fin n))=[(47006575853040600,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step177
theorem step179 : NodeGood bank Hit (1970579579335640,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 1970579579335640 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1970579579335640 45035996273704960 0 ([53] : List (Fin n))=[(10977778834076632,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step178
theorem step180 : NodeGood bank Hit (1407629625914328,45598946227126272,0) := by
  apply use_pivot bank Hit sym noLoop 1407629625914328 45598946227126272 0 49 [49] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1407629625914328 45598946227126272 0 ([49] : List (Fin n))=[(1970579579335640,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step179
theorem step181 : NodeGood bank Hit (1126154649203672,45880421203836928,0) := by
  apply use_pivot bank Hit sym noLoop 1126154649203672 45880421203836928 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1126154649203672 45880421203836928 0 ([48] : List (Fin n))=[(1407629625914328,45598946227126272,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step180
theorem step182 : NodeGood bank Hit (254742361048,47006338559249411,0) := by
  apply use_pivot bank Hit sym noLoop 254742361048 47006338559249411 0 10 [10,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254742361048 47006338559249411 0 ([10,50] : List (Fin n))=[(254742362072,45880438652405763,0),(1126154649203672,45880421203836928,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step176
  · subst C; exact step181
theorem step183 : NodeGood bank Hit (65232080578278360,0,0) := by
  exact leaf bank Hit 65232080578278360 0 ⟨65232080578278360,by decide +kernel,rfl⟩
theorem step184 : NodeGood bank Hit (29203283559314392,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 29203283559314392 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 29203283559314392 36028797018963968 0 ([55] : List (Fin n))=[(65232080578278360,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step183
theorem step185 : NodeGood bank Hit (11188885049832408,54043195528445952,0) := by
  apply use_pivot bank Hit sym noLoop 11188885049832408 54043195528445952 0 54 [54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 11188885049832408 54043195528445952 0 ([54] : List (Fin n))=[(29203283559314392,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step184
theorem step186 : NodeGood bank Hit (2181685795091416,63050394783186944,0) := by
  apply use_pivot bank Hit sym noLoop 2181685795091416 63050394783186944 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2181685795091416 63050394783186944 0 ([53] : List (Fin n))=[(11188885049832408,54043195528445952,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step185
theorem step187 : NodeGood bank Hit (1055785888248792,64176294690029568,0) := by
  apply use_pivot bank Hit sym noLoop 1055785888248792 64176294690029568 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1055785888248792 64176294690029568 0 ([50] : List (Fin n))=[(2181685795091416,63050394783186944,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step186
theorem step188 : NodeGood bank Hit (492835934827480,64739244643450880,0) := by
  apply use_pivot bank Hit sym noLoop 492835934827480 64739244643450880 0 49 [49] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 492835934827480 64739244643450880 0 ([49] : List (Fin n))=[(1055785888248792,64176294690029568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step187
theorem step189 : NodeGood bank Hit (211360958116824,65020719620161536,0) := by
  apply use_pivot bank Hit sym noLoop 211360958116824 65020719620161536 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 211360958116824 65020719620161536 0 ([48] : List (Fin n))=[(492835934827480,64739244643450880,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step188
theorem step190 : NodeGood bank Hit (70623469761496,65161457108516864,0) := by
  apply use_pivot bank Hit sym noLoop 70623469761496 65161457108516864 0 47 [47] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 70623469761496 65161457108516864 0 ([47] : List (Fin n))=[(211360958116824,65020719620161536,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step189
theorem step191 : NodeGood bank Hit (140992213939160,65020719620161536,70368744177664) := by
  apply use_pivot bank Hit sym noLoop 140992213939160 65020719620161536 70368744177664 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 140992213939160 65020719620161536 70368744177664 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
end IU.Trace5
