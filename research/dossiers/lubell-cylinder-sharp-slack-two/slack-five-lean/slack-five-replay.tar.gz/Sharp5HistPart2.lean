import Sharp5HistPart1
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts10 : ∀ q : Fin 20, ((members n 2058897678299).filter (fun v => code v=q)).card=(histograms[10]!)[q.val]! := by decide +kernel
theorem counts11 : ∀ q : Fin 20, ((members n 2059300331487).filter (fun v => code v=q)).card=(histograms[11]!)[q.val]! := by decide +kernel
theorem counts12 : ∀ q : Fin 20, ((members n 2196336107483).filter (fun v => code v=q)).card=(histograms[12]!)[q.val]! := by decide +kernel
theorem counts13 : ∀ q : Fin 20, ((members n 4395359360987).filter (fun v => code v=q)).card=(histograms[13]!)[q.val]! := by decide +kernel
theorem counts14 : ∀ q : Fin 20, ((members n 6456944188891).filter (fun v => code v=q)).card=(histograms[14]!)[q.val]! := by decide +kernel
end IU.Sharp5
