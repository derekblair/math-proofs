import WalkReflection
namespace IU.UniversalCount

def Annotated (n : Nat) (H D : ℤ) :=
  { p : List Bool × Nat // p.1.length=n ∧ height p.1=D ∧ FirstHit p.1 p.2 H }

theorem first_unique {w : List Bool} {H : ℤ} {a b : Nat}
    (ha : FirstHit w a H) (hb : FirstHit w b H) : a=b := by
  rcases lt_trichotomy a b with h|h|h
  · exact False.elim (hb.2.2 _ h ha.2.1)
  · exact h
  · exact False.elim (ha.2.2 _ h hb.2.1)

def reflect_map {n : Nat} {H D E : Int} (e : E=2*H-D) :
    Annotated n H D → Annotated n H E := fun p =>
  ⟨(reflect p.val.1 p.val.2,p.val.2),by
    obtain ⟨len,endpoint,hit⟩ := p.property
    refine ⟨(reflect_length _ _).trans len,?_,preserve_hit hit⟩
    have ep := reflect_endpoint _ hit.2.1
    change height (reflect p.val.1 p.val.2)=E
    omega⟩

def reflect_annotated (n : Nat) (H D : ℤ) :
    Annotated n H D ≃ Annotated n H (2*H-D) where
  toFun := reflect_map rfl
  invFun := reflect_map (by omega)
  left_inv p := by
    apply Subtype.ext
    change (reflect (reflect p.val.1 p.val.2) p.val.2,p.val.2)=p.val
    rw [reflect_twice _ p.property.2.2.1]
  right_inv p := by
    apply Subtype.ext
    change (reflect (reflect p.val.1 p.val.2) p.val.2,p.val.2)=p.val
    rw [reflect_twice _ p.property.2.2.1]

def Crosses (n : Nat) (H D : ℤ) :=
  {w : List Bool // w.length=n ∧ height w=D ∧ ∃ k≤w.length, H≤partialHeight w k}

def Ends (n : Nat) (D : ℤ) :=
  {w : List Bool // w.length=n ∧ height w=D}

def forgetHit {n : Nat} {H D : ℤ} (p : Annotated n H D) : Crosses n H D :=
  ⟨p.val.1,p.property.1,p.property.2.1,p.val.2,p.property.2.2.1,
    le_of_eq p.property.2.2.2.1.symm⟩

noncomputable def crossesAnnotated (n : Nat) (H D : ℤ) (h0 : 0≤H) :
    Crosses n H D ≃ Annotated n H D where
  toFun w :=
    let C := exists_first h0 w.property.2.2
    ⟨(w.val,Classical.choose C),w.property.1,w.property.2.1,Classical.choose_spec C⟩
  invFun := forgetHit
  left_inv w := Subtype.ext rfl
  right_inv p := by
    apply Subtype.ext
    change (p.val.1,Classical.choose (exists_first h0 (forgetHit p).property.2.2))=p.val
    refine Prod.ext rfl ?_
    exact first_unique (Classical.choose_spec (exists_first h0 (forgetHit p).property.2.2)) p.property.2.2

noncomputable def endsCrosses (n : Nat) (H D : ℤ) (hd : H≤D) :
    Ends n D ≃ Crosses n H D where
  toFun w := ⟨w.val,w.property.1,w.property.2,w.val.length,le_rfl,by
    simpa [partialHeight,w.property.2] using hd⟩
  invFun w := ⟨w.val,w.property.1,w.property.2.1⟩
  left_inv w := Subtype.ext rfl
  right_inv w := Subtype.ext rfl

/-- Reflect at the first hit, with the hitting time removed on both sides. -/
noncomputable def reflection (n : Nat) (H D : ℤ) (nonneg : 0≤H) (endLe : D≤H) :
    Crosses n H D ≃ Ends n (2*H-D) :=
  (crossesAnnotated n H D nonneg).trans
    ((reflect_annotated n H D).trans
      ((crossesAnnotated n H (2*H-D) nonneg).symm.trans
        (endsCrosses n H (2*H-D) (by omega)).symm))

#print axioms reflection
end IU.UniversalCount
