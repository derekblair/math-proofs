import Sharp5Grid2Compare1
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot8 : ∀ i j : Fin 8, dot data histograms[8]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare8 : ∀ i j : Fin 8, sumTable data 959788711903 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts8, hist_sound data _ _ counts61] <;> exact dot8 i j
theorem dot9 : ∀ i j : Fin 8, dot data histograms[9]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare9 : ∀ i j : Fin 8, sumTable data 1096824487899 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts9, hist_sound data _ _ counts61] <;> exact dot9 i j
theorem dot10 : ∀ i j : Fin 8, dot data histograms[10]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare10 : ∀ i j : Fin 8, sumTable data 2058897678299 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts10, hist_sound data _ _ counts61] <;> exact dot10 i j
theorem dot11 : ∀ i j : Fin 8, dot data histograms[11]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare11 : ∀ i j : Fin 8, sumTable data 2059300331487 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts11, hist_sound data _ _ counts61] <;> exact dot11 i j
end IU.Sharp5.Cone2
