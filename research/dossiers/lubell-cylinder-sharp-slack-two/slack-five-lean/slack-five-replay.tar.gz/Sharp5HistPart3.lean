import Sharp5HistPart2
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts15 : ∀ q : Fin 20, ((members n 6457346842079).filter (fun v => code v=q)).card=(histograms[15]!)[q.val]! := by decide +kernel
theorem counts16 : ∀ q : Fin 20, ((members n 6594382618075).filter (fun v => code v=q)).card=(histograms[16]!)[q.val]! := by decide +kernel
theorem counts17 : ∀ q : Fin 20, ((members n 8793405871579).filter (fun v => code v=q)).card=(histograms[17]!)[q.val]! := by decide +kernel
theorem counts18 : ∀ q : Fin 20, ((members n 17589498893659).filter (fun v => code v=q)).card=(histograms[18]!)[q.val]! := by decide +kernel
theorem counts19 : ∀ q : Fin 20, ((members n 35181684938059).filter (fun v => code v=q)).card=(histograms[19]!)[q.val]! := by decide +kernel
end IU.Sharp5
