import Enumerate
import Mathlib.Data.Fintype.Basic

namespace IU.Universal
open Finset
set_option maxRecDepth 40000
set_option maxHeartbeats 3000000
abbrev Vertex := Nat × Nat × Nat

def bits (mask h : Nat) : Nat :=
  ((List.range h).filter (fun z => mask.testBit z)).length

def compat (s : Nat) (a b : Vertex) : Bool :=
  (List.range (s+1)).any (fun h =>
    decide (a.2.2+b.2.2-s+a.1+b.1+h ≤ bits a.2.1 h + bits b.2.1 h))

def vertexList (s : Nat) : List Vertex :=
  ((List.range (s/2+1)).flatMap fun r =>
     (List.range (2^s)).flatMap fun m =>
       (List.range (s+1)).map fun j => (r,m,j)).filter
    (fun x => decide (bits x.2.1 s≤x.2.2+x.1) && compat s x x)

def edge (s : Nat) (a b : Fin (vertexList s).length) : Prop :=
  a≠b ∧ compat s (vertexList s)[a] (vertexList s)[b]=true

instance (s : Nat) : DecidableRel (edge s) := by
  unfold edge
  infer_instance

theorem compat_sym (s : Nat) (a b : Vertex) : compat s a b=compat s b a := by
  unfold compat
  congr 1
  funext h
  have e : a.2.2+b.2.2-s+a.1+b.1+h = b.2.2+a.2.2-s+b.1+a.1+h := by omega
  rw [e,Nat.add_comm (bits a.2.1 h) (bits b.2.1 h)]

theorem edge_sym (s : Nat) : Symmetric (edge s) := by
  intro a b h
  exact ⟨Ne.symm h.1,(compat_sym s _ _).symm.trans h.2⟩

theorem edge_irrefl (s : Nat) (a : Fin (vertexList s).length) : ¬edge s a a :=
  fun h => h.1 rfl

def listCl (s : Nat) : List (Finset (Fin (vertexList s).length)) :=
  BK.enumerate (edge s) (vertexList s).length ∅ univ ∅

theorem listCl_covers (s : Nat) {Q : Finset (Fin (vertexList s).length)}
    (maxQ : BK.MaxClique (edge s) Q) : Q∈listCl s := by
  apply BK.enumerate_covers (edge s) (edge_sym s) (edge_irrefl s) _ maxQ
  · simp [BK.Covers]
  · simp [BK.NeighborsOf]
  · simp

theorem vertices4 : (vertexList 4).length = 31 := by decide
theorem vertices5 : (vertexList 5).length = 62 := by decide
theorem vertices6 : (vertexList 6).length = 150 := by decide
theorem vertices7 : (vertexList 7).length = 300 := by decide

#print axioms listCl_covers
#print axioms vertices7
end IU.Universal
