import Sharp5HistPart11
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts60 : ∀ q : Fin 20, ((members n 64669680380507096).filter (fun v => code v=q)).card=(histograms[60]!)[q.val]! := by decide +kernel
theorem counts61 : ∀ q : Fin 20, ((members n 65232080578278360).filter (fun v => code v=q)).card=(histograms[61]!)[q.val]! := by decide +kernel
theorem counts62 : ∀ q : Fin 20, ((members n 117097985402295256).filter (fun v => code v=q)).card=(histograms[62]!)[q.val]! := by decide +kernel
theorem counts63 : ∀ q : Fin 20, ((members n 117102383448805848).filter (fun v => code v=q)).card=(histograms[63]!)[q.val]! := by decide +kernel
theorem counts64 : ∀ q : Fin 20, ((members n 117111179541827928).filter (fun v => code v=q)).card=(histograms[64]!)[q.val]! := by decide +kernel
end IU.Sharp5
