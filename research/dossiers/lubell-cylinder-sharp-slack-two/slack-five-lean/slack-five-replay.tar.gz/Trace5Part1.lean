import Trace5Part0
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step16 : NodeGood bank Hit (1619081387144184,18014398509481984,0) := by
  apply use_pivot bank Hit sym noLoop 1619081387144184 18014398509481984 0 54 [54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1619081387144184 18014398509481984 0 ([54] : List (Fin n))=[(19633479896626168,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step15
theorem step17 : NodeGood bank Hit (493181480301560,19140298416324608,0) := by
  apply use_pivot bank Hit sym noLoop 493181480301560 19140298416324608 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 493181480301560 19140298416324608 0 ([50] : List (Fin n))=[(1619081387144184,18014398509481984,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step16
theorem step18 : NodeGood bank Hit (211706503590904,19421773393035264,0) := by
  apply use_pivot bank Hit sym noLoop 211706503590904 19421773393035264 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 211706503590904 19421773393035264 0 ([48] : List (Fin n))=[(493181480301560,19140298416324608,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step17
theorem step19 : NodeGood bank Hit (70969015235576,19562510881390592,0) := by
  apply use_pivot bank Hit sym noLoop 70969015235576 19562510881390592 0 47 [47] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 70969015235576 19562510881390592 0 ([47] : List (Fin n))=[(211706503590904,19421773393035264,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step18
theorem step20 : NodeGood bank Hit (141337759413240,19421773393035264,70368744177664) := by
  apply use_pivot bank Hit sym noLoop 141337759413240 19421773393035264 70368744177664 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 141337759413240 19421773393035264 70368744177664 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step21 : NodeGood bank Hit (18014998780539896,1407374883553280,211106232532992) := by
  apply use_pivot bank Hit sym noLoop 18014998780539896 1407374883553280 211106232532992 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18014998780539896 1407374883553280 211106232532992 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step22 : NodeGood bank Hit (600271057912,19633172506217479,0) := by
  apply use_pivot bank Hit sym noLoop 600271057912 19633172506217479 0 24 [24,46,47,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 600271057912 19633172506217479 0 ([24,46,47,54] : List (Fin n))=[(600287835128,1407667747425287,0),(70969015235576,19562510881390592,0),(141337759413240,19421773393035264,70368744177664),(18014998780539896,1407374883553280,211106232532992)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step14
  · subst C; exact step19
  · subst C; exact step20
  · subst C; exact step21
theorem step23 : NodeGood bank Hit (595976090616,19633176801184775,0) := by
  apply use_pivot bank Hit sym noLoop 595976090616 19633176801184775 0 32 [32] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 595976090616 19633176801184775 0 ([32] : List (Fin n))=[(600271057912,19633172506217479,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step22
theorem step24 : NodeGood bank Hit (595976090488,19633176801184903,0) := by
  apply use_pivot bank Hit sym noLoop 595976090488 19633176801184903 0 7 [7] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 595976090488 19633176801184903 0 ([7] : List (Fin n))=[(595976090616,19633176801184775,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step23
theorem step25 : NodeGood bank Hit (3659770690106168,0,0) := by
  exact leaf bank Hit 3659770690106168 0 ⟨3659770690106168,by decide +kernel,rfl⟩
theorem step26 : NodeGood bank Hit (2533870783263544,1125899906842624,0) := by
  apply use_pivot bank Hit sym noLoop 2533870783263544 1125899906842624 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2533870783263544 1125899906842624 0 ([50] : List (Fin n))=[(3659770690106168,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step25
theorem step27 : NodeGood bank Hit (2252395806552888,1407374883553280,0) := by
  apply use_pivot bank Hit sym noLoop 2252395806552888 1407374883553280 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2252395806552888 1407374883553280 0 ([48] : List (Fin n))=[(2533870783263544,1125899906842624,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step26
theorem step28 : NodeGood bank Hit (2252395789775672,1407374900330496,0) := by
  apply use_pivot bank Hit sym noLoop 2252395789775672 1407374900330496 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2252395789775672 1407374900330496 0 ([24] : List (Fin n))=[(2252395806552888,1407374883553280,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step27
theorem step29 : NodeGood bank Hit (595976090424,21884976614870215,0) := by
  apply use_pivot bank Hit sym noLoop 595976090424 21884976614870215 0 6 [6,51] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 595976090424 21884976614870215 0 ([6,51] : List (Fin n))=[(595976090488,19633176801184903,0),(2252395789775672,1407374900330496,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step24
  · subst C; exact step28
theorem step30 : NodeGood bank Hit (46220276536,21885526370684103,0) := by
  apply use_pivot bank Hit sym noLoop 46220276536 21885526370684103 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 46220276536 21885526370684103 0 ([39] : List (Fin n))=[(595976090424,21884976614870215,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step29
theorem step31 : NodeGood bank Hit (44072792888,21885528518167751,0) := by
  apply use_pivot bank Hit sym noLoop 44072792888 21885528518167751 0 31 [31] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 44072792888 21885528518167751 0 ([31] : List (Fin n))=[(46220276536,21885526370684103,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step30
end IU.Trace5
