import Trace5Part34
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step560 : NodeGood bank Hit (2252050260906240,3433783059881828888,0) := by
  apply use_pivot bank Hit sym noLoop 2252050260906240 3433783059881828888 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2252050260906240 3433783059881828888 0 ([48] : List (Fin n))=[(2533525237616896,3433501584905118232,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step559
theorem step561 : NodeGood bank Hit (2252050244129024,3433783059898606104,0) := by
  apply use_pivot bank Hit sym noLoop 2252050244129024 3433783059898606104 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2252050244129024 3433783059898606104 0 ([24] : List (Fin n))=[(2252050260906240,3433783059881828888,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step560
theorem step562 : NodeGood bank Hit (250430443776,3454260661075750619,0) := by
  apply use_pivot bank Hit sym noLoop 250430443776 3454260661075750619 0 32 [32,51] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 250430443776 3454260661075750619 0 ([32,51] : List (Fin n))=[(254725411072,3452008856967098075,0),(2252050244129024,3433783059898606104,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step507
  · subst C; exact step561
theorem step563 : NodeGood bank Hit (1206683474532233984,0,0) := by
  exact leaf bank Hit 1206683474532233984 0 ⟨1206683474532233984,by decide +kernel,rfl⟩
theorem step564 : NodeGood bank Hit (1206120524578812672,562949953421312,0) := by
  apply use_pivot bank Hit sym noLoop 1206120524578812672 562949953421312 0 49 [49] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206120524578812672 562949953421312 0 ([49] : List (Fin n))=[(1206683474532233984,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step563
theorem step565 : NodeGood bank Hit (1206120524578681600,562949953552384,0) := by
  apply use_pivot bank Hit sym noLoop 1206120524578681600 562949953552384 0 17 [17] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206120524578681600 562949953552384 0 ([17] : List (Fin n))=[(1206120524578812672,562949953421312,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step564
theorem step566 : NodeGood bank Hit (1206120524578673408,562949953560576,0) := by
  apply use_pivot bank Hit sym noLoop 1206120524578673408 562949953560576 0 13 [13] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206120524578673408 562949953560576 0 ([13] : List (Fin n))=[(1206120524578681600,562949953552384,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step565
theorem step567 : NodeGood bank Hit (1206120524578672896,562949953561088,0) := by
  apply use_pivot bank Hit sym noLoop 1206120524578672896 562949953561088 0 9 [9] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206120524578672896 562949953561088 0 ([9] : List (Fin n))=[(1206120524578673408,562949953560576,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step566
theorem step568 : NodeGood bank Hit (1206120524578771200,562949953430016,32768) := by
  apply use_pivot bank Hit sym noLoop 1206120524578771200 562949953430016 32768 15 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206120524578771200 562949953430016 32768 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step569 : NodeGood bank Hit (1206121074334462720,0,0) := by
  exact leaf bank Hit 1206121074334462720 0 ⟨1206121074334462720,by decide +kernel,rfl⟩
theorem step570 : NodeGood bank Hit (1206121074334462208,512,0) := by
  apply use_pivot bank Hit sym noLoop 1206121074334462208 512 0 9 [9] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206121074334462208 512 0 ([9] : List (Fin n))=[(1206121074334462720,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step569
theorem step571 : NodeGood bank Hit (1278181966907265792,0,0) := by
  exact leaf bank Hit 1278181966907265792 0 ⟨1278181966907265792,by decide +kernel,rfl⟩
theorem step572 : NodeGood bank Hit (4592897263349616896,0,0) := by
  exact leaf bank Hit 4592897263349616896 0 ⟨4592897263349616896,by decide +kernel,rfl⟩
theorem step573 : NodeGood bank Hit (2287054254135922944,2305843009213693952,0) := by
  apply use_pivot bank Hit sym noLoop 2287054254135922944 2305843009213693952 0 61 [61] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2287054254135922944 2305843009213693952 0 ([61] : List (Fin n))=[(4592897263349616896,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step572
theorem step574 : NodeGood bank Hit (1710593501832499456,2882303761517117440,0) := by
  apply use_pivot bank Hit sym noLoop 1710593501832499456 2882303761517117440 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1710593501832499456 2882303761517117440 0 ([59] : List (Fin n))=[(2287054254135922944,2305843009213693952,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step573
theorem step575 : NodeGood bank Hit (1422363125680787712,3170534137668829184,0) := by
  apply use_pivot bank Hit sym noLoop 1422363125680787712 3170534137668829184 0 58 [58] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1422363125680787712 3170534137668829184 0 ([58] : List (Fin n))=[(1710593501832499456,2882303761517117440,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step574
end IU.Trace5
