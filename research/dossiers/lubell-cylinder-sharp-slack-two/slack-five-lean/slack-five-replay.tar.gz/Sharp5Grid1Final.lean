import Sharp5Grid1Compare26
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem compare (R : Nat) (h : R ∈ IU.Trace5.output) (i j : Fin 8) :
    sumTable data R i.val j.val≤sumTable data bestMask i.val j.val := by
  change R∈[272190930907,409630277595,410032930783,547068706779,890668679131,891071332319,893151707135,959386058715,959788711903,1096824487899,2058897678299,2059300331487,2196336107483,4395359360987,6456944188891,6457346842079,6594382618075,8793405871579,17589498893659,35181684938059,70366057026889,282092444418040,1407975171388408,3659770690106168,9007471177236440,9007608616583128,9007746055012312,9008089654984664,9008158372364248,9008295810793432,9009257883983832,9009395322413016,9011594345666520,9013655930494424,9013793368923608,9015992392177112,9024788485199192,9289289753001944,10415172479972312,12666967998690072,19633479896626168,28640677205210072,45036543073714136,45037092829495256,45038192341114840,45040391364368344,45042590387625432,45044789410878936,45053585503901016,45318292928298968,45319392439918552,45321591463172056,45323790486429144,45325989509682648,45334785602704728,45880693126070232,46444175655269336,47006575853040600,48695971173987096,49258371371758360,64669680380507096,65232080578278360,117097985402295256,117102383448805848,117111179541827928,117379185501098968,117383583547609560,117392379640631640,118505068228072408,118509466274583000,118518262367605080,120756863746790168,136523864767287768,136532660860309848,136598631557976408,136730572953310168,261226367617683736,261507567716487448,262633450443460888,264885245962178840,280647848936165656,576531118360450376,585538317346755912,621567114365457736,621848314464261448,693624708403384648,693905908502188360,695031791229161800,713046189721866568,713112160419533128,837739896479240456,838021096578044168,839146979305017608,841398774823735560,857161377797722376,1170092071159165696,1206121074334462720,1206683474532233984,1278181966907265792,3431813281844646144,3432094481943449856,3433220364670423296,3435472160189141248,3451234763163128064,4592897263349616896] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh|hh
  · subst R; exact compare0 i j
  · subst R; exact compare1 i j
  · subst R; exact compare2 i j
  · subst R; exact compare3 i j
  · subst R; exact compare4 i j
  · subst R; exact compare5 i j
  · subst R; exact compare6 i j
  · subst R; exact compare7 i j
  · subst R; exact compare8 i j
  · subst R; exact compare9 i j
  · subst R; exact compare10 i j
  · subst R; exact compare11 i j
  · subst R; exact compare12 i j
  · subst R; exact compare13 i j
  · subst R; exact compare14 i j
  · subst R; exact compare15 i j
  · subst R; exact compare16 i j
  · subst R; exact compare17 i j
  · subst R; exact compare18 i j
  · subst R; exact compare19 i j
  · subst R; exact compare20 i j
  · subst R; exact compare21 i j
  · subst R; exact compare22 i j
  · subst R; exact compare23 i j
  · subst R; exact compare24 i j
  · subst R; exact compare25 i j
  · subst R; exact compare26 i j
  · subst R; exact compare27 i j
  · subst R; exact compare28 i j
  · subst R; exact compare29 i j
  · subst R; exact compare30 i j
  · subst R; exact compare31 i j
  · subst R; exact compare32 i j
  · subst R; exact compare33 i j
  · subst R; exact compare34 i j
  · subst R; exact compare35 i j
  · subst R; exact compare36 i j
  · subst R; exact compare37 i j
  · subst R; exact compare38 i j
  · subst R; exact compare39 i j
  · subst R; exact compare40 i j
  · subst R; exact compare41 i j
  · subst R; exact compare42 i j
  · subst R; exact compare43 i j
  · subst R; exact compare44 i j
  · subst R; exact compare45 i j
  · subst R; exact compare46 i j
  · subst R; exact compare47 i j
  · subst R; exact compare48 i j
  · subst R; exact compare49 i j
  · subst R; exact compare50 i j
  · subst R; exact compare51 i j
  · subst R; exact compare52 i j
  · subst R; exact compare53 i j
  · subst R; exact compare54 i j
  · subst R; exact compare55 i j
  · subst R; exact compare56 i j
  · subst R; exact compare57 i j
  · subst R; exact compare58 i j
  · subst R; exact compare59 i j
  · subst R; exact compare60 i j
  · subst R; exact compare61 i j
  · subst R; exact compare62 i j
  · subst R; exact compare63 i j
  · subst R; exact compare64 i j
  · subst R; exact compare65 i j
  · subst R; exact compare66 i j
  · subst R; exact compare67 i j
  · subst R; exact compare68 i j
  · subst R; exact compare69 i j
  · subst R; exact compare70 i j
  · subst R; exact compare71 i j
  · subst R; exact compare72 i j
  · subst R; exact compare73 i j
  · subst R; exact compare74 i j
  · subst R; exact compare75 i j
  · subst R; exact compare76 i j
  · subst R; exact compare77 i j
  · subst R; exact compare78 i j
  · subst R; exact compare79 i j
  · subst R; exact compare80 i j
  · subst R; exact compare81 i j
  · subst R; exact compare82 i j
  · subst R; exact compare83 i j
  · subst R; exact compare84 i j
  · subst R; exact compare85 i j
  · subst R; exact compare86 i j
  · subst R; exact compare87 i j
  · subst R; exact compare88 i j
  · subst R; exact compare89 i j
  · subst R; exact compare90 i j
  · subst R; exact compare91 i j
  · subst R; exact compare92 i j
  · subst R; exact compare93 i j
  · subst R; exact compare94 i j
  · subst R; exact compare95 i j
  · subst R; exact compare96 i j
  · subst R; exact compare97 i j
  · subst R; exact compare98 i j
  · subst R; exact compare99 i j
  · subst R; exact compare100 i j
  · subst R; exact compare101 i j
  · subst R; exact compare102 i j
  · subst R; exact compare103 i j
  · subst R; exact compare104 i j

theorem checked (R : Nat) (h : R∈IU.Trace5.output) (a b : Nat) :
    sumN (param T a b) (param U a b) shapes (members n R) ≤
      sumN (param T a b) (param U a b) shapes (members n bestMask) := by
  apply cert_sound T U shapes _ _ d (fun v _ => vertex_degree v) (fun v _ => vertex_degree v) ?_
  intro i hi j hj
  rw [cert_linear]
  apply sub_nonneg.mpr
  have hd : d = 7 := by decide
  let i' : Fin 8 := ⟨i,by omega⟩
  let j' : Fin 8 := ⟨j,by omega⟩
  have P : ∀ v : Fin n, vcoeff T U (shapes v) i j=readTable data v i j := fun v => entries v i' j'
  simpa only [P,sumTable] using compare R h i' j'

#print axioms checked
end IU.Sharp5.Cone1
