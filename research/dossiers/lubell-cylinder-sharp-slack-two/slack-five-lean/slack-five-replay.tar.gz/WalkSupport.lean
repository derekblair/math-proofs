import WalkBijection
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Powerset
import Mathlib.SetTheory.Cardinal.Finite

namespace IU.UniversalCount
open Finset
open scoped BigOperators

def walk {n : Nat} (S : Finset (Fin n)) : List Bool := List.ofFn fun i => decide (i∈S)

def support {n : Nat} (w : List Bool) (h : w.length=n) : Finset (Fin n) :=
  univ.filter fun i => w.get (Fin.cast h.symm i)

theorem height_walk {n : Nat} (S : Finset (Fin n)) :
    height (walk S)=2*(S.card:ℤ)-n := by
  have term (i : Fin n) : step (decide (i∈S))=(if i∈S then (2:ℤ) else 0)-1 := by
    by_cases h : i∈S <;> simp [h,step]
  unfold height walk
  rw [List.map_ofFn,List.sum_ofFn]
  simp only [Function.comp_apply,term,sum_sub_distrib]
  have val : (∑ i : Fin n, if i∈S then (2:ℤ) else 0)=∑ _∈S,(2:ℤ) := by
    rw [←sum_filter]
    simp [filter_mem_eq_inter]
  rw [val,sum_const,sum_const]
  simp [nsmul_eq_mul,mul_comm]

theorem walk_support {n : Nat} (w : List Bool) (h : w.length=n) :
    walk (support w h)=w := by
  subst n
  unfold walk
  have F : (fun i : Fin w.length => decide (i∈support w rfl)) = fun i => w[i.val] := by
    funext i
    cases z : w[i.val] <;> simp [support,z]
  rw [F,List.ofFn_getElem]

theorem support_walk {n : Nat} (S : Finset (Fin n)) :
    support (walk S) (by simp [walk])=S := by
  ext i
  simp only [support,walk,mem_filter,mem_univ,true_and,List.get_eq_getElem,
    List.getElem_ofFn,decide_eq_true_eq]
  apply Iff.of_eq
  apply congrArg (fun (q : Fin n) => q∈S)
  exact Fin.ext rfl

def Slices (n m : Nat) := {S : Finset (Fin n) // S.card=m}

def terminal_support (n m : Nat) : Ends n ((2:ℤ)*m-n) ≃ Slices n m where
  toFun w := ⟨support w.val w.property.1,by
    have W := height_walk (support w.val w.property.1)
    rw [walk_support] at W
    have H := w.property.2
    omega⟩
  invFun S := ⟨walk S.val,by simp [walk],by rw [height_walk,S.property]⟩
  left_inv w := Subtype.ext (walk_support w.val w.property.1)
  right_inv S := Subtype.ext (support_walk S.val)

/-- The reflected ending condition is precisely a fixed-size subset of
time positions. This gives the binomial reflection count directly. -/
noncomputable def reflected_slice (n m : Nat) (H D : Int)
    (nonneg : 0≤H) (endLe : D≤H) (hd : 2*H-D=2*(m:ℤ)-n) :
    Crosses n H D ≃ Slices n m :=
  (reflection n H D nonneg endLe).trans (hd ▸ terminal_support n m)

theorem slices_card (n m : Nat) : Nat.card (Slices n m)=n.choose m := by
  classical
  have E : ∀ X : Finset (Fin n), X∈(univ : Finset (Fin n)).powersetCard m ↔ X.card=m := by
    intro X
    simp
  letI : Fintype (Slices n m) := Fintype.ofFinset _ E
  rw [Nat.card_eq_fintype_card]
  calc
    _ = ((univ : Finset (Fin n)).powersetCard m).card := Fintype.card_ofFinset _ E
    _ = n.choose m := by rw [card_powersetCard,card_univ,Fintype.card_fin]

theorem reflected_card (n m : Nat) (H D : Int) (hn : 0≤H) (hD : D≤H)
    (hd : 2*H-D=2*(m:ℤ)-n) : Nat.card (Crosses n H D)=n.choose m :=
  (Nat.card_congr (reflected_slice n m H D hn hD hd)).trans (slices_card n m)

/-- The fixed outer deficits and fixed center population contribute one
binomial coefficient. At this step the walk representation is exact. -/
theorem bucket_card (s m r z : Nat) (left : 2*r≤m) (right : m+2*z≤s) :
    Nat.card (Crosses s (max (2*(r:ℤ)) (2*(m:ℤ)-s+2*(z:ℤ))) (2*(m:ℤ)-s)) =
      s.choose (min (m-2*r) (s-m-2*z)) := by
  let H := max (2*(r:ℤ)) (2*(m:ℤ)-s+2*(z:ℤ))
  let D : ℤ := 2*(m:ℤ)-s
  let k := min (m-2*r) (s-m-2*z)
  have ks : k≤s := by
    unfold k
    exact (min_le_right _ _).trans (Nat.sub_le _ _ |>.trans (Nat.sub_le _ _))
  have hn : 0≤H := le_trans (by omega) (le_max_left _ _)
  have hd : D≤H := le_trans (by unfold D; omega) (le_max_right _ _)
  have q := reflected_ones (s:ℤ) (m:ℤ) (r:ℤ) (z:ℤ)
  have right' : 2*z≤s-m := by omega
  have ms : m≤s := by omega
  have qk : (k:ℤ)=(m:ℤ)-H := by
    have a : ((m-2*r:ℕ):ℤ)=(m:ℤ)-2*(r:ℤ) := by
      rw [Nat.cast_sub left,Nat.cast_mul,Nat.cast_ofNat]
    have b : ((s-m-2*z:ℕ):ℤ)=(s:ℤ)-m-2*(z:ℤ) := by
      rw [Nat.cast_sub right',Nat.cast_sub ms,Nat.cast_mul,Nat.cast_ofNat]
    unfold k H
    by_cases ab : m-2*r≤s-m-2*z
    · have ab' : (m:ℤ)-2*(r:ℤ)≤(s:ℤ)-m-2*(z:ℤ) := by omega
      rw [min_eq_left ab,a]
      rw [min_eq_left ab'] at q
      exact q.symm
    · have abn : s-m-2*z≤m-2*r := by omega
      have ab' : (s:ℤ)-m-2*(z:ℤ)≤(m:ℤ)-2*(r:ℤ) := by omega
      rw [min_eq_right abn,b]
      rw [min_eq_right ab'] at q
      exact q.symm
  have eh : 2*H-D=2*((s-k:ℕ):ℤ)-s := by
    rw [Nat.cast_sub ks]
    unfold D
    omega
  change Nat.card (Crosses s H D)=s.choose k
  rw [reflected_card s (s-k) H D hn hd eh,Nat.choose_symm ks]

#print axioms bucket_card
#print axioms reflected_card
#print axioms terminal_support
#print axioms reflected_slice
end IU.UniversalCount
