import ProfileNormalize
namespace IU.Slack
open Finset IU.Universal
open scoped BigOperators

theorem shift_inj {x y : Bag} {t s : Nat} (xx : x⊆mid t s)
    (yy : y⊆mid t s) (e : shiftMiddle x t=shiftMiddle y t) : x=y := by
  ext z
  constructor
  · intro z1
    have z' : z-t∈shiftMiddle x t := mem_image.mpr ⟨z,z1,rfl⟩
    rw [e] at z'
    obtain ⟨w,hw,E⟩ := mem_image.mp z'
    have tz : t≤z := Nat.le_of_not_gt (fun q => (mem_sdiff.mp (xx z1)).2 (mem_range.mpr q))
    have tw : t≤w := Nat.le_of_not_gt (fun q => (mem_sdiff.mp (yy hw)).2 (mem_range.mpr q))
    change w-t=z-t at E
    have zz : z=w := by omega
    exact zz ▸ hw
  · intro z1
    have z' : z-t∈shiftMiddle y t := mem_image.mpr ⟨z,z1,rfl⟩
    rw [←e] at z'
    obtain ⟨w,hw,E⟩ := mem_image.mp z'
    have tz : t≤z := Nat.le_of_not_gt (fun q => (mem_sdiff.mp (yy z1)).2 (mem_range.mpr q))
    have tw : t≤w := Nat.le_of_not_gt (fun q => (mem_sdiff.mp (xx hw)).2 (mem_range.mpr q))
    change w-t=z-t at E
    have zz : z=w := by omega
    exact zz ▸ hw

theorem small_inj {x y : Q} {t u s : Nat}
    (hx : Admissible t u s x) (hy : Admissible t u s y)
    (e : small t s x=small t s y) : x=y := by
  have a := congrArg Prod.fst e
  have b := congrArg (fun z => z.2.1) e
  have c := congrArg (fun z => z.2.2) e
  change t-x.1=t-y.1 at a
  change mask (shiftMiddle x.2.1 t) s=mask (shiftMiddle y.2.1 t) s at b
  change full x-t=full y-t at c
  have b' := shift_inj hx.1 hy.1 (mask_inj (shift_range hx.1) (shift_range hy.1) b)
  have bd := congrArg card b'
  have hx1 := hx.2.1
  have hy1 := hy.2.1
  have hx2 := hx.2.2.2.1
  have hy2 := hy.2.2.2.1
  unfold full at c hx2 hy2
  apply Prod.ext (by omega)
  apply Prod.ext b'
  omega

def normalizedWeight (w : Nat → Nat) (t u s : Nat) (v : Vertex) : Nat :=
  t.choose v.1 * u.choose (v.2.2+v.1-Universal.bits v.2.1 s) * w (t+v.2.2)

theorem normalizedWeight_eq (w : Nat → Nat) {x : Q} {t u s : Nat}
    (h : Admissible t u s x) :
    normalizedWeight w t u s (small t s x) =
      t.choose x.1 * u.choose x.2.2 * w (full x) := by
  simp only [normalizedWeight,small,Nat.choose_symm h.2.1]
  have L : x.2.1.filter (·<t+s)=x.2.1 := by
    apply filter_true_of_mem
    intro z hz
    exact mem_range.mp (mem_sdiff.mp (h.1 hz)).1
  rw [center_bits h.1 le_rfl,L]
  have A := h.2.1
  have B := h.2.2.2.1
  rw [show t+(full x-t)=full x by omega,
    show full x-t+(t-x.1)-x.2.1.card=x.2.2 by unfold full at *; omega]

theorem transfer (w : Nat → Nat) {I : Finset Q} {t u s : Nat}
    (h : Good I t u s) :
    ∃ J : Finset (Fin (vertexList s).length), BK.Clique (Universal.edge s) J ∧
      (∑ i∈J, normalizedWeight w t u s (vertexList s)[i]) = Qscore w I t u := by
  classical
  have ExistsIndex (x : Q) (hx : x∈I) : ∃ i, (vertexList s).get i=small t s x :=
    List.get_of_mem (small_in_vertices (h.1 x hx) (h.2 x hx x hx))
  have pos : 0<(vertexList s).length := by
    let v : Q := (t,∅,0)
    have av : Admissible t u s v := by simp [Admissible,v,full]
    have cv : Qcompat t s v v := ⟨0,by omega,by simp [v,full]⟩
    exact List.length_pos_of_mem (small_in_vertices av cv)
  let f (x : Q) : Fin (vertexList s).length :=
    if hx : x∈I then Classical.choose (ExistsIndex x hx) else ⟨0,pos⟩
  have spec (x : Q) (hx : x∈I) : (vertexList s)[f x]=small t s x := by
    simpa [f,hx] using Classical.choose_spec (ExistsIndex x hx)
  have inject : Set.InjOn f (↑I : Set Q) := by
    intro x hx y hy e
    apply small_inj (h.1 x hx) (h.1 y hy)
    rw [←spec x hx,←spec y hy]
    change (vertexList s).get (f x)=(vertexList s).get (f y)
    exact congrArg (vertexList s).get e
  refine ⟨I.image f,?_,?_⟩
  · intro a ha b hb ab
    obtain ⟨x,hx,rfl⟩ := mem_image.mp ha
    obtain ⟨y,hy,rfl⟩ := mem_image.mp hb
    refine ⟨ab,?_⟩
    rw [spec x hx,spec y hy]
    exact (compat_small (h.1 x hx) (h.1 y hy)).mpr (h.2 x hx y hy)
  · rw [sum_image inject]
    unfold Qscore
    exact sum_congr rfl (fun x hx => by rw [spec x hx,normalizedWeight_eq w (h.1 x hx)])

#print axioms transfer
end IU.Slack
