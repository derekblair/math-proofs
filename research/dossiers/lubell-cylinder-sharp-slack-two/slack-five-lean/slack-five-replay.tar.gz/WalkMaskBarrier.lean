import WalkMaskHeight

namespace IU.UniversalCount
open IU.Universal

theorem mask_compat_iff (s r w j : Nat) (terminal : bits w s≤j+r) :
    compat s (r,w,j) (r,w,j)=true ↔
      ∃ h≤(maskWalk s w).length,
        max (2*(r:ℤ)) (2*(bits w s:ℤ)-s+2*((j+r-bits w s:ℕ):ℤ)) ≤
          partialHeight (maskWalk s w) h := by
  unfold compat
  simp only [List.any_eq_true, List.mem_range, Nat.lt_succ_iff, decide_eq_true_eq, maskWalk_length]
  constructor
  · rintro ⟨h, hs, hp⟩
    exact ⟨h, hs, by
      rw [partial_maskWalk s w h hs]
      exact (barrier_iff s (bits w s) r j h (bits w h) terminal).mp hp⟩
  · rintro ⟨h, hs, hp⟩
    rw [partial_maskWalk s w h hs] at hp
    exact ⟨h, hs, (barrier_iff s (bits w s) r j h (bits w h) terminal).mpr hp⟩

/-- A self-compatible graph vertex maps to the exact reflected-count bucket.
The integer barrier handles the truncated natural subtraction in the graph. -/
def mask_to_bucket (s r w j : Nat)
    (terminal : bits w s≤j+r) (cross : compat s (r,w,j) (r,w,j)=true) :
    Crosses s (max (2*(r:ℤ)) (2*(bits w s:ℤ)-s+2*((j+r-bits w s:ℕ):ℤ)))
      (2*(bits w s:ℤ)-s) :=
  ⟨maskWalk s w, maskWalk_length s w, height_maskWalk s w,
    (mask_compat_iff s r w j terminal).mp cross⟩

#print axioms mask_compat_iff
#print axioms mask_to_bucket
end IU.UniversalCount
