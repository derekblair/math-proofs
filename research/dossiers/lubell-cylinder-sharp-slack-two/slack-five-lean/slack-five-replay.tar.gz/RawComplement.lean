import RawFactor
namespace IU.Slack
open Finset
open scoped BigOperators

def complement (F : Sys) (n : ℕ) : Sys := F.image (fun A => range n \ A)

theorem flip_valid {F : Sys} {n t u : ℕ} (h : IsIU F n t u) (un : u≤n) :
    IsIU (complement F n) n u t := by
  classical
  refine ⟨?_,?_⟩
  · intro X x
    obtain ⟨A,a,rfl⟩ := mem_image.mp x
    exact sdiff_subset
  · intro X x Y y
    obtain ⟨A,a,rfl⟩ := mem_image.mp x
    obtain ⟨B,b,rfl⟩ := mem_image.mp y
    have e : (range n \ A) ∩ (range n \ B) = range n \ (A∪B) := by
      ext z; simp only [mem_inter,mem_sdiff,mem_union]; tauto
    have f : (range n \ A) ∪ (range n \ B) = range n \ (A∩B) := by
      ext z; simp only [mem_inter,mem_sdiff,mem_union]; tauto
    rw [e,f,card_sdiff_of_subset (union_subset (h.1 A a) (h.1 B b)),
      card_sdiff_of_subset (inter_subset_left.trans (h.1 A a)),card_range]
    have z := h.2 A a B b
    omega

theorem raw_flip {F : Sys} {n t u : ℕ} (h : IsIU F n t u) :
    rawSum n (complement F n)=rawSum n F := by
  classical
  have CC (A : Bag) (a : A∈F) : range n \ (range n \ A)=A := by
    ext z
    simp only [mem_sdiff]
    have L : z∈A → z∈range n := fun hz => h.1 A a hz
    tauto
  have I : Set.InjOn (fun A => range n \ A) ↑F := by
    intro A a B b E
    have K := congrArg (fun g => range n \ g) E
    rwa [CC A a,CC B b] at K
  unfold complement rawSum
  rw [sum_image I]
  apply sum_congr rfl
  intro A a
  rw [card_sdiff_of_subset (h.1 A a),card_range,Nat.choose_symm (by
    simpa using card_le_card (h.1 A a))]

#print axioms raw_flip
end IU.Slack
