import NewtonPos
import Mathlib.Algebra.Polynomial.BigOperators

namespace IU.Newton
open Polynomial Finset Function
open scoped BigOperators fwdDiff

def coeff (i k : Nat) : ℤ := (-1)^(i-k)*i.choose k

theorem piece_sum (P : (ℚ[X])[X]) (i : Nat) :
    piece P i = ∑ k∈range (i+1), coeff i k • P.eval (k:ℚ[X]) := by
  unfold piece
  rw [fwdDiff_iter_eq_sum_shift]
  simp [coeff]

theorem piece_deg (P : (ℚ[X])[X]) (i e : Nat)
    (H : ∀ k≤i,(P.eval (k:ℚ[X])).natDegree≤e) :
    (piece P i).natDegree≤e := by
  rw [piece_sum]
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro k hk
  exact (Polynomial.natDegree_smul_le _ _).trans (H k (by have := mem_range.mp hk; omega))

theorem double_sum (P : (ℚ[X])[X]) (i j : Nat) :
    ((fwdDiff (1:ℚ))^[j] (piece P i).eval) 0 =
    ∑ l∈range (j+1), coeff j l •
      ∑ k∈range (i+1), coeff i k • (P.eval (k:ℚ[X])).eval (l:ℚ) := by
  rw [fwdDiff_iter_eq_sum_shift]
  apply sum_congr rfl
  intro l ll
  simp only [zero_add,nsmul_one]
  congr 1
  rw [piece_sum,eval_finsetSum]
  apply sum_congr rfl
  intro k kl
  exact map_zsmul (evalRingHom (l:ℚ)) _ _

/-- A bounded grid of exact rational values certifies a two-variable
polynomial nonnegative on the entire nonnegative integer quadrant. -/
theorem grid_nonneg (P : (ℚ[X])[X]) (d e : Nat)
    (hd : P.natDegree≤d)
    (he : ∀ i≤d,(P.eval (i:ℚ[X])).natDegree≤e)
    (f : Nat → Nat → ℚ)
    (hf : ∀ k≤d, ∀ l≤e, (P.eval (k:ℚ[X])).eval (l:ℚ)=f k l)
    (h : ∀ i≤d, ∀ j≤e, 0 ≤ ∑ l∈range (j+1), coeff j l •
        ∑ k∈range (i+1), coeff i k • f k l) (a b : Nat) :
    0 ≤ (P.eval (a:ℚ[X])).eval (b:ℚ) := by
  apply two_variable_nonneg P d e hd
  · intro i hi
    exact piece_deg P i e (fun k hk => he k (hk.trans hi))
  · intro i hi j hj
    rw [double_sum]
    have ex := h i hi j hj
    have eq : (∑ l∈range (j+1), coeff j l •
        ∑ k∈range (i+1), coeff i k • (P.eval (k:ℚ[X])).eval (l:ℚ)) =
        ∑ l∈range (j+1), coeff j l •
        ∑ k∈range (i+1), coeff i k • f k l := by
      apply sum_congr rfl
      intro l ll
      congr 1
      apply sum_congr rfl
      intro k kk
      rw [hf k (by have := mem_range.mp kk; omega) l (by have := mem_range.mp ll; omega)]
    rwa [eq]

#print axioms grid_nonneg
end IU.Newton
