import Trace5Part16
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step272 : NodeGood bank Hit (10418677171180504,108086391056891904,0) := by
  apply use_pivot bank Hit sym noLoop 10418677171180504 108086391056891904 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10418677171180504 108086391056891904 0 ([55] : List (Fin n))=[(46447474190144472,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step271
theorem step273 : NodeGood bank Hit (1411477916439512,117093590311632896,0) := by
  apply use_pivot bank Hit sym noLoop 1411477916439512 117093590311632896 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1411477916439512 117093590311632896 0 ([53] : List (Fin n))=[(10418677171180504,108086391056891904,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step272
theorem step274 : NodeGood bank Hit (1130002939728856,117375065288343552,0) := by
  apply use_pivot bank Hit sym noLoop 1130002939728856 117375065288343552 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1130002939728856 117375065288343552 0 ([48] : List (Fin n))=[(1411477916439512,117093590311632896,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step273
theorem step275 : NodeGood bank Hit (4103032886232,118501257521660931,0) := by
  apply use_pivot bank Hit sym noLoop 4103032886232 118501257521660931 0 34 [34,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4103032886232 118501257521660931 0 ([34,50] : List (Fin n))=[(4120212755416,117375340434949123,0),(1130002939728856,117375065288343552,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step269
  · subst C; exact step274
theorem step276 : NodeGood bank Hit (136730572953310168,0,0) := by
  exact leaf bank Hit 136730572953310168 0 ⟨136730572953310168,by decide +kernel,rfl⟩
theorem step277 : NodeGood bank Hit (64672978915382232,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 64672978915382232 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 64672978915382232 72057594037927936 0 ([56] : List (Fin n))=[(136730572953310168,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step276
theorem step278 : NodeGood bank Hit (28644181896418264,108086391056891904,0) := by
  apply use_pivot bank Hit sym noLoop 28644181896418264 108086391056891904 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 28644181896418264 108086391056891904 0 ([55] : List (Fin n))=[(64672978915382232,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step277
theorem step279 : NodeGood bank Hit (10629783386936280,126100789566373888,0) := by
  apply use_pivot bank Hit sym noLoop 10629783386936280 126100789566373888 0 54 [54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10629783386936280 126100789566373888 0 ([54] : List (Fin n))=[(28644181896418264,108086391056891904,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step278
theorem step280 : NodeGood bank Hit (1622584132195288,135107988821114880,0) := by
  apply use_pivot bank Hit sym noLoop 1622584132195288 135107988821114880 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1622584132195288 135107988821114880 0 ([53] : List (Fin n))=[(10629783386936280,126100789566373888,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step279
theorem step281 : NodeGood bank Hit (496684225352664,136233888727957504,0) := by
  apply use_pivot bank Hit sym noLoop 496684225352664 136233888727957504 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 496684225352664 136233888727957504 0 ([50] : List (Fin n))=[(1622584132195288,135107988821114880,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step280
theorem step282 : NodeGood bank Hit (215209248642008,136515363704668160,0) := by
  apply use_pivot bank Hit sym noLoop 215209248642008 136515363704668160 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 215209248642008 136515363704668160 0 ([48] : List (Fin n))=[(496684225352664,136233888727957504,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step281
theorem step283 : NodeGood bank Hit (74471760286680,136656101193023488,0) := by
  apply use_pivot bank Hit sym noLoop 74471760286680 136656101193023488 0 47 [47] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 74471760286680 136656101193023488 0 ([47] : List (Fin n))=[(215209248642008,136515363704668160,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step282
theorem step284 : NodeGood bank Hit (144840504464344,136515363704668160,70368744177664) := by
  apply use_pivot bank Hit sym noLoop 144840504464344 136515363704668160 70368744177664 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 144840504464344 136515363704668160 70368744177664 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step285 : NodeGood bank Hit (18018501525591000,118500965195186176,211106232532992) := by
  apply use_pivot bank Hit sym noLoop 18018501525591000 118500965195186176 211106232532992 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18018501525591000 118500965195186176 211106232532992 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step286 : NodeGood bank Hit (4103016109016,136726762280453123,0) := by
  apply use_pivot bank Hit sym noLoop 4103016109016 136726762280453123 0 24 [24,46,47,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4103016109016 136726762280453123 0 ([24,46,47,54] : List (Fin n))=[(4103032886232,118501257521660931,0),(74471760286680,136656101193023488,0),(144840504464344,136515363704668160,70368744177664),(18018501525591000,118500965195186176,211106232532992)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step275
  · subst C; exact step283
  · subst C; exact step284
  · subst C; exact step285
theorem step287 : NodeGood bank Hit (1903992853464,136728961303710723,0) := by
  apply use_pivot bank Hit sym noLoop 1903992853464 136728961303710723 0 41 [11,41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1903992853464 136728961303710723 0 ([11,41] : List (Fin n))=[(1903992855512,45317763593667587,0),(4103016109016,136726762280453123,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step251
  · subst C; exact step286
end IU.Trace5
