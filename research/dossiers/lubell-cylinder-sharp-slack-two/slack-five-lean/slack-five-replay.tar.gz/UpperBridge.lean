import ProfileTransfer
import Mathlib.Data.Finset.Powerset

namespace BK
open Finset

theorem extend_to_max {α : Type} [Fintype α] [DecidableEq α]
    {E : α → α → Prop} {F : Finset α} (cl : Clique E F) :
    ∃ Q, MaxClique E Q ∧ F⊆Q := by
  classical
  let candidates := (univ : Finset α).powerset.filter fun Q => Clique E Q ∧ F⊆Q
  have H (Q : Finset α) : Q∈candidates ↔ Clique E Q ∧ F⊆Q := by simp [candidates]
  obtain ⟨Q,qa,qm⟩ := exists_max_image candidates Finset.card ⟨F,(H F).mpr ⟨cl,Subset.rfl⟩⟩
  obtain ⟨qc,fq⟩ := (H Q).mp qa
  refine ⟨Q,⟨qc,?_⟩,fq⟩
  intro U uc qu
  have uCan : U∈candidates := (H U).mpr ⟨uc,fq.trans qu⟩
  exact (eq_of_subset_of_card_le qu (qm U uCan)).ge

end BK

namespace IU.Slack
open Finset IU.Universal
open scoped BigOperators

/-- Upper certification needs only evaluate the list produced by the
kernel-proved clique search, not reason again about original set families. -/
theorem bounded_by_enumeration (w : ℕ → ℕ) {t u s k : ℕ}
    (ht : 0<t) (H : ∀ J∈listCl s,
      ∑ i∈J, normalizedWeight w t u s (vertexList s)[i] ≤ k)
    {F : Sys} (V : IsIU F (t+u+s) t u) : objective w F≤k := by
  obtain ⟨I,g,le⟩ := original_to_graph w F ht V
  obtain ⟨J,jc,js⟩ := transfer w g
  obtain ⟨Q,q,sub⟩ := BK.extend_to_max jc
  have h := sum_le_sum_of_subset (f:=fun i => normalizedWeight w t u s (vertexList s)[i]) sub
  exact le.trans (js ▸ h.trans (H Q (listCl_covers s q)))

#print axioms bounded_by_enumeration
end IU.Slack
