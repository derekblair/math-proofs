import Sharp5Grid0Compare14
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot60 : ∀ i j : Fin 8, dot data histograms[60]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare60 : ∀ i j : Fin 8, sumTable data 64669680380507096 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts60, hist_sound data _ _ counts6] <;> exact dot60 i j
theorem dot61 : ∀ i j : Fin 8, dot data histograms[61]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare61 : ∀ i j : Fin 8, sumTable data 65232080578278360 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts61, hist_sound data _ _ counts6] <;> exact dot61 i j
theorem dot62 : ∀ i j : Fin 8, dot data histograms[62]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare62 : ∀ i j : Fin 8, sumTable data 117097985402295256 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts62, hist_sound data _ _ counts6] <;> exact dot62 i j
theorem dot63 : ∀ i j : Fin 8, dot data histograms[63]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare63 : ∀ i j : Fin 8, sumTable data 117102383448805848 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts63, hist_sound data _ _ counts6] <;> exact dot63 i j
end IU.Sharp5.Cone0
