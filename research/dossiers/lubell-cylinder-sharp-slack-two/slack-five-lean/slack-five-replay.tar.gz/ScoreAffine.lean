import ScorePoly
namespace IU.PolyCert
open Polynomial Finset
open scoped BigOperators

theorem cast_eval_rise_deg (P : Bi) (k a : ℕ) (h : (P.eval (a:ℚ[X])).natDegree≤1) :
    ((rise P k).eval (a:ℚ[X])).natDegree≤k := by
  simp only [rise,eval_comp,eval_add,eval_one]
  have aux : (ascPochhammer (ℚ[X]) k).eval (P.eval (a:ℚ[X])+1) =
      (ascPochhammer ℚ k).comp (P.eval (a:ℚ[X])+1) := by
    rw [← ascPochhammer_map (C : ℚ →+* ℚ[X]),eval_map]
    rfl
  rw [aux]
  refine natDegree_comp_le.trans ?_
  rw [ascPochhammer_natDegree]
  have hj : (P.eval (a:ℚ[X])+1).natDegree≤1 := (natDegree_add_le _ _).trans (by simp [h])
  simpa using Nat.mul_le_mul_left k hj

structure Coeff where
  base : ℕ
  left : ℕ
  right : ℕ
  deriving Inhabited

def param (C : Coeff) (a b : ℕ) : ℕ := C.base+C.left*a+C.right*b
noncomputable def parameter (c : Coeff) : Bi := aff c.base c.left c.right

structure Shape where
  slack : ℕ
  removed : ℕ
  outside : ℕ
  rankExcess : ℕ
  deriving Inhabited

def bound (z : Shape) : Nat := z.removed+z.outside+(z.rankExcess+(z.slack-z.rankExcess))

noncomputable def scoreP (T U : Coeff) (v : Shape) : Bi :=
  (fall (parameter T) v.removed * fall (parameter U) v.outside) *
    (rise (parameter T) v.rankExcess * rise (parameter U) (v.slack-v.rankExcess))

def scoreN (t u : ℕ) (z : Shape) : ℕ :=
  (t.choose z.removed * u.choose z.outside) *
    ((t+1).ascFactorial z.rankExcess * (u+1).ascFactorial (z.slack-z.rankExcess))

theorem score_eval (T U : Coeff) (v : Shape) (a b : ℕ) :
    ((scoreP T U v).eval (a:ℚ[X])).eval (b:ℚ) =
      (scoreN (param T a b) (param U a b) v:ℚ) := by
  have hT : ((parameter T).eval (a:ℚ[X])).eval (b:ℚ)=((param T a b:ℕ):ℚ) :=
    aff_eval _ _ _ _ _
  have hU : ((parameter U).eval (a:ℚ[X])).eval (b:ℚ)=((param U a b:ℕ):ℚ) :=
    aff_eval _ _ _ _ _
  simp only [scoreP,eval_mul,scoreN,Nat.cast_mul]
  rw [fall_eval _ _ _ _ _ hT,fall_eval _ _ _ _ _ hU,
      rise_eval _ _ _ _ _ hT,rise_eval _ _ _ _ _ hU]

lemma deg_mul_le {R : Type*} [Semiring R] {A B : R[X]} {a b : ℕ}
    (ha : A.natDegree≤a) (hb : B.natDegree≤b) : (A*B).natDegree≤a+b :=
  natDegree_mul_le.trans (Nat.add_le_add ha hb)

theorem score_deg (T U : Coeff) (v : Shape) : (scoreP T U v).natDegree≤bound v := by
  unfold scoreP bound
  apply deg_mul_le (deg_mul_le (fall_degree _ _ (aff_degree _ _ _))
    (fall_degree _ _ (aff_degree _ _ _)))
  exact deg_mul_le (rise_degree _ _ (aff_degree _ _ _)) (rise_degree _ _ (aff_degree _ _ _))

theorem score_inner_deg (T U : Coeff) (v : Shape) (a : ℕ) :
    ((scoreP T U v).eval (a:ℚ[X])).natDegree≤bound v := by
  simp only [scoreP,bound,eval_mul]
  apply deg_mul_le (deg_mul_le
    (cast_eval_fall_deg _ _ _ (aff_eval_degree _ _ _ _))
    (cast_eval_fall_deg _ _ _ (aff_eval_degree _ _ _ _)))
  exact deg_mul_le (cast_eval_rise_deg _ _ _ (aff_eval_degree _ _ _ _))
    (cast_eval_rise_deg _ _ _ (aff_eval_degree _ _ _ _))

#print axioms score_eval
#print axioms score_deg
#print axioms score_inner_deg
end IU.PolyCert
