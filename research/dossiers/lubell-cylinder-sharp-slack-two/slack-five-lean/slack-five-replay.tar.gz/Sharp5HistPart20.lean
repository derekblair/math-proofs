import Sharp5HistPart19
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts100 : ∀ q : Fin 20, ((members n 3432094481943449856).filter (fun v => code v=q)).card=(histograms[100]!)[q.val]! := by decide +kernel
theorem counts101 : ∀ q : Fin 20, ((members n 3433220364670423296).filter (fun v => code v=q)).card=(histograms[101]!)[q.val]! := by decide +kernel
theorem counts102 : ∀ q : Fin 20, ((members n 3435472160189141248).filter (fun v => code v=q)).card=(histograms[102]!)[q.val]! := by decide +kernel
theorem counts103 : ∀ q : Fin 20, ((members n 3451234763163128064).filter (fun v => code v=q)).card=(histograms[103]!)[q.val]! := by decide +kernel
theorem counts104 : ∀ q : Fin 20, ((members n 4592897263349616896).filter (fun v => code v=q)).card=(histograms[104]!)[q.val]! := by decide +kernel
end IU.Sharp5
