import Sharp5HistPart7
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts40 : ∀ q : Fin 20, ((members n 19633479896626168).filter (fun v => code v=q)).card=(histograms[40]!)[q.val]! := by decide +kernel
theorem counts41 : ∀ q : Fin 20, ((members n 28640677205210072).filter (fun v => code v=q)).card=(histograms[41]!)[q.val]! := by decide +kernel
theorem counts42 : ∀ q : Fin 20, ((members n 45036543073714136).filter (fun v => code v=q)).card=(histograms[42]!)[q.val]! := by decide +kernel
theorem counts43 : ∀ q : Fin 20, ((members n 45037092829495256).filter (fun v => code v=q)).card=(histograms[43]!)[q.val]! := by decide +kernel
theorem counts44 : ∀ q : Fin 20, ((members n 45038192341114840).filter (fun v => code v=q)).card=(histograms[44]!)[q.val]! := by decide +kernel
end IU.Sharp5
