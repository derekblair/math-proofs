import Trace5Part36
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step592 : NodeGood bank Hit (4503848984072448,4588956364319138304,0) := by
  apply use_pivot bank Hit sym noLoop 4503848984072448 4588956364319138304 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4503848984072448 4588956364319138304 0 ([24] : List (Fin n))=[(4503849000849664,4588956364302361088,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step591
theorem step593 : NodeGood bank Hit (1152921753963548928,3436034859712291328,4503599627370496) := by
  apply use_pivot bank Hit sym noLoop 1152921753963548928 3436034859712291328 4503599627370496 52 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1152921753963548928 3436034859712291328 4503599627370496 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step594 : NodeGood bank Hit (249356701952,4611685766383709915,0) := by
  apply use_pivot bank Hit sym noLoop 249356701952 4611685766383709915 0 30 [30,52,60] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 249356701952 4611685766383709915 0 ([30,52,60] : List (Fin n))=[(250430443776,3454260661075750619,0),(4503848984072448,4588956364319138304,0),(1152921753963548928,3436034859712291328,4503599627370496)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h
  · subst C; exact step562
  · subst C; exact step592
  · subst C; exact step593
theorem step595 : NodeGood bank Hit (111917748480,4611685903823187675,0) := by
  apply use_pivot bank Hit sym noLoop 111917748480 4611685903823187675 0 37 [19,37] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111917748480 4611685903823187675 0 ([19,37] : List (Fin n))=[(111918272768,9013544280698587,0),(249356701952,4611685766383709915,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step162
  · subst C; exact step594
theorem step596 : NodeGood bank Hit (112320401664,6345026481883,4) := by
  apply use_pivot bank Hit sym noLoop 112320401664 6345026481883 4 2 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 112320401664 6345026481883 4 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step597 : NodeGood bank Hit (111783530752,4611685904494276319,0) := by
  apply use_pivot bank Hit sym noLoop 111783530752 4611685904494276319 0 27 [2,27,29] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530752 4611685904494276319 0 ([2,27,29] : List (Fin n))=[(111783530756,6345563352795,0),(111917748480,4611685903823187675,0),(112320401664,6345026481883,4)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h
  · subst C; exact step127
  · subst C; exact step595
  · subst C; exact step596
theorem step598 : NodeGood bank Hit (43064054016,4611685973215850207,0) := by
  apply use_pivot bank Hit sym noLoop 43064054016 4611685973215850207 0 36 [21,36] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 43064054016 4611685973215850207 0 ([21,36] : List (Fin n))=[(43066151168,1188317831067610847,0),(111783530752,4611685904494276319,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step100
  · subst C; exact step597
theorem step599 : NodeGood bank Hit (45144428800,21885527446531807,32) := by
  apply use_pivot bank Hit sym noLoop 45144428800 21885527446531807 32 5 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 45144428800 21885527446531807 32 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step600 : NodeGood bank Hit (42996945152,4611685975430442751,0) := by
  apply use_pivot bank Hit sym noLoop 42996945152 4611685975430442751 0 26 [5,26,31] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 42996945152 4611685975430442751 0 ([5,26,31] : List (Fin n))=[(42996945184,21885529594015455,0),(43064054016,4611685973215850207,0),(45144428800,21885527446531807,32)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h
  · subst C; exact step37
  · subst C; exact step598
  · subst C; exact step599
theorem step601 : NodeGood bank Hit (8637206784,4611686009790181119,0) := by
  apply use_pivot bank Hit sym noLoop 8637206784 4611686009790181119 0 35 [35] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8637206784 4611686009790181119 0 ([35] : List (Fin n))=[(42996945152,4611685975430442751,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step600
theorem step602 : NodeGood bank Hit (47272192,4611686018380115711,0) := by
  apply use_pivot bank Hit sym noLoop 47272192 4611686018380115711 0 33 [33] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 47272192 4611686018380115711 0 ([33] : List (Fin n))=[(8637206784,4611686009790181119,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step601
theorem step603 : NodeGood bank Hit (13717760,4611686018413670143,0) := by
  apply use_pivot bank Hit sym noLoop 13717760 4611686018413670143 0 25 [25] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 13717760 4611686018413670143 0 ([25] : List (Fin n))=[(47272192,4611686018380115711,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step602
theorem step604 : NodeGood bank Hit (5329152,4611686018422058751,0) := by
  apply use_pivot bank Hit sym noLoop 5329152 4611686018422058751 0 23 [23] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 5329152 4611686018422058751 0 ([23] : List (Fin n))=[(13717760,4611686018413670143,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step603
theorem step605 : NodeGood bank Hit (1134848,4611686018426253055,0) := by
  apply use_pivot bank Hit sym noLoop 1134848 4611686018426253055 0 22 [22] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1134848 4611686018426253055 0 ([22] : List (Fin n))=[(5329152,4611686018422058751,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step604
theorem step606 : NodeGood bank Hit (86272,4611686018427301631,0) := by
  apply use_pivot bank Hit sym noLoop 86272 4611686018427301631 0 20 [20] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 86272 4611686018427301631 0 ([20] : List (Fin n))=[(1134848,4611686018426253055,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step605
theorem step607 : NodeGood bank Hit (20736,4611686018427367167,0) := by
  apply use_pivot bank Hit sym noLoop 20736 4611686018427367167 0 16 [16] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 20736 4611686018427367167 0 ([16] : List (Fin n))=[(86272,4611686018427301631,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step606
end IU.Trace5
