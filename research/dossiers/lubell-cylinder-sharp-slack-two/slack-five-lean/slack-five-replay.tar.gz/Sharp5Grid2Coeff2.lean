import Sharp5Grid2Coeff1
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry4 : ∀ i j : Fin 8, vcoeff T U shapeBank[4]! i.val j.val=(data[4]!)[8*i.val+j.val]! := by decide +kernel
theorem entry5 : ∀ i j : Fin 8, vcoeff T U shapeBank[5]! i.val j.val=(data[5]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone2
