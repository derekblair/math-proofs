import Trace5Part13
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step224 : NodeGood bank Hit (1126704404853720,45317471250415616,0) := by
  apply use_pivot bank Hit sym noLoop 1126704404853720 45317471250415616 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1126704404853720 45317471250415616 0 ([48] : List (Fin n))=[(1408179381564376,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step223
theorem step225 : NodeGood bank Hit (804498011096,46443663483735043,0) := by
  apply use_pivot bank Hit sym noLoop 804498011096 46443663483735043 0 10 [10,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 804498011096 46443663483735043 0 ([10,50] : List (Fin n))=[(804498012120,45317763576891395,0),(1126704404853720,45317471250415616,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step220
  · subst C; exact step224
theorem step226 : NodeGood bank Hit (64669680380507096,0,0) := by
  exact leaf bank Hit 64669680380507096 0 ⟨64669680380507096,by decide +kernel,rfl⟩
theorem step227 : NodeGood bank Hit (28640883361543128,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 28640883361543128 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 28640883361543128 36028797018963968 0 ([55] : List (Fin n))=[(64669680380507096,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step226
theorem step228 : NodeGood bank Hit (10626484852061144,54043195528445952,0) := by
  apply use_pivot bank Hit sym noLoop 10626484852061144 54043195528445952 0 54 [54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10626484852061144 54043195528445952 0 ([54] : List (Fin n))=[(28640883361543128,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step227
theorem step229 : NodeGood bank Hit (1619285597320152,63050394783186944,0) := by
  apply use_pivot bank Hit sym noLoop 1619285597320152 63050394783186944 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1619285597320152 63050394783186944 0 ([53] : List (Fin n))=[(10626484852061144,54043195528445952,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step228
theorem step230 : NodeGood bank Hit (493385690477528,64176294690029568,0) := by
  apply use_pivot bank Hit sym noLoop 493385690477528 64176294690029568 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 493385690477528 64176294690029568 0 ([50] : List (Fin n))=[(1619285597320152,63050394783186944,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step229
theorem step231 : NodeGood bank Hit (211910713766872,64457769666740224,0) := by
  apply use_pivot bank Hit sym noLoop 211910713766872 64457769666740224 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 211910713766872 64457769666740224 0 ([48] : List (Fin n))=[(493385690477528,64176294690029568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step230
theorem step232 : NodeGood bank Hit (71173225411544,64598507155095552,0) := by
  apply use_pivot bank Hit sym noLoop 71173225411544 64598507155095552 0 47 [47] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 71173225411544 64598507155095552 0 ([47] : List (Fin n))=[(211910713766872,64457769666740224,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step231
theorem step233 : NodeGood bank Hit (141541969589208,64457769666740224,70368744177664) := by
  apply use_pivot bank Hit sym noLoop 141541969589208 64457769666740224 70368744177664 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 141541969589208 64457769666740224 70368744177664 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step234 : NodeGood bank Hit (18015202990715864,46443371157258240,211106232532992) := by
  apply use_pivot bank Hit sym noLoop 18015202990715864 46443371157258240 211106232532992 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18015202990715864 46443371157258240 211106232532992 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step235 : NodeGood bank Hit (804481233880,64669168242527235,0) := by
  apply use_pivot bank Hit sym noLoop 804481233880 64669168242527235 0 24 [24,46,47,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 804481233880 64669168242527235 0 ([24,46,47,54] : List (Fin n))=[(804498011096,46443663483735043,0),(71173225411544,64598507155095552,0),(141541969589208,64457769666740224,70368744177664),(18015202990715864,46443371157258240,211106232532992)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step225
  · subst C; exact step232
  · subst C; exact step233
  · subst C; exact step234
theorem step236 : NodeGood bank Hit (254725419992,65232667951926275,0) := by
  apply use_pivot bank Hit sym noLoop 254725419992 65232667951926275 0 15 [15,39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725419992 65232667951926275 0 ([15,39] : List (Fin n))=[(254725452760,65232118196079619,0),(804481233880,64669168242527235,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step206
  · subst C; exact step235
theorem step237 : NodeGood bank Hit (2196336107483,0,0) := by
  exact leaf bank Hit 2196336107483 0 ⟨2196336107483,by decide +kernel,rfl⟩
theorem step238 : NodeGood bank Hit (2196067672027,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 2196067672027 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2196067672027 268435456 0 ([28] : List (Fin n))=[(2196336107483,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step237
theorem step239 : NodeGood bank Hit (2196067672025,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 2196067672025 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2196067672025 268435458 0 ([1] : List (Fin n))=[(2196067672027,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step238
end IU.Trace5
