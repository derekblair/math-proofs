import Trace5Part21
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step352 : NodeGood bank Hit (298789328999768,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 298789328999768 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 298789328999768 45035996273704960 0 ([53] : List (Fin n))=[(9305988583740760,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step351
theorem step353 : NodeGood bank Hit (17314352289112,45317746397020163,0) := by
  apply use_pivot bank Hit sym noLoop 17314352289112 45317746397020163 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17314352289112 45317746397020163 0 ([38,48] : List (Fin n))=[(17589230196056,45035996542402563,0),(298789328999768,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step349
  · subst C; exact step352
theorem step354 : NodeGood bank Hit (117111179541827928,0,0) := by
  exact leaf bank Hit 117111179541827928 0 ⟨117111179541827928,by decide +kernel,rfl⟩
theorem step355 : NodeGood bank Hit (117392379640631640,0,0) := by
  exact leaf bank Hit 117392379640631640 0 ⟨117392379640631640,by decide +kernel,rfl⟩
theorem step356 : NodeGood bank Hit (117110904663920984,281749854617600,0) := by
  apply use_pivot bank Hit sym noLoop 117110904663920984 281749854617600 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 117110904663920984 281749854617600 0 ([38,48] : List (Fin n))=[(117111179541827928,0,0),(117392379640631640,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step354
  · subst C; exact step355
theorem step357 : NodeGood bank Hit (81082107644957016,36310546873581568,0) := by
  apply use_pivot bank Hit sym noLoop 81082107644957016 36310546873581568 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 81082107644957016 36310546873581568 0 ([55] : List (Fin n))=[(117110904663920984,281749854617600,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step356
theorem step358 : NodeGood bank Hit (72074908390216024,45317746128322560,0) := by
  apply use_pivot bank Hit sym noLoop 72074908390216024 45317746128322560 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 72074908390216024 45317746128322560 0 ([53] : List (Fin n))=[(81082107644957016,36310546873581568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step357
theorem step359 : NodeGood bank Hit (17314352288088,117375340434949123,0) := by
  apply use_pivot bank Hit sym noLoop 17314352288088 117375340434949123 0 10 [10,56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17314352288088 117375340434949123 0 ([10,56] : List (Fin n))=[(17314352289112,45317746397020163,0),(72074908390216024,45317746128322560,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step353
  · subst C; exact step358
theorem step360 : NodeGood bank Hit (118518262367605080,0,0) := by
  exact leaf bank Hit 118518262367605080 0 ⟨118518262367605080,by decide +kernel,rfl⟩
theorem step361 : NodeGood bank Hit (46460668329677144,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 46460668329677144 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 46460668329677144 72057594037927936 0 ([56] : List (Fin n))=[(118518262367605080,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step360
theorem step362 : NodeGood bank Hit (10431871310713176,108086391056891904,0) := by
  apply use_pivot bank Hit sym noLoop 10431871310713176 108086391056891904 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10431871310713176 108086391056891904 0 ([55] : List (Fin n))=[(46460668329677144,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step361
theorem step363 : NodeGood bank Hit (1424672055972184,117093590311632896,0) := by
  apply use_pivot bank Hit sym noLoop 1424672055972184 117093590311632896 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1424672055972184 117093590311632896 0 ([53] : List (Fin n))=[(10431871310713176,108086391056891904,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step362
theorem step364 : NodeGood bank Hit (1143197079261528,117375065288343552,0) := by
  apply use_pivot bank Hit sym noLoop 1143197079261528 117375065288343552 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1143197079261528 117375065288343552 0 ([48] : List (Fin n))=[(1424672055972184,117093590311632896,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step363
theorem step365 : NodeGood bank Hit (17297172418904,118501257521660931,0) := by
  apply use_pivot bank Hit sym noLoop 17297172418904 118501257521660931 0 34 [34,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17297172418904 118501257521660931 0 ([34,50] : List (Fin n))=[(17314352288088,117375340434949123,0),(1143197079261528,117375065288343552,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step359
  · subst C; exact step364
theorem step366 : NodeGood bank Hit (136532660860309848,0,0) := by
  exact leaf bank Hit 136532660860309848 0 ⟨136532660860309848,by decide +kernel,rfl⟩
theorem step367 : NodeGood bank Hit (64475066822381912,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 64475066822381912 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 64475066822381912 72057594037927936 0 ([56] : List (Fin n))=[(136532660860309848,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step366
end IU.Trace5
