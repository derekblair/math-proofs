import BronKerbosch
import Mathlib.Data.Finset.Sort

namespace BK
open Finset
variable {α : Type} [LinearOrder α]
variable (E : α → α → Prop) [DecidableRel E]

theorem branch_budget (noLoop : ∀ v, ¬ E v v) {R P X : Finset α}
    (vs : List α) (hvs : ∀ v∈vs, v∈P) (dn : vs.Nodup) :
    ∀ i∈build E R P X vs, i.2.1.card<P.card := by
  induction vs generalizing P X with
  | nil => simp [build]
  | cons v vs ih =>
    intro j jh
    have mv := hvs v List.mem_cons_self
    rcases List.mem_cons.mp jh with a|a
    · subst j
      have sub : P.filter (E v) ⊆ P.erase v := by
        intro y py
        obtain ⟨yp,he⟩ := mem_filter.mp py
        exact mem_erase.mpr ⟨fun e => noLoop v (e ▸ he),yp⟩
      exact (card_le_card sub).trans_lt (card_erase_lt_of_mem mv)
    · have n : ∀ y∈vs, y∈P.erase v := by
        intro y h
        exact mem_erase.mpr ⟨fun e => (List.nodup_cons.mp dn).1 (e ▸ h),
          hvs _ (List.mem_cons_of_mem _ h)⟩
      exact (ih n (List.nodup_cons.mp dn).2 j a).trans (card_erase_lt_of_mem mv)

def choices (P X : Finset α) (hp : P.Nonempty) : Finset α :=
  P.filter (fun w => ¬ E ((P∪X).min' (by
    obtain ⟨v,hv⟩ := hp
    exact ⟨v,mem_union.mpr (Or.inl hv)⟩)) w)

def enumerate : Nat → Finset α → Finset α → Finset α → List (Finset α)
  | 0,R,_,_ => [R]
  | k+1,R,P,X => if hp : P.Nonempty then
       (build E R P X ((choices E P X hp).sort)).flatMap
         (fun i => enumerate k i.1 i.2.1 i.2.2)
     else [R]

theorem enumerate_covers (sym : Symmetric E) (noLoop : ∀ v, ¬ E v v) (k : Nat)
    {Q R P X : Finset α} (mq : MaxClique E Q)
    (c : Covers Q R P X) (adj : NeighborsOf E R P X) (sz : P.card≤k) :
    Q∈enumerate E k R P X := by
  induction k generalizing R P X with
  | zero =>
    have p : P=∅ := card_eq_zero.mp (Nat.eq_zero_of_le_zero sz)
    have eq : Q=R := Subset.antisymm (by simpa [p] using c.2.1) c.1
    simp [enumerate,eq]
  | succ k ih =>
    by_cases pos : P.Nonempty
    · rw [enumerate,dif_pos pos]
      let v := (P∪X).min' (by
        obtain ⟨v,hv⟩ := pos
        exact ⟨v,mem_union.mpr (Or.inl hv)⟩)
      have vm : v∈P∪X := min'_mem _ _
      obtain ⟨w,wq,wp,wn⟩ := pivot_branch sym noLoop mq c.2.1 (adj _ vm)
      let vs := (choices E P X pos).sort
      have wv : w∈vs := by simpa [vs,choices,v] using And.intro wp wn
      obtain ⟨i,ij,ic⟩ := build_cover E mq.1 c vs ⟨w,wv,wq⟩
      have sb : ∀ y∈vs, y∈P := by
        intro y h
        have : y∈choices E P X pos := by simpa [vs] using h
        exact (mem_filter.mp this).1
      have nd : vs.Nodup := sort_nodup _ _
      have ad := build_neighbors E sym adj vs sb nd i ij
      have bd := branch_budget E noLoop vs sb nd i ij
      exact List.mem_flatMap.mpr ⟨i,ij,ih ic ad (by omega)⟩
    · have emp := not_nonempty_iff_eq_empty.mp pos
      have eq : Q=R := Subset.antisymm (by simpa [emp] using c.2.1) c.1
      simp [enumerate,pos,eq]

#print axioms enumerate_covers
end BK
