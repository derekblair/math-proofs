import Trace5Part19
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step320 : NodeGood bank Hit (81073311551934936,36310546873581568,0) := by
  apply use_pivot bank Hit sym noLoop 81073311551934936 36310546873581568 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 81073311551934936 36310546873581568 0 ([55] : List (Fin n))=[(117102108570898904,281749854617600,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step319
theorem step321 : NodeGood bank Hit (72066112297193944,45317746128322560,0) := by
  apply use_pivot bank Hit sym noLoop 72066112297193944 45317746128322560 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 72066112297193944 45317746128322560 0 ([53] : List (Fin n))=[(81073311551934936,36310546873581568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step320
theorem step322 : NodeGood bank Hit (72063913273938392,45319945151578112,0) := by
  apply use_pivot bank Hit sym noLoop 72063913273938392 45319945151578112 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 72063913273938392 45319945151578112 0 ([41] : List (Fin n))=[(72066112297193944,45317746128322560,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step321
theorem step323 : NodeGood bank Hit (6319236010456,117377539458206723,0) := by
  apply use_pivot bank Hit sym noLoop 6319236010456 117377539458206723 0 10 [10,56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6319236010456 117377539458206723 0 ([10,56] : List (Fin n))=[(6319236011480,45319945420277763,0),(72063913273938392,45319945151578112,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step316
  · subst C; exact step322
theorem step324 : NodeGood bank Hit (118509466274583000,0,0) := by
  exact leaf bank Hit 118509466274583000 0 ⟨118509466274583000,by decide +kernel,rfl⟩
theorem step325 : NodeGood bank Hit (46451872236655064,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 46451872236655064 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 46451872236655064 72057594037927936 0 ([56] : List (Fin n))=[(118509466274583000,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step324
theorem step326 : NodeGood bank Hit (10423075217691096,108086391056891904,0) := by
  apply use_pivot bank Hit sym noLoop 10423075217691096 108086391056891904 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10423075217691096 108086391056891904 0 ([55] : List (Fin n))=[(46451872236655064,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step325
theorem step327 : NodeGood bank Hit (1415875962950104,117093590311632896,0) := by
  apply use_pivot bank Hit sym noLoop 1415875962950104 117093590311632896 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1415875962950104 117093590311632896 0 ([53] : List (Fin n))=[(10423075217691096,108086391056891904,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step326
theorem step328 : NodeGood bank Hit (1134400986239448,117375065288343552,0) := by
  apply use_pivot bank Hit sym noLoop 1134400986239448 117375065288343552 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1134400986239448 117375065288343552 0 ([48] : List (Fin n))=[(1415875962950104,117093590311632896,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step327
theorem step329 : NodeGood bank Hit (1132201962983896,117377264311599104,0) := by
  apply use_pivot bank Hit sym noLoop 1132201962983896 117377264311599104 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1132201962983896 117377264311599104 0 ([41] : List (Fin n))=[(1134400986239448,117375065288343552,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step328
theorem step330 : NodeGood bank Hit (6302056141272,118503456544918531,0) := by
  apply use_pivot bank Hit sym noLoop 6302056141272 118503456544918531 0 34 [34,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6302056141272 118503456544918531 0 ([34,50] : List (Fin n))=[(6319236010456,117377539458206723,0),(1132201962983896,117377264311599104,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step323
  · subst C; exact step329
theorem step331 : NodeGood bank Hit (136523864767287768,0,0) := by
  exact leaf bank Hit 136523864767287768 0 ⟨136523864767287768,by decide +kernel,rfl⟩
theorem step332 : NodeGood bank Hit (64466270729359832,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 64466270729359832 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 64466270729359832 72057594037927936 0 ([56] : List (Fin n))=[(136523864767287768,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step331
theorem step333 : NodeGood bank Hit (28437473710395864,108086391056891904,0) := by
  apply use_pivot bank Hit sym noLoop 28437473710395864 108086391056891904 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 28437473710395864 108086391056891904 0 ([55] : List (Fin n))=[(64466270729359832,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step332
theorem step334 : NodeGood bank Hit (19430274455654872,117093590311632896,0) := by
  apply use_pivot bank Hit sym noLoop 19430274455654872 117093590311632896 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 19430274455654872 117093590311632896 0 ([53] : List (Fin n))=[(28437473710395864,108086391056891904,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step333
theorem step335 : NodeGood bank Hit (18304374548812248,118219490218475520,0) := by
  apply use_pivot bank Hit sym noLoop 18304374548812248 118219490218475520 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18304374548812248 118219490218475520 0 ([50] : List (Fin n))=[(19430274455654872,117093590311632896,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step334
end IU.Trace5
