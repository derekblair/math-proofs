import WeightedGraph
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Tactic.FieldSimp
import Mathlib.Data.Rat.Cast.Order
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

namespace IU.Slack
open Finset
open scoped BigOperators

def scaledWeight (t u s k : ℕ) : ℕ :=
  (t+1).ascFactorial (k-t) * (u+1).ascFactorial (t+s-k)

def rawSum (n : ℕ) (F : Sys) : ℚ :=
  ∑ A∈F, ((n.choose A.card : ℚ))⁻¹

def normalization (t u s : ℕ) : ℚ :=
  ((t.factorial:ℚ)*(u.factorial:ℚ)) / (((t+u+s).factorial:ℚ))

theorem raw_member_factor {t u s k : ℕ} (lo : t≤k) (hi : k≤t+s) :
    (((t+u+s).choose k : ℚ))⁻¹ =
      normalization t u s * (scaledWeight t u s k:ℚ) := by
  let n := t+u+s
  have kn : k≤n := by dsimp [n]; omega
  have posn : (n.factorial:ℚ)≠0 := by positivity
  have posc : (n.choose k:ℚ)≠0 := by exact_mod_cast (Nat.choose_pos kn).ne'
  have e := congrArg (fun x : ℕ => (x:ℚ)) (Nat.choose_mul_factorial_mul_factorial kn)
  push_cast at e
  have ah := congrArg (fun x : ℕ => (x:ℚ)) (Nat.factorial_mul_ascFactorial t (k-t))
  have bh := congrArg (fun x : ℕ => (x:ℚ)) (Nat.factorial_mul_ascFactorial u (t+s-k))
  push_cast at ah bh
  rw [show t+(k-t)=k by omega] at ah
  rw [show u+(t+s-k)=n-k by dsimp [n]; omega] at bh
  unfold normalization scaledWeight
  change (n.choose k:ℚ)⁻¹ = ((t.factorial:ℚ)*(u.factorial:ℚ))/(n.factorial:ℚ) *
    ((t+1).ascFactorial (k-t)*(u+1).ascFactorial (t+s-k):ℕ)
  push_cast
  calc
    _ = ((k.factorial:ℚ)*((n-k).factorial:ℚ))/(n.factorial:ℚ) := by
      field_simp
      simpa only [mul_assoc] using e.symm
    _ = _ := by rw [←ah,←bh]; ring

theorem raw_factor {F : Sys} {t u s : ℕ} (ok : IsIU F (t+u+s) t u) :
    rawSum (t+u+s) F = normalization t u s * (objective (scaledWeight t u s) F:ℚ) := by
  unfold rawSum objective
  rw [Nat.cast_sum,mul_sum]
  apply sum_congr rfl
  intro A ha
  have low : t≤A.card := by simpa using (ok.2 A ha A ha).1
  have hi : A.card≤t+s := by simpa [show t+u+s-u=t+s by omega] using (ok.2 A ha A ha).2
  exact raw_member_factor low hi

theorem norm_positive (t u s : ℕ) : 0<normalization t u s := by
  unfold normalization
  positivity

#print axioms raw_factor
end IU.Slack
