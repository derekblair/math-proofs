import Sharp5Grid0Compare21
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot88 : ∀ i j : Fin 8, dot data histograms[88]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare88 : ∀ i j : Fin 8, sumTable data 713046189721866568 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts88, hist_sound data _ _ counts6] <;> exact dot88 i j
theorem dot89 : ∀ i j : Fin 8, dot data histograms[89]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare89 : ∀ i j : Fin 8, sumTable data 713112160419533128 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts89, hist_sound data _ _ counts6] <;> exact dot89 i j
theorem dot90 : ∀ i j : Fin 8, dot data histograms[90]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare90 : ∀ i j : Fin 8, sumTable data 837739896479240456 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts90, hist_sound data _ _ counts6] <;> exact dot90 i j
theorem dot91 : ∀ i j : Fin 8, dot data histograms[91]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare91 : ∀ i j : Fin 8, sumTable data 838021096578044168 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts91, hist_sound data _ _ counts6] <;> exact dot91 i j
end IU.Sharp5.Cone0
