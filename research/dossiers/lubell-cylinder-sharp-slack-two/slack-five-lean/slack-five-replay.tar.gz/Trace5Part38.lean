import Trace5Part37
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step608 : NodeGood bank Hit (4352,4611686018427383551,0) := by
  apply use_pivot bank Hit sym noLoop 4352 4611686018427383551 0 14 [14] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4352 4611686018427383551 0 ([14] : List (Fin n))=[(20736,4611686018427367167,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step607
theorem step609 : NodeGood bank Hit (256,4611686018427387647,0) := by
  apply use_pivot bank Hit sym noLoop 256 4611686018427387647 0 12 [12] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 256 4611686018427387647 0 ([12] : List (Fin n))=[(4352,4611686018427383551,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step608
theorem step610 : NodeGood bank Hit (0,4611686018427387903,0) := by
  apply use_pivot bank Hit sym noLoop 0 4611686018427387903 0 8 [8] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 0 4611686018427387903 0 ([8] : List (Fin n))=[(256,4611686018427387647,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step609

theorem all_maximal (Q : Finset (Fin n)) (h : BK.MaxClique (edge bank) Q) : Hit Q := by
  apply step610 Q h
  change BK.Covers Q (members n 0) (members n (2^n-1)) (members n 0)
  simp [BK.Covers,members_zero,members_full]
#print axioms all_maximal
end IU.Trace5
