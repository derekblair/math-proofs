import Sharp5Grid1Coeff9
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entries (v : Fin n) (i j : Fin 8) : vcoeff T U (shapes v) i.val j.val=readTable data v i.val j.val := by
  rw [shape_lookup]
  fin_cases v
  · exact entry0 i j
  · exact entry6 i j
  · exact entry10 i j
  · exact entry1 i j
  · exact entry7 i j
  · exact entry11 i j
  · exact entry1 i j
  · exact entry7 i j
  · exact entry2 i j
  · exact entry8 i j
  · exact entry1 i j
  · exact entry7 i j
  · exact entry2 i j
  · exact entry8 i j
  · exact entry2 i j
  · exact entry8 i j
  · exact entry3 i j
  · exact entry9 i j
  · exact entry1 i j
  · exact entry7 i j
  · exact entry2 i j
  · exact entry8 i j
  · exact entry2 i j
  · exact entry3 i j
  · exact entry2 i j
  · exact entry3 i j
  · exact entry3 i j
  · exact entry4 i j
  · exact entry1 i j
  · exact entry7 i j
  · exact entry2 i j
  · exact entry8 i j
  · exact entry2 i j
  · exact entry3 i j
  · exact entry2 i j
  · exact entry3 i j
  · exact entry3 i j
  · exact entry4 i j
  · exact entry2 i j
  · exact entry3 i j
  · exact entry3 i j
  · exact entry4 i j
  · exact entry3 i j
  · exact entry4 i j
  · exact entry4 i j
  · exact entry5 i j
  · exact entry12 i j
  · exact entry16 i j
  · exact entry13 i j
  · exact entry17 i j
  · exact entry13 i j
  · exact entry13 i j
  · exact entry13 i j
  · exact entry14 i j
  · exact entry13 i j
  · exact entry14 i j
  · exact entry14 i j
  · exact entry14 i j
  · exact entry14 i j
  · exact entry15 i j
  · exact entry18 i j
  · exact entry19 i j
end IU.Sharp5.Cone1
