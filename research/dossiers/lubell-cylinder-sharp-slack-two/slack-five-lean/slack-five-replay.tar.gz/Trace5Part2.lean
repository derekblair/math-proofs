import Trace5Part1
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step32 : NodeGood bank Hit (42999051064,21885529591909575,0) := by
  apply use_pivot bank Hit sym noLoop 42999051064 21885529591909575 0 30 [30] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 42999051064 21885529591909575 0 ([30] : List (Fin n))=[(44072792888,21885528518167751,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step31
theorem step33 : NodeGood bank Hit (42996953912,21885529594006727,0) := by
  apply use_pivot bank Hit sym noLoop 42996953912 21885529594006727 0 21 [21] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 42996953912 21885529594006727 0 ([21] : List (Fin n))=[(42999051064,21885529591909575,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step32
theorem step34 : NodeGood bank Hit (42996945720,21885529594014919,0) := by
  apply use_pivot bank Hit sym noLoop 42996945720 21885529594014919 0 13 [13] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 42996945720 21885529594014919 0 ([13] : List (Fin n))=[(42996953912,21885529594006727,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step33
theorem step35 : NodeGood bank Hit (42996945208,21885529594015431,0) := by
  apply use_pivot bank Hit sym noLoop 42996945208 21885529594015431 0 9 [9] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 42996945208 21885529594015431 0 ([9] : List (Fin n))=[(42996945720,21885529594014919,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step34
theorem step36 : NodeGood bank Hit (42996945192,21885529594015447,0) := by
  apply use_pivot bank Hit sym noLoop 42996945192 21885529594015447 0 4 [4] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 42996945192 21885529594015447 0 ([4] : List (Fin n))=[(42996945208,21885529594015431,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step35
theorem step37 : NodeGood bank Hit (42996945184,21885529594015455,0) := by
  apply use_pivot bank Hit sym noLoop 42996945184 21885529594015455 0 3 [3] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 42996945184 21885529594015455 0 ([3] : List (Fin n))=[(42996945192,21885529594015447,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step36
theorem step38 : NodeGood bank Hit (891071332319,0,0) := by
  exact leaf bank Hit 891071332319 0 ⟨891071332319,by decide +kernel,rfl⟩
theorem step39 : NodeGood bank Hit (616193425375,274877906944,0) := by
  apply use_pivot bank Hit sym noLoop 616193425375 274877906944 0 38 [38] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 616193425375 274877906944 0 ([38] : List (Fin n))=[(891071332319,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step38
theorem step40 : NodeGood bank Hit (599013556191,292057776128,0) := by
  apply use_pivot bank Hit sym noLoop 599013556191 292057776128 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 599013556191 292057776128 0 ([34] : List (Fin n))=[(616193425375,274877906944,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step39
theorem step41 : NodeGood bank Hit (598476685279,292594647040,0) := by
  apply use_pivot bank Hit sym noLoop 598476685279 292594647040 0 29 [29] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598476685279 292594647040 0 ([29] : List (Fin n))=[(599013556191,292057776128,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step40
theorem step42 : NodeGood bank Hit (598208249823,292863082496,0) := by
  apply use_pivot bank Hit sym noLoop 598208249823 292863082496 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598208249823 292863082496 0 ([28] : List (Fin n))=[(598476685279,292594647040,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step41
theorem step43 : NodeGood bank Hit (598191472607,292879859712,0) := by
  apply use_pivot bank Hit sym noLoop 598191472607 292879859712 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598191472607 292879859712 0 ([24] : List (Fin n))=[(598208249823,292863082496,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step42
theorem step44 : NodeGood bank Hit (598190948319,292880384000,0) := by
  apply use_pivot bank Hit sym noLoop 598190948319 292880384000 0 19 [19] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598190948319 292880384000 0 ([19] : List (Fin n))=[(598191472607,292879859712,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step43
theorem step45 : NodeGood bank Hit (598190686175,292880646144,0) := by
  apply use_pivot bank Hit sym noLoop 598190686175 292880646144 0 18 [18] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598190686175 292880646144 0 ([18] : List (Fin n))=[(598190948319,292880384000,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step44
theorem step46 : NodeGood bank Hit (598190684127,292880648192,0) := by
  apply use_pivot bank Hit sym noLoop 598190684127 292880648192 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598190684127 292880648192 0 ([11] : List (Fin n))=[(598190686175,292880646144,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step45
theorem step47 : NodeGood bank Hit (598190683103,292880649216,0) := by
  apply use_pivot bank Hit sym noLoop 598190683103 292880649216 0 10 [10] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598190683103 292880649216 0 ([10] : List (Fin n))=[(598190684127,292880648192,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step46
end IU.Trace5
