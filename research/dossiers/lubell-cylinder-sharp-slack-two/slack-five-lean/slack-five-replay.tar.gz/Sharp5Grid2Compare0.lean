import Sharp5Grid2Entries
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot0 : ∀ i j : Fin 8, dot data histograms[0]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare0 : ∀ i j : Fin 8, sumTable data 272190930907 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts0, hist_sound data _ _ counts61] <;> exact dot0 i j
theorem dot1 : ∀ i j : Fin 8, dot data histograms[1]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare1 : ∀ i j : Fin 8, sumTable data 409630277595 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts1, hist_sound data _ _ counts61] <;> exact dot1 i j
theorem dot2 : ∀ i j : Fin 8, dot data histograms[2]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare2 : ∀ i j : Fin 8, sumTable data 410032930783 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts2, hist_sound data _ _ counts61] <;> exact dot2 i j
theorem dot3 : ∀ i j : Fin 8, dot data histograms[3]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare3 : ∀ i j : Fin 8, sumTable data 547068706779 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts3, hist_sound data _ _ counts61] <;> exact dot3 i j
end IU.Sharp5.Cone2
