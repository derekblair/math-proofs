import Trace5Part33
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step544 : NodeGood bank Hit (1129629150975447296,2305843009213693952,0) := by
  apply use_pivot bank Hit sym noLoop 1129629150975447296 2305843009213693952 0 61 [61] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1129629150975447296 2305843009213693952 0 ([61] : List (Fin n))=[(3435472160189141248,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step543
theorem step545 : NodeGood bank Hit (553168398672023808,2882303761517117440,0) := by
  apply use_pivot bank Hit sym noLoop 553168398672023808 2882303761517117440 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 553168398672023808 2882303761517117440 0 ([59] : List (Fin n))=[(1129629150975447296,2305843009213693952,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step544
theorem step546 : NodeGood bank Hit (409053210596167936,3026418949592973312,0) := by
  apply use_pivot bank Hit sym noLoop 409053210596167936 3026418949592973312 0 57 [57] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 409053210596167936 3026418949592973312 0 ([57] : List (Fin n))=[(553168398672023808,2882303761517117440,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step545
theorem step547 : NodeGood bank Hit (336995616558240000,3098476543630901248,0) := by
  apply use_pivot bank Hit sym noLoop 336995616558240000 3098476543630901248 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336995616558240000 3098476543630901248 0 ([56] : List (Fin n))=[(409053210596167936,3026418949592973312,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step546
theorem step548 : NodeGood bank Hit (336960432186151168,3098511728002990080,0) := by
  apply use_pivot bank Hit sym noLoop 336960432186151168 3098511728002990080 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336960432186151168 3098511728002990080 0 ([45] : List (Fin n))=[(336995616558240000,3098476543630901248,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step547
theorem step549 : NodeGood bank Hit (336942840000106752,3098529320189034496,0) := by
  apply use_pivot bank Hit sym noLoop 336942840000106752 3098529320189034496 0 44 [44] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336942840000106752 3098529320189034496 0 ([44] : List (Fin n))=[(336960432186151168,3098511728002990080,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step548
theorem step550 : NodeGood bank Hit (336934043907084544,3098538116282056704,0) := by
  apply use_pivot bank Hit sym noLoop 336934043907084544 3098538116282056704 0 43 [43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336934043907084544 3098538116282056704 0 ([43] : List (Fin n))=[(336942840000106752,3098529320189034496,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step549
theorem step551 : NodeGood bank Hit (336929645860573440,3098542514328567808,0) := by
  apply use_pivot bank Hit sym noLoop 336929645860573440 3098542514328567808 0 42 [42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336929645860573440 3098542514328567808 0 ([42] : List (Fin n))=[(336934043907084544,3098538116282056704,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step550
theorem step552 : NodeGood bank Hit (336927446837317888,3098544713351823360,0) := by
  apply use_pivot bank Hit sym noLoop 336927446837317888 3098544713351823360 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336927446837317888 3098544713351823360 0 ([41] : List (Fin n))=[(336929645860573440,3098542514328567808,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step551
theorem step553 : NodeGood bank Hit (336926347325690112,3098545812863451136,0) := by
  apply use_pivot bank Hit sym noLoop 336926347325690112 3098545812863451136 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336926347325690112 3098545812863451136 0 ([40] : List (Fin n))=[(336927446837317888,3098544713351823360,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step552
theorem step554 : NodeGood bank Hit (336925797569876224,3098546362619265024,0) := by
  apply use_pivot bank Hit sym noLoop 336925797569876224 3098546362619265024 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 336925797569876224 3098546362619265024 0 ([39] : List (Fin n))=[(336926347325690112,3098545812863451136,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step553
theorem step555 : NodeGood bank Hit (2354538430631858432,792703353405571072,288230376151711744) := by
  apply use_pivot bank Hit sym noLoop 2354538430631858432 792703353405571072 288230376151711744 58 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2354538430631858432 792703353405571072 288230376151711744 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step556 : NodeGood bank Hit (48695421418164480,3387339688724570648,0) := by
  apply use_pivot bank Hit sym noLoop 48695421418164480 3387339688724570648 0 3 [3,58,61] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48695421418164480 3387339688724570648 0 ([3,58,61] : List (Fin n))=[(48695421418164488,793266303359164944,0),(336925797569876224,3098546362619265024,0),(2354538430631858432,792703353405571072,288230376151711744)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h
  · subst C; exact step542
  · subst C; exact step554
  · subst C; exact step555
theorem step557 : NodeGood bank Hit (12666624399200512,3423368485743534616,0) := by
  apply use_pivot bank Hit sym noLoop 12666624399200512 3423368485743534616 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 12666624399200512 3423368485743534616 0 ([55] : List (Fin n))=[(48695421418164480,3387339688724570648,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step556
theorem step558 : NodeGood bank Hit (3659425144459520,3432375684998275608,0) := by
  apply use_pivot bank Hit sym noLoop 3659425144459520 3432375684998275608 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3659425144459520 3432375684998275608 0 ([53] : List (Fin n))=[(12666624399200512,3423368485743534616,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step557
theorem step559 : NodeGood bank Hit (2533525237616896,3433501584905118232,0) := by
  apply use_pivot bank Hit sym noLoop 2533525237616896 3433501584905118232 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2533525237616896 3433501584905118232 0 ([50] : List (Fin n))=[(3659425144459520,3432375684998275608,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step558
end IU.Trace5
