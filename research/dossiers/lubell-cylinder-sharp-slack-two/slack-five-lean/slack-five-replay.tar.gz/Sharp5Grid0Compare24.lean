import Sharp5Grid0Compare23
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot96 : ∀ i j : Fin 8, dot data histograms[96]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare96 : ∀ i j : Fin 8, sumTable data 1206121074334462720 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts96, hist_sound data _ _ counts6] <;> exact dot96 i j
theorem dot97 : ∀ i j : Fin 8, dot data histograms[97]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare97 : ∀ i j : Fin 8, sumTable data 1206683474532233984 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts97, hist_sound data _ _ counts6] <;> exact dot97 i j
theorem dot98 : ∀ i j : Fin 8, dot data histograms[98]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare98 : ∀ i j : Fin 8, sumTable data 1278181966907265792 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts98, hist_sound data _ _ counts6] <;> exact dot98 i j
theorem dot99 : ∀ i j : Fin 8, dot data histograms[99]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare99 : ∀ i j : Fin 8, sumTable data 3431813281844646144 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts99, hist_sound data _ _ counts6] <;> exact dot99 i j
end IU.Sharp5.Cone0
