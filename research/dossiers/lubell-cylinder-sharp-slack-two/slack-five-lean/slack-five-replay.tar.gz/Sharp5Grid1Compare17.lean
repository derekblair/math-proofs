import Sharp5Grid1Compare16
import Sharp5HistPart20
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot68 : ∀ i j : Fin 8, dot data histograms[68]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare68 : ∀ i j : Fin 8, sumTable data 118505068228072408 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts68, hist_sound data _ _ counts6] <;> exact dot68 i j
theorem dot69 : ∀ i j : Fin 8, dot data histograms[69]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare69 : ∀ i j : Fin 8, sumTable data 118509466274583000 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts69, hist_sound data _ _ counts6] <;> exact dot69 i j
theorem dot70 : ∀ i j : Fin 8, dot data histograms[70]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare70 : ∀ i j : Fin 8, sumTable data 118518262367605080 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts70, hist_sound data _ _ counts6] <;> exact dot70 i j
theorem dot71 : ∀ i j : Fin 8, dot data histograms[71]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare71 : ∀ i j : Fin 8, sumTable data 120756863746790168 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts71, hist_sound data _ _ counts6] <;> exact dot71 i j
end IU.Sharp5.Cone1
