import Sharp5HistPart0
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts5 : ∀ q : Fin 20, ((members n 891071332319).filter (fun v => code v=q)).card=(histograms[5]!)[q.val]! := by decide +kernel
theorem counts6 : ∀ q : Fin 20, ((members n 893151707135).filter (fun v => code v=q)).card=(histograms[6]!)[q.val]! := by decide +kernel
theorem counts7 : ∀ q : Fin 20, ((members n 959386058715).filter (fun v => code v=q)).card=(histograms[7]!)[q.val]! := by decide +kernel
theorem counts8 : ∀ q : Fin 20, ((members n 959788711903).filter (fun v => code v=q)).card=(histograms[8]!)[q.val]! := by decide +kernel
theorem counts9 : ∀ q : Fin 20, ((members n 1096824487899).filter (fun v => code v=q)).card=(histograms[9]!)[q.val]! := by decide +kernel
end IU.Sharp5
