import Trace5Part27
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step448 : NodeGood bank Hit (261226367617683736,0,0) := by
  exact leaf bank Hit 261226367617683736 0 ⟨261226367617683736,by decide +kernel,rfl⟩
theorem step449 : NodeGood bank Hit (837739896479240456,0,0) := by
  exact leaf bank Hit 837739896479240456 0 ⟨837739896479240456,by decide +kernel,rfl⟩
theorem step450 : NodeGood bank Hit (261279144175816968,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 261279144175816968 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261279144175816968 576460752303423488 0 ([59] : List (Fin n))=[(837739896479240456,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step449
theorem step451 : NodeGood bank Hit (261243959803728136,576495936675512320,0) := by
  apply use_pivot bank Hit sym noLoop 261243959803728136 576495936675512320 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261243959803728136 576495936675512320 0 ([45] : List (Fin n))=[(261279144175816968,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step450
theorem step452 : NodeGood bank Hit (261226367617683720,576513528861556752,0) := by
  apply use_pivot bank Hit sym noLoop 261226367617683720 576513528861556752 0 44 [4,44] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261226367617683720 576513528861556752 0 ([4,44] : List (Fin n))=[(261226367617683736,0,0),(261243959803728136,576495936675512320,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step448
  · subst C; exact step451
theorem step453 : NodeGood bank Hit (261507567716487448,0,0) := by
  exact leaf bank Hit 261507567716487448 0 ⟨261507567716487448,by decide +kernel,rfl⟩
theorem step454 : NodeGood bank Hit (838021096578044168,0,0) := by
  exact leaf bank Hit 838021096578044168 0 ⟨838021096578044168,by decide +kernel,rfl⟩
theorem step455 : NodeGood bank Hit (261560344274620680,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 261560344274620680 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261560344274620680 576460752303423488 0 ([59] : List (Fin n))=[(838021096578044168,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step454
theorem step456 : NodeGood bank Hit (261525159902531848,576495936675512320,0) := by
  apply use_pivot bank Hit sym noLoop 261525159902531848 576495936675512320 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261525159902531848 576495936675512320 0 ([45] : List (Fin n))=[(261560344274620680,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step455
theorem step457 : NodeGood bank Hit (261507567716487432,576513528861556752,0) := by
  apply use_pivot bank Hit sym noLoop 261507567716487432 576513528861556752 0 44 [4,44] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261507567716487432 576513528861556752 0 ([4,44] : List (Fin n))=[(261507567716487448,0,0),(261525159902531848,576495936675512320,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step453
  · subst C; exact step456
theorem step458 : NodeGood bank Hit (261226092739776776,576795278716174352,0) := by
  apply use_pivot bank Hit sym noLoop 261226092739776776 576795278716174352 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261226092739776776 576795278716174352 0 ([38,48] : List (Fin n))=[(261226367617683720,576513528861556752,0),(261507567716487432,576513528861556752,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step452
  · subst C; exact step457
theorem step459 : NodeGood bank Hit (262633450443460888,0,0) := by
  exact leaf bank Hit 262633450443460888 0 ⟨262633450443460888,by decide +kernel,rfl⟩
theorem step460 : NodeGood bank Hit (839146979305017608,0,0) := by
  exact leaf bank Hit 839146979305017608 0 ⟨839146979305017608,by decide +kernel,rfl⟩
theorem step461 : NodeGood bank Hit (262686227001594120,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 262686227001594120 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 262686227001594120 576460752303423488 0 ([59] : List (Fin n))=[(839146979305017608,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step460
theorem step462 : NodeGood bank Hit (262651042629505288,576495936675512320,0) := by
  apply use_pivot bank Hit sym noLoop 262651042629505288 576495936675512320 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 262651042629505288 576495936675512320 0 ([45] : List (Fin n))=[(262686227001594120,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step461
theorem step463 : NodeGood bank Hit (262633450443460872,576513528861556752,0) := by
  apply use_pivot bank Hit sym noLoop 262633450443460872 576513528861556752 0 44 [4,44] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 262633450443460872 576513528861556752 0 ([4,44] : List (Fin n))=[(262633450443460888,0,0),(262651042629505288,576495936675512320,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step459
  · subst C; exact step462
end IU.Trace5
