import Sharp5HistPart16
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts85 : ∀ q : Fin 20, ((members n 693624708403384648).filter (fun v => code v=q)).card=(histograms[85]!)[q.val]! := by decide +kernel
theorem counts86 : ∀ q : Fin 20, ((members n 693905908502188360).filter (fun v => code v=q)).card=(histograms[86]!)[q.val]! := by decide +kernel
theorem counts87 : ∀ q : Fin 20, ((members n 695031791229161800).filter (fun v => code v=q)).card=(histograms[87]!)[q.val]! := by decide +kernel
theorem counts88 : ∀ q : Fin 20, ((members n 713046189721866568).filter (fun v => code v=q)).card=(histograms[88]!)[q.val]! := by decide +kernel
theorem counts89 : ∀ q : Fin 20, ((members n 713112160419533128).filter (fun v => code v=q)).card=(histograms[89]!)[q.val]! := by decide +kernel
end IU.Sharp5
