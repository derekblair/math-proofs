import Sharp5Grid1Compare5
import Sharp5HistPart20
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot24 : ∀ i j : Fin 8, dot data histograms[24]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare24 : ∀ i j : Fin 8, sumTable data 9007471177236440 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts24, hist_sound data _ _ counts6] <;> exact dot24 i j
theorem dot25 : ∀ i j : Fin 8, dot data histograms[25]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare25 : ∀ i j : Fin 8, sumTable data 9007608616583128 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts25, hist_sound data _ _ counts6] <;> exact dot25 i j
theorem dot26 : ∀ i j : Fin 8, dot data histograms[26]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare26 : ∀ i j : Fin 8, sumTable data 9007746055012312 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts26, hist_sound data _ _ counts6] <;> exact dot26 i j
theorem dot27 : ∀ i j : Fin 8, dot data histograms[27]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare27 : ∀ i j : Fin 8, sumTable data 9008089654984664 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts27, hist_sound data _ _ counts6] <;> exact dot27 i j
end IU.Sharp5.Cone1
