import Trace5Part3
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step64 : NodeGood bank Hit (1126498248520664,9288674231451648,0) := by
  apply use_pivot bank Hit sym noLoop 1126498248520664 9288674231451648 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1126498248520664 9288674231451648 0 ([48] : List (Fin n))=[(1407973225231320,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step63
theorem step65 : NodeGood bank Hit (598341678040,10414866465295363,0) := by
  apply use_pivot bank Hit sym noLoop 598341678040 10414866465295363 0 10 [10,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598341678040 10414866465295363 0 ([10,50] : List (Fin n))=[(598341679064,9288966558451715,0),(1126498248520664,9288674231451648,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step61
  · subst C; exact step64
theorem step66 : NodeGood bank Hit (28640677205210072,0,0) := by
  exact leaf bank Hit 28640677205210072 0 ⟨28640677205210072,by decide +kernel,rfl⟩
theorem step67 : NodeGood bank Hit (10626278695728088,18014398509481984,0) := by
  apply use_pivot bank Hit sym noLoop 10626278695728088 18014398509481984 0 54 [54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10626278695728088 18014398509481984 0 ([54] : List (Fin n))=[(28640677205210072,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step66
theorem step68 : NodeGood bank Hit (1619079440987096,27021597764222976,0) := by
  apply use_pivot bank Hit sym noLoop 1619079440987096 27021597764222976 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1619079440987096 27021597764222976 0 ([53] : List (Fin n))=[(10626278695728088,18014398509481984,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step67
theorem step69 : NodeGood bank Hit (493179534144472,28147497671065600,0) := by
  apply use_pivot bank Hit sym noLoop 493179534144472 28147497671065600 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 493179534144472 28147497671065600 0 ([50] : List (Fin n))=[(1619079440987096,27021597764222976,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step68
theorem step70 : NodeGood bank Hit (211704557433816,28428972647776256,0) := by
  apply use_pivot bank Hit sym noLoop 211704557433816 28428972647776256 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 211704557433816 28428972647776256 0 ([48] : List (Fin n))=[(493179534144472,28147497671065600,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step69
theorem step71 : NodeGood bank Hit (70967069078488,28569710136131584,0) := by
  apply use_pivot bank Hit sym noLoop 70967069078488 28569710136131584 0 47 [47] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 70967069078488 28569710136131584 0 ([47] : List (Fin n))=[(211704557433816,28428972647776256,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step70
theorem step72 : NodeGood bank Hit (141335813256152,28428972647776256,70368744177664) := by
  apply use_pivot bank Hit sym noLoop 141335813256152 28428972647776256 70368744177664 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 141335813256152 28428972647776256 70368744177664 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step73 : NodeGood bank Hit (18014996834382808,10414574138294272,211106232532992) := by
  apply use_pivot bank Hit sym noLoop 18014996834382808 10414574138294272 211106232532992 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18014996834382808 10414574138294272 211106232532992 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step74 : NodeGood bank Hit (598324900824,28640371224087555,0) := by
  apply use_pivot bank Hit sym noLoop 598324900824 28640371224087555 0 24 [24,46,47,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598324900824 28640371224087555 0 ([24,46,47,54] : List (Fin n))=[(598341678040,10414866465295363,0),(70967069078488,28569710136131584,0),(141335813256152,28428972647776256,70368744177664),(18014996834382808,10414574138294272,211106232532992)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step65
  · subst C; exact step71
  · subst C; exact step72
  · subst C; exact step73
theorem step75 : NodeGood bank Hit (598727554008,292343778307,4) := by
  apply use_pivot bank Hit sym noLoop 598727554008 292343778307 4 2 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598727554008 292343778307 4 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step76 : NodeGood bank Hit (598190683096,28640371895176199,0) := by
  apply use_pivot bank Hit sym noLoop 598190683096 28640371895176199 0 27 [2,27,29] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598190683096 28640371895176199 0 ([2,27,29] : List (Fin n))=[(598190683100,292880649219,0),(598324900824,28640371224087555,0),(598727554008,292343778307,4)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h
  · subst C; exact step49
  · subst C; exact step74
  · subst C; exact step75
theorem step77 : NodeGood bank Hit (593895715800,28640376190143495,0) := by
  apply use_pivot bank Hit sym noLoop 593895715800 28640376190143495 0 32 [32] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 593895715800 28640376190143495 0 ([32] : List (Fin n))=[(598190683096,28640371895176199,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step76
theorem step78 : NodeGood bank Hit (593895715672,28640376190143623,0) := by
  apply use_pivot bank Hit sym noLoop 593895715672 28640376190143623 0 7 [7] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 593895715672 28640376190143623 0 ([7] : List (Fin n))=[(593895715800,28640376190143495,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step77
theorem step79 : NodeGood bank Hit (12666967998690072,0,0) := by
  exact leaf bank Hit 12666967998690072 0 ⟨12666967998690072,by decide +kernel,rfl⟩
end IU.Trace5
