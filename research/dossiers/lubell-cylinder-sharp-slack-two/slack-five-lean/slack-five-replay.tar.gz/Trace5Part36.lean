import Trace5Part35
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step576 : NodeGood bank Hit (1278247937604931840,3314649325744685056,0) := by
  apply use_pivot bank Hit sym noLoop 1278247937604931840 3314649325744685056 0 57 [57] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1278247937604931840 3314649325744685056 0 ([57] : List (Fin n))=[(1422363125680787712,3170534137668829184,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step575
theorem step577 : NodeGood bank Hit (1278212753232843008,3314684510116773888,0) := by
  apply use_pivot bank Hit sym noLoop 1278212753232843008 3314684510116773888 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1278212753232843008 3314684510116773888 0 ([45] : List (Fin n))=[(1278247937604931840,3314649325744685056,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step576
theorem step578 : NodeGood bank Hit (1278195161046798592,3314702102302818304,0) := by
  apply use_pivot bank Hit sym noLoop 1278195161046798592 3314702102302818304 0 44 [44] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1278195161046798592 3314702102302818304 0 ([44] : List (Fin n))=[(1278212753232843008,3314684510116773888,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step577
theorem step579 : NodeGood bank Hit (1278186364953776384,3314710898395840512,0) := by
  apply use_pivot bank Hit sym noLoop 1278186364953776384 3314710898395840512 0 43 [43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1278186364953776384 3314710898395840512 0 ([43] : List (Fin n))=[(1278195161046798592,3314702102302818304,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step578
theorem step580 : NodeGood bank Hit (1278181966907265280,3314715296442352128,0) := by
  apply use_pivot bank Hit sym noLoop 1278181966907265280 3314715296442352128 0 42 [9,42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1278181966907265280 3314715296442352128 0 ([9,42] : List (Fin n))=[(1278181966907265792,0,0),(1278186364953776384,3314710898395840512,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step571
  · subst C; exact step579
theorem step581 : NodeGood bank Hit (1206124372869337344,3386772890480280064,0) := by
  apply use_pivot bank Hit sym noLoop 1206124372869337344 3386772890480280064 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206124372869337344 3386772890480280064 0 ([56] : List (Fin n))=[(1278181966907265280,3314715296442352128,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step580
theorem step582 : NodeGood bank Hit (1206122173846081792,3386775089503535616,0) := by
  apply use_pivot bank Hit sym noLoop 1206122173846081792 3386775089503535616 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206122173846081792 3386775089503535616 0 ([41] : List (Fin n))=[(1206124372869337344,3386772890480280064,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step581
theorem step583 : NodeGood bank Hit (1206121074334454016,3386776189015171584,0) := by
  apply use_pivot bank Hit sym noLoop 1206121074334454016 3386776189015171584 0 40 [13,40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206121074334454016 3386776189015171584 0 ([13,40] : List (Fin n))=[(1206121074334462208,512,0),(1206122173846081792,3386775089503535616,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step570
  · subst C; exact step582
theorem step584 : NodeGood bank Hit (1206683474532061440,8704,163840) := by
  apply use_pivot bank Hit sym noLoop 1206683474532061440 8704 163840 15 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206683474532061440 8704 163840 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step585 : NodeGood bank Hit (1206120524578640128,3387339688724570624,0) := by
  apply use_pivot bank Hit sym noLoop 1206120524578640128 3387339688724570624 0 39 [15,17,39,49] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1206120524578640128 3387339688724570624 0 ([15,17,39,49] : List (Fin n))=[(1206120524578672896,562949953561088,0),(1206120524578771200,562949953430016,32768),(1206121074334454016,3386776189015171584,0),(1206683474532061440,8704,163840)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step567
  · subst C; exact step568
  · subst C; exact step583
  · subst C; exact step584
theorem step586 : NodeGood bank Hit (53199019971793152,4540261193331417600,0) := by
  apply use_pivot bank Hit sym noLoop 53199019971793152 4540261193331417600 0 60 [60] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 53199019971793152 4540261193331417600 0 ([60] : List (Fin n))=[(1206120524578640128,3387339688724570624,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step585
theorem step587 : NodeGood bank Hit (17170222952829184,4576289990350381568,0) := by
  apply use_pivot bank Hit sym noLoop 17170222952829184 4576289990350381568 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17170222952829184 4576289990350381568 0 ([55] : List (Fin n))=[(53199019971793152,4540261193331417600,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step586
theorem step588 : NodeGood bank Hit (8163023698088192,4585297189605122560,0) := by
  apply use_pivot bank Hit sym noLoop 8163023698088192 4585297189605122560 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8163023698088192 4585297189605122560 0 ([53] : List (Fin n))=[(17170222952829184,4576289990350381568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step587
theorem step589 : NodeGood bank Hit (5911223884402944,4587548989418807808,0) := by
  apply use_pivot bank Hit sym noLoop 5911223884402944 4587548989418807808 0 51 [51] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 5911223884402944 4587548989418807808 0 ([51] : List (Fin n))=[(8163023698088192,4585297189605122560,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step588
theorem step590 : NodeGood bank Hit (4785323977560320,4588674889325650432,0) := by
  apply use_pivot bank Hit sym noLoop 4785323977560320 4588674889325650432 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4785323977560320 4588674889325650432 0 ([50] : List (Fin n))=[(5911223884402944,4587548989418807808,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step589
theorem step591 : NodeGood bank Hit (4503849000849664,4588956364302361088,0) := by
  apply use_pivot bank Hit sym noLoop 4503849000849664 4588956364302361088 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4503849000849664 4588956364302361088 0 ([48] : List (Fin n))=[(4785323977560320,4588674889325650432,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step590
end IU.Trace5
