import WalkGraphBucket

namespace IU.UniversalCount
open IU.Universal

theorem bits_prefix_bounds (m h s : Nat) (hs : h≤s) :
    bits m h≤bits m s ∧ bits m s+(h-bits m h)≤s ∧ bits m h≤h := by
  have bdd (k : Nat) : bits m k≤k := by
    induction k with
    | zero => simp [bits]
    | succ k ih =>
        rw [bits_succ]
        split <;> omega
  have D (d : Nat) : bits m h≤bits m (h+d) ∧ bits m (h+d)≤bits m h+d := by
    induction d with
    | zero => simp
    | succ d ih =>
        rw [← Nat.add_assoc,bits_succ]
        obtain ⟨a,b⟩ := ih
        split <;> omega
  have H := D (s-h)
  rw [Nat.add_sub_of_le hs] at H
  have J := bdd h
  omega

def BucketIndex (s : Nat) := {t : Nat × Nat × Nat // 2*t.1≤t.2.2 ∧ t.2.2+2*t.2.1≤s}

theorem vertex_deficits (s r w j : Nat) (hv : (r,w,j)∈vertexList s) :
    2*r≤bits w s ∧ bits w s+2*(j+r-bits w s)≤s := by
  obtain ⟨_,_,_,ht,hc⟩ := (mem_vertices s r w j).mp hv
  have ex := hc
  simp only [compat,List.any_eq_true,List.mem_range,Nat.lt_succ_iff,decide_eq_true_eq] at ex
  obtain ⟨h,hs,hcross⟩ := ex
  obtain ⟨p,q,bh⟩ := bits_prefix_bounds w h s hs
  have q' : h-bits w h≤s-bits w s := by omega
  have ms := (bits_prefix_bounds w s s le_rfl).2.2
  exact deficits_of_range s (bits w s) r j h (bits w h) hs p q' bh ms ht hcross

def graph_partition (s : Nat) :
    {v : Vertex // v∈vertexList s} ≃
      (i : BucketIndex s) × GraphBucket s i.val.1 i.val.2.1 i.val.2.2 := by
  let forward (v : {v : Vertex // v∈vertexList s}) :
      (i : BucketIndex s) × GraphBucket s i.val.1 i.val.2.1 i.val.2.2 := by
    rcases v with ⟨⟨r,w,j⟩,hv⟩
    let m := bits w s
    let z := j+r-m
    have ds := vertex_deficits s r w j hv
    let idx : BucketIndex s := ⟨(r,z,m),ds⟩
    have ht := ((mem_vertices s r w j).mp hv).2.2.2.1
    have J : m-r+z=j := by
      dsimp [m,z] at *
      omega
    exact ⟨idx,⟨w,by change (r,w,m-r+z)∈vertexList s ∧ bits w s=m; rw [J]; exact ⟨hv,rfl⟩⟩⟩
  let backward (x : (i : BucketIndex s) × GraphBucket s i.val.1 i.val.2.1 i.val.2.2) :
      {v : Vertex // v∈vertexList s} :=
    ⟨(x.1.val.1,x.2.val,x.1.val.2.2-x.1.val.1+x.1.val.2.1),x.2.property.1⟩
  refine ⟨forward,backward,?_,?_⟩
  · rintro ⟨⟨r,w,j⟩,hv⟩
    apply Subtype.ext
    change (r,w,bits w s-r+(j+r-bits w s))=(r,w,j)
    have lo := (vertex_deficits s r w j hv).1
    have ht := ((mem_vertices s r w j).mp hv).2.2.2.1
    have e : bits w s-r+(j+r-bits w s)=j := by omega
    rw [e]
  · rintro ⟨⟨⟨r,z,m⟩,hlo,hhi⟩,⟨w,hv,hw⟩⟩
    change bits w s=m at hw
    have eq := (index_of_deficits s m r z hlo hhi).2.2.2
    apply Sigma.ext
    · apply Subtype.ext
      change (r,m-r+z+r-bits w s,bits w s)=(r,z,m)
      rw [hw,eq]
    · apply (Subtype.heq_iff_coe_eq ?_).2
      · rfl
      · intro x
        change ((r,x,bits w s-r+(m-r+z+r-bits w s))∈vertexList s ∧ bits x s=bits w s) ↔ ((r,x,m-r+z)∈vertexList s ∧ bits x s=m)
        rw [hw,eq]

#print axioms graph_partition
end IU.UniversalCount
