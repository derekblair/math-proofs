import Trace5Part31
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step512 : NodeGood bank Hit (48695421418173208,563499709399040,0) := by
  apply use_pivot bank Hit sym noLoop 48695421418173208 563499709399040 0 15 [15,39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48695421418173208 563499709399040 0 ([15,39] : List (Fin n))=[(48695421418205976,562949953552384,0),(48695971173987096,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step510
  · subst C; exact step511
theorem step513 : NodeGood bank Hit (120756863746790168,0,0) := by
  exact leaf bank Hit 120756863746790168 0 ⟨120756863746790168,by decide +kernel,rfl⟩
theorem step514 : NodeGood bank Hit (48699269708862232,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 48699269708862232 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48699269708862232 72057594037927936 0 ([56] : List (Fin n))=[(120756863746790168,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step513
theorem step515 : NodeGood bank Hit (48697070685606680,72059793061183488,0) := by
  apply use_pivot bank Hit sym noLoop 48697070685606680 72059793061183488 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48697070685606680 72059793061183488 0 ([41] : List (Fin n))=[(48699269708862232,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step514
theorem step516 : NodeGood bank Hit (48696520929792792,72060342816997376,0) := by
  apply use_pivot bank Hit sym noLoop 48696520929792792 72060342816997376 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48696520929792792 72060342816997376 0 ([39] : List (Fin n))=[(48697070685606680,72059793061183488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step515
theorem step517 : NodeGood bank Hit (48697620441420568,72058143793741824,1099511627776) := by
  apply use_pivot bank Hit sym noLoop 48697620441420568 72058143793741824 1099511627776 40 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48697620441420568 72058143793741824 1099511627776 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step518 : NodeGood bank Hit (120753015456092952,549755813888,3298534883328) := by
  apply use_pivot bank Hit sym noLoop 120753015456092952 549755813888 3298534883328 40 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 120753015456092952 549755813888 3298534883328 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step519 : NodeGood bank Hit (48695421418165016,72624392282218496,0) := by
  apply use_pivot bank Hit sym noLoop 48695421418165016 72624392282218496 0 13 [13,40,41,56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48695421418165016 72624392282218496 0 ([13,40,41,56] : List (Fin n))=[(48695421418173208,563499709399040,0),(48696520929792792,72060342816997376,0),(48697620441420568,72058143793741824,1099511627776),(120753015456092952,549755813888,3298534883328)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step512
  · subst C; exact step516
  · subst C; exact step517
  · subst C; exact step518
theorem step520 : NodeGood bank Hit (264885245962178840,0,0) := by
  exact leaf bank Hit 264885245962178840 0 ⟨264885245962178840,by decide +kernel,rfl⟩
theorem step521 : NodeGood bank Hit (120770057886322968,144115188075855872,0) := by
  apply use_pivot bank Hit sym noLoop 120770057886322968 144115188075855872 0 57 [57] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 120770057886322968 144115188075855872 0 ([57] : List (Fin n))=[(264885245962178840,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step520
theorem step522 : NodeGood bank Hit (48712463848395032,216172782113783808,0) := by
  apply use_pivot bank Hit sym noLoop 48712463848395032 216172782113783808 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48712463848395032 216172782113783808 0 ([56] : List (Fin n))=[(120770057886322968,144115188075855872,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step521
theorem step523 : NodeGood bank Hit (48703667755372824,216181578206806016,0) := by
  apply use_pivot bank Hit sym noLoop 48703667755372824 216181578206806016 0 43 [43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48703667755372824 216181578206806016 0 ([43] : List (Fin n))=[(48712463848395032,216172782113783808,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step522
theorem step524 : NodeGood bank Hit (48701468732117272,216183777230061568,0) := by
  apply use_pivot bank Hit sym noLoop 48701468732117272 216183777230061568 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48701468732117272 216183777230061568 0 ([41] : List (Fin n))=[(48703667755372824,216181578206806016,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step523
theorem step525 : NodeGood bank Hit (48700369220489496,216184876741689344,0) := by
  apply use_pivot bank Hit sym noLoop 48700369220489496 216184876741689344 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48700369220489496 216184876741689344 0 ([40] : List (Fin n))=[(48701468732117272,216183777230061568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step524
theorem step526 : NodeGood bank Hit (48699819464675608,216185426497503232,0) := by
  apply use_pivot bank Hit sym noLoop 48699819464675608 216185426497503232 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48699819464675608 216185426497503232 0 ([39] : List (Fin n))=[(48700369220489496,216184876741689344,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step525
theorem step527 : NodeGood bank Hit (48704217511186712,216176630404481024,4398046511104) := by
  apply use_pivot bank Hit sym noLoop 48704217511186712 216176630404481024 4398046511104 42 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48704217511186712 216176630404481024 4398046511104 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
end IU.Trace5
