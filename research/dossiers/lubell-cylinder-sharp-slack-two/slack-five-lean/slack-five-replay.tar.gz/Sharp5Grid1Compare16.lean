import Sharp5Grid1Compare15
import Sharp5HistPart20
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot64 : ∀ i j : Fin 8, dot data histograms[64]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare64 : ∀ i j : Fin 8, sumTable data 117111179541827928 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts64, hist_sound data _ _ counts6] <;> exact dot64 i j
theorem dot65 : ∀ i j : Fin 8, dot data histograms[65]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare65 : ∀ i j : Fin 8, sumTable data 117379185501098968 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts65, hist_sound data _ _ counts6] <;> exact dot65 i j
theorem dot66 : ∀ i j : Fin 8, dot data histograms[66]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare66 : ∀ i j : Fin 8, sumTable data 117383583547609560 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts66, hist_sound data _ _ counts6] <;> exact dot66 i j
theorem dot67 : ∀ i j : Fin 8, dot data histograms[67]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare67 : ∀ i j : Fin 8, sumTable data 117392379640631640 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts67, hist_sound data _ _ counts6] <;> exact dot67 i j
end IU.Sharp5.Cone1
