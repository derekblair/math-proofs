import Sharp5HistPart9
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts50 : ∀ q : Fin 20, ((members n 45319392439918552).filter (fun v => code v=q)).card=(histograms[50]!)[q.val]! := by decide +kernel
theorem counts51 : ∀ q : Fin 20, ((members n 45321591463172056).filter (fun v => code v=q)).card=(histograms[51]!)[q.val]! := by decide +kernel
theorem counts52 : ∀ q : Fin 20, ((members n 45323790486429144).filter (fun v => code v=q)).card=(histograms[52]!)[q.val]! := by decide +kernel
theorem counts53 : ∀ q : Fin 20, ((members n 45325989509682648).filter (fun v => code v=q)).card=(histograms[53]!)[q.val]! := by decide +kernel
theorem counts54 : ∀ q : Fin 20, ((members n 45334785602704728).filter (fun v => code v=q)).card=(histograms[54]!)[q.val]! := by decide +kernel
end IU.Sharp5
