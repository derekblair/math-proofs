import Mathlib.Algebra.Group.ForwardDiff
import Mathlib.Data.Rat.Cast.Order
import Mathlib.Algebra.Order.BigOperators.Group.Finset

namespace IU.Newton
open Polynomial Finset Function
open scoped BigOperators fwdDiff

theorem polynomial_nonneg (P : ℚ[X]) (d : Nat)
    (hd : P.natDegree≤d)
    (h : ∀ j≤d, 0≤((fwdDiff (1:ℚ))^[j] P.eval) 0) (b : Nat) :
    0≤P.eval (b:ℚ) := by
  have hb : (0:ℚ)+b • (1:ℚ)=(b:ℚ) := by simp
  rw [←hb,shift_eq_sum_fwdDiff_iter (1:ℚ) P.eval b 0]
  apply Finset.sum_nonneg
  intro j _
  apply nsmul_nonneg
  by_cases hj : j≤d
  · exact h j hj
  · rw [Polynomial.fwdDiff_iter_eq_zero_of_degree_lt (lt_of_le_of_lt hd (Nat.lt_of_not_ge hj))]
    simp

noncomputable def piece (P : (ℚ[X])[X]) (i : Nat) : ℚ[X] :=
  ((fwdDiff (1:ℚ[X]))^[i] P.eval) 0

theorem two_variable_nonneg (P : (ℚ[X])[X]) (d e : Nat)
    (hd : P.natDegree≤d)
    (he : ∀ i≤d,(piece P i).natDegree≤e)
    (h : ∀ i≤d, ∀ j≤e, 0≤((fwdDiff (1:ℚ))^[j] (piece P i).eval) 0)
    (a b : Nat) : 0≤(P.eval (a:ℚ[X])).eval (b:ℚ) := by
  have ha : (0:ℚ[X])+a • (1:ℚ[X])=(a:ℚ[X]) := by simp
  rw [←ha,shift_eq_sum_fwdDiff_iter (1:ℚ[X]) P.eval a 0]
  simp only [eval_finsetSum]
  apply Finset.sum_nonneg
  intro i _
  change 0≤(evalRingHom (b:ℚ)) (a.choose i • piece P i)
  rw [map_nsmul]
  change 0≤a.choose i • (piece P i).eval (b:ℚ)
  apply nsmul_nonneg
  by_cases hi : i≤d
  · exact polynomial_nonneg (piece P i) e (he i hi) (h i hi) b
  · unfold piece
    rw [Polynomial.fwdDiff_iter_eq_zero_of_degree_lt (lt_of_le_of_lt hd (Nat.lt_of_not_ge hi))]
    simp

#print axioms polynomial_nonneg
#print axioms two_variable_nonneg
end IU.Newton
