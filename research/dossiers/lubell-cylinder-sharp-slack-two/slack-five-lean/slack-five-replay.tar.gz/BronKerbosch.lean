import BronKerboschCore
import Mathlib.Data.Finset.Max

namespace BK
open Finset
variable {α : Type} [LinearOrder α]
variable (E : α → α → Prop) [DecidableRel E]

abbrev State (α) := Finset α × Finset α × Finset α

def build (R P X : Finset α) : List α → List (State α)
  | [] => []
  | v::vs => (insert v R,P.filter (E v),X.filter (E v)) ::
      build R (P.erase v) (insert v X) vs

def Covers (Q R P X : Finset α) : Prop :=
  R⊆Q ∧ Q⊆R∪P ∧ Disjoint Q X

theorem build_cover {Q R P X : Finset α} (cl : Clique E Q)
    (cover : Covers Q R P X) (vs : List α) (hit : ∃ v∈vs, v∈Q) :
    ∃ i∈build E R P X vs, Covers Q i.1 i.2.1 i.2.2 := by
  induction vs generalizing P X with
  | nil => simp at hit
  | cons v vs ih =>
    by_cases hv : v∈Q
    · exact ⟨_,List.mem_cons_self,child_cover cl cover.2.1 cover.1 cover.2.2 hv⟩
    · have dis : Disjoint Q (insert v X) := disjoint_left.mpr (by
        intro x a ex
        rcases mem_insert.mp ex with rfl|h
        · exact hv a
        · exact disjoint_left.mp cover.2.2 a h)
      have cut : Q⊆R∪P.erase v := by
        intro x a
        rcases mem_union.mp (cover.2.1 a) with r|p
        · exact mem_union.mpr (Or.inl r)
        · exact mem_union.mpr (Or.inr (mem_erase.mpr ⟨fun e => hv (e ▸ a),p⟩))
      obtain ⟨j,jv,jq⟩ := hit
      have jt : j∈vs := (List.mem_cons.mp jv).resolve_left (fun e => hv (e ▸ jq))
      obtain ⟨i,a,b⟩ := ih ⟨cover.1,cut,dis⟩ ⟨j,jt,jq⟩
      exact ⟨i,List.mem_cons_of_mem _ a,b⟩

def NeighborsOf (R P X : Finset α) : Prop := ∀ v∈P∪X, ∀ w∈R, E v w

theorem build_neighbors (sym : Symmetric E) {R P X : Finset α}
    (adj : NeighborsOf E R P X) (vs : List α) (hvs : ∀ v∈vs, v∈P) (dn : vs.Nodup) :
    ∀ i∈build E R P X vs, NeighborsOf E i.1 i.2.1 i.2.2 := by
  induction vs generalizing P X with
  | nil => simp [build]
  | cons v vs ih =>
    intro i hi
    have vP : v∈P := hvs _ List.mem_cons_self
    have vR := adj _ (mem_union.mpr (Or.inl vP))
    rcases List.mem_cons.mp hi with e|e
    · subst i
      intro y yp z zr
      have yz := mem_union.mp yp
      have yV : y∈P∪X := by
        rcases yz with a|b
        · exact mem_union.mpr (Or.inl (mem_filter.mp a).1)
        · exact mem_union.mpr (Or.inr (mem_filter.mp b).1)
      rcases mem_insert.mp zr with rfl|zR
      · rcases yz with a|b
        · exact sym (mem_filter.mp a).2
        · exact sym (mem_filter.mp b).2
      · exact adj _ yV _ zR
    · apply ih ?_ ?_ (List.nodup_cons.mp dn).2 i e
      · intro y yp z zr
        rcases mem_union.mp yp with a|b
        · exact adj _ (mem_union.mpr (Or.inl (mem_of_mem_erase a))) _ zr
        · rcases mem_insert.mp b with rfl|a
          · exact vR _ zr
          · exact adj _ (mem_union.mpr (Or.inr a)) _ zr
      · intro y h
        exact mem_erase.mpr ⟨fun yes => (List.nodup_cons.mp dn).1 (yes ▸ h),
          hvs _ (List.mem_cons_of_mem _ h)⟩

end BK
