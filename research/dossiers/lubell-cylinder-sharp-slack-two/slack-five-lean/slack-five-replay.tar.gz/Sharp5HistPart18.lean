import Sharp5HistPart17
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts90 : ∀ q : Fin 20, ((members n 837739896479240456).filter (fun v => code v=q)).card=(histograms[90]!)[q.val]! := by decide +kernel
theorem counts91 : ∀ q : Fin 20, ((members n 838021096578044168).filter (fun v => code v=q)).card=(histograms[91]!)[q.val]! := by decide +kernel
theorem counts92 : ∀ q : Fin 20, ((members n 839146979305017608).filter (fun v => code v=q)).card=(histograms[92]!)[q.val]! := by decide +kernel
theorem counts93 : ∀ q : Fin 20, ((members n 841398774823735560).filter (fun v => code v=q)).card=(histograms[93]!)[q.val]! := by decide +kernel
theorem counts94 : ∀ q : Fin 20, ((members n 857161377797722376).filter (fun v => code v=q)).card=(histograms[94]!)[q.val]! := by decide +kernel
end IU.Sharp5
