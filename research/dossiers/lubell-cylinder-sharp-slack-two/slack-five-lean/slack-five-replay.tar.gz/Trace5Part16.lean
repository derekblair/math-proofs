import Trace5Part15
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step256 : NodeGood bank Hit (4395090925528,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 4395090925528 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4395090925528 9007199523176451 0 ([0,53] : List (Fin n))=[(4395090925529,268435458,0),(9011594345666520,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step254
  · subst C; exact step255
theorem step257 : NodeGood bank Hit (45040391364368344,0,0) := by
  exact leaf bank Hit 45040391364368344 0 ⟨45040391364368344,by decide +kernel,rfl⟩
theorem step258 : NodeGood bank Hit (36033192109627352,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 36033192109627352 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36033192109627352 9007199254740992 0 ([53] : List (Fin n))=[(45040391364368344,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step257
theorem step259 : NodeGood bank Hit (4395090663384,45035996542402563,0) := by
  apply use_pivot bank Hit sym noLoop 4395090663384 45035996542402563 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4395090663384 45035996542402563 0 ([18,55] : List (Fin n))=[(4395090925528,9007199523176451,0),(36033192109627352,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step256
  · subst C; exact step258
theorem step260 : NodeGood bank Hit (45321591463172056,0,0) := by
  exact leaf bank Hit 45321591463172056 0 ⟨45321591463172056,by decide +kernel,rfl⟩
theorem step261 : NodeGood bank Hit (9292794444208088,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 9292794444208088 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9292794444208088 36028797018963968 0 ([55] : List (Fin n))=[(45321591463172056,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step260
theorem step262 : NodeGood bank Hit (285595189467096,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 285595189467096 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 285595189467096 45035996273704960 0 ([53] : List (Fin n))=[(9292794444208088,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step261
theorem step263 : NodeGood bank Hit (4120212756440,45317746397020163,0) := by
  apply use_pivot bank Hit sym noLoop 4120212756440 45317746397020163 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4120212756440 45317746397020163 0 ([38,48] : List (Fin n))=[(4395090663384,45035996542402563,0),(285595189467096,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step259
  · subst C; exact step262
theorem step264 : NodeGood bank Hit (117097985402295256,0,0) := by
  exact leaf bank Hit 117097985402295256 0 ⟨117097985402295256,by decide +kernel,rfl⟩
theorem step265 : NodeGood bank Hit (117379185501098968,0,0) := by
  exact leaf bank Hit 117379185501098968 0 ⟨117379185501098968,by decide +kernel,rfl⟩
theorem step266 : NodeGood bank Hit (117097710524388312,281749854617600,0) := by
  apply use_pivot bank Hit sym noLoop 117097710524388312 281749854617600 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 117097710524388312 281749854617600 0 ([38,48] : List (Fin n))=[(117097985402295256,0,0),(117379185501098968,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step264
  · subst C; exact step265
theorem step267 : NodeGood bank Hit (81068913505424344,36310546873581568,0) := by
  apply use_pivot bank Hit sym noLoop 81068913505424344 36310546873581568 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 81068913505424344 36310546873581568 0 ([55] : List (Fin n))=[(117097710524388312,281749854617600,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step266
theorem step268 : NodeGood bank Hit (72061714250683352,45317746128322560,0) := by
  apply use_pivot bank Hit sym noLoop 72061714250683352 45317746128322560 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 72061714250683352 45317746128322560 0 ([53] : List (Fin n))=[(81068913505424344,36310546873581568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step267
theorem step269 : NodeGood bank Hit (4120212755416,117375340434949123,0) := by
  apply use_pivot bank Hit sym noLoop 4120212755416 117375340434949123 0 10 [10,56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4120212755416 117375340434949123 0 ([10,56] : List (Fin n))=[(4120212756440,45317746397020163,0),(72061714250683352,45317746128322560,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step263
  · subst C; exact step268
theorem step270 : NodeGood bank Hit (118505068228072408,0,0) := by
  exact leaf bank Hit 118505068228072408 0 ⟨118505068228072408,by decide +kernel,rfl⟩
theorem step271 : NodeGood bank Hit (46447474190144472,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 46447474190144472 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 46447474190144472 72057594037927936 0 ([56] : List (Fin n))=[(118505068228072408,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step270
end IU.Trace5
