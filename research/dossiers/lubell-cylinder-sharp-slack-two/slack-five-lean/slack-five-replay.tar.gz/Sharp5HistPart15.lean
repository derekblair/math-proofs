import Sharp5HistPart14
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts75 : ∀ q : Fin 20, ((members n 136730572953310168).filter (fun v => code v=q)).card=(histograms[75]!)[q.val]! := by decide +kernel
theorem counts76 : ∀ q : Fin 20, ((members n 261226367617683736).filter (fun v => code v=q)).card=(histograms[76]!)[q.val]! := by decide +kernel
theorem counts77 : ∀ q : Fin 20, ((members n 261507567716487448).filter (fun v => code v=q)).card=(histograms[77]!)[q.val]! := by decide +kernel
theorem counts78 : ∀ q : Fin 20, ((members n 262633450443460888).filter (fun v => code v=q)).card=(histograms[78]!)[q.val]! := by decide +kernel
theorem counts79 : ∀ q : Fin 20, ((members n 264885245962178840).filter (fun v => code v=q)).card=(histograms[79]!)[q.val]! := by decide +kernel
end IU.Sharp5
