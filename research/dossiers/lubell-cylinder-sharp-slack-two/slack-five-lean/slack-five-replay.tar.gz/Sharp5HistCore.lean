import Sharp5GridSetup
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.List.Lemmas

namespace IU.Sharp5
open Finset IU.BitCert
open scoped BigOperators

def code (v : Fin n) : Fin 20 := ⟨codes[v.val]! % 20,Nat.mod_lt _ (by decide)⟩

theorem code_eq (v : Fin n) : (code v).val=codes[v.val]! := by
  fin_cases v <;> rfl

def dot (tbl : Array (Array Int)) (hist : Array Nat) (i j : Nat) : Int :=
  (List.ofFn fun q : Fin 20 => (hist[q.val]!:Int)*(tbl[q.val]!)[8*i+j]!).sum

theorem hist_sound (tbl : Array (Array Int)) (hist : Array Nat) (R : Nat)
    (cert : ∀ q : Fin 20, ((members n R).filter (fun v => code v=q)).card=hist[q.val]!)
    (i j : Nat) : sumTable tbl R i j=dot tbl hist i j := by
  unfold sumTable dot
  rw [List.sum_ofFn]
  let f (q : Fin 20) := (tbl[q.val]!)[8*i+j]!
  have w : ∀ v : Fin n, readTable tbl v i j=f (code v) := by
    intro v
    simp only [readTable,f,code_eq]
  simp_rw [w]
  rw [←sum_fiberwise_of_maps_to' (t:=univ) (fun _ _ => mem_univ _) f]
  apply sum_congr rfl
  intro q hq
  rw [sum_const,nsmul_eq_mul]
  simpa [f,cert q]

#print axioms hist_sound
end IU.Sharp5
