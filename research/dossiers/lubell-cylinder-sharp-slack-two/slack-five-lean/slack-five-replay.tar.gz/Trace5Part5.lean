import Trace5Part4
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step80 : NodeGood bank Hit (3659768743949080,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 3659768743949080 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 3659768743949080 9007199254740992 0 ([53] : List (Fin n))=[(12666967998690072,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step79
theorem step81 : NodeGood bank Hit (2533868837106456,10133099161583616,0) := by
  apply use_pivot bank Hit sym noLoop 2533868837106456 10133099161583616 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2533868837106456 10133099161583616 0 ([50] : List (Fin n))=[(3659768743949080,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step80
theorem step82 : NodeGood bank Hit (2252393860395800,10414574138294272,0) := by
  apply use_pivot bank Hit sym noLoop 2252393860395800 10414574138294272 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2252393860395800 10414574138294272 0 ([48] : List (Fin n))=[(2533868837106456,10133099161583616,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step81
theorem step83 : NodeGood bank Hit (2252393726178072,10414574272512000,0) := by
  apply use_pivot bank Hit sym noLoop 2252393726178072 10414574272512000 0 27 [27] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2252393726178072 10414574272512000 0 ([27] : List (Fin n))=[(2252393860395800,10414574138294272,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step82
theorem step84 : NodeGood bank Hit (2252393709400856,10414574289289216,0) := by
  apply use_pivot bank Hit sym noLoop 2252393709400856 10414574289289216 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2252393709400856 10414574289289216 0 ([24] : List (Fin n))=[(2252393726178072,10414574272512000,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step83
theorem step85 : NodeGood bank Hit (593895715608,30892176003828935,0) := by
  apply use_pivot bank Hit sym noLoop 593895715608 30892176003828935 0 6 [6,51] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 593895715608 30892176003828935 0 ([6,51] : List (Fin n))=[(593895715672,28640376190143623,0),(2252393709400856,10414574289289216,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step78
  · subst C; exact step84
theorem step86 : NodeGood bank Hit (592821973784,30892177077570759,0) := by
  apply use_pivot bank Hit sym noLoop 592821973784 30892177077570759 0 30 [30] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 592821973784 30892177077570759 0 ([30] : List (Fin n))=[(593895715608,30892176003828935,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step85
theorem step87 : NodeGood bank Hit (592821973768,30892177077570775,0) := by
  apply use_pivot bank Hit sym noLoop 592821973768 30892177077570775 0 4 [4] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 592821973768 30892177077570775 0 ([4] : List (Fin n))=[(592821973784,30892177077570759,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step86
theorem step88 : NodeGood bank Hit (1170092071159165696,0,0) := by
  exact leaf bank Hit 1170092071159165696 0 ⟨1170092071159165696,by decide +kernel,rfl⟩
theorem step89 : NodeGood bank Hit (17170566552318720,1152921504606846976,0) := by
  apply use_pivot bank Hit sym noLoop 17170566552318720 1152921504606846976 0 60 [60] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17170566552318720 1152921504606846976 0 ([60] : List (Fin n))=[(1170092071159165696,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step88
theorem step90 : NodeGood bank Hit (8163367297577728,1161928703861587968,0) := by
  apply use_pivot bank Hit sym noLoop 8163367297577728 1161928703861587968 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8163367297577728 1161928703861587968 0 ([53] : List (Fin n))=[(17170566552318720,1152921504606846976,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step89
theorem step91 : NodeGood bank Hit (5911567483892480,1164180503675273216,0) := by
  apply use_pivot bank Hit sym noLoop 5911567483892480 1164180503675273216 0 51 [51] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 5911567483892480 1164180503675273216 0 ([51] : List (Fin n))=[(8163367297577728,1161928703861587968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step90
theorem step92 : NodeGood bank Hit (4785667577049856,1165306403582115840,0) := by
  apply use_pivot bank Hit sym noLoop 4785667577049856 1165306403582115840 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4785667577049856 1165306403582115840 0 ([50] : List (Fin n))=[(5911567483892480,1164180503675273216,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step91
theorem step93 : NodeGood bank Hit (4504192600339200,1165587878558826496,0) := by
  apply use_pivot bank Hit sym noLoop 4504192600339200 1165587878558826496 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4504192600339200 1165587878558826496 0 ([48] : List (Fin n))=[(4785667577049856,1165306403582115840,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step92
theorem step94 : NodeGood bank Hit (4504192466121472,1165587878693044224,0) := by
  apply use_pivot bank Hit sym noLoop 4504192466121472 1165587878693044224 0 27 [27] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4504192466121472 1165587878693044224 0 ([27] : List (Fin n))=[(4504192600339200,1165587878558826496,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step93
theorem step95 : NodeGood bank Hit (4504192449344256,1165587878709821440,0) := by
  apply use_pivot bank Hit sym noLoop 4504192449344256 1165587878709821440 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4504192449344256 1165587878709821440 0 ([24] : List (Fin n))=[(4504192466121472,1165587878693044224,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step94
end IU.Trace5
