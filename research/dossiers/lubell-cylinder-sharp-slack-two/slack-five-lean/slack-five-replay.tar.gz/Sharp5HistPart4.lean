import Sharp5HistPart3
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts20 : ∀ q : Fin 20, ((members n 70366057026889).filter (fun v => code v=q)).card=(histograms[20]!)[q.val]! := by decide +kernel
theorem counts21 : ∀ q : Fin 20, ((members n 282092444418040).filter (fun v => code v=q)).card=(histograms[21]!)[q.val]! := by decide +kernel
theorem counts22 : ∀ q : Fin 20, ((members n 1407975171388408).filter (fun v => code v=q)).card=(histograms[22]!)[q.val]! := by decide +kernel
theorem counts23 : ∀ q : Fin 20, ((members n 3659770690106168).filter (fun v => code v=q)).card=(histograms[23]!)[q.val]! := by decide +kernel
theorem counts24 : ∀ q : Fin 20, ((members n 9007471177236440).filter (fun v => code v=q)).card=(histograms[24]!)[q.val]! := by decide +kernel
end IU.Sharp5
