import UniversalScore
import DenseBridge5
import DenseBridge4
import UnpackProfile

namespace IU.DenseCert
open Finset IU.Universal IU.Slack IU.PolyCert
open scoped BigOperators

theorem list_get_cast {α : Type} {L M : List α} (eq : L=M) (i : Fin L.length) :
    M.get (Fin.cast (congrArg List.length eq) i)=L.get i := by
  subst M
  rfl

theorem cast_vertices5 (a : Fin (vertexList 5).length) :
    orig5 (Fin.cast vertices5 a) = (vertexList 5).get a :=
  list_get_cast coords5_eq a

theorem cast_vertices4 (a : Fin (vertexList 4).length) :
    orig4 (Fin.cast vertices4 a) = (vertexList 4).get a :=
  list_get_cast coords4_eq a

theorem raw_dense_upper {s n t u k : Nat} {F : IU.Sys}
    (ht : 0<t) (ok : IU.IsIU F (t+u+s) t u)
    (e : Fin (vertexList s).length ↪ Fin n)
    (bank : Array Nat) (orig : Fin n → Vertex)
    (vs : ∀ a,orig (e a)=(vertexList s).get a)
    (edges : ∀ a b, IU.Universal.edge s a b → edge bank (e a) (e b))
    (H : ∀ A : Finset (Fin n), BK.MaxClique (edge bank) A →
      sumN t u (fun i => shapeOf s (orig i)) A≤k) :
    rawSum (t+u+s) F ≤ normalization t u s * (k:ℚ) := by
  apply raw_bound_from_profile_maxima ht ok
  intro A c
  have mc : BK.Clique (edge bank) (A.map e) := by
    intro x hx y hy ne
    obtain ⟨a,ha,rfl⟩ := mem_map.mp hx
    obtain ⟨b,hb,rfl⟩ := mem_map.mp hy
    exact edges a b (c.1 a ha b hb (fun eq => ne (congrArg e eq)))
  obtain ⟨Q,Qmax,sub⟩ := BK.extend_to_max mc
  have h := sum_le_sum_of_subset (f:=fun i => scoreN t u (shapeOf s (orig i))) sub
  have wt : sumN t u (fun i => shapeOf s (orig i)) (A.map e) =
      sumN t u (fun i => shapeOf s (vertexList s)[i]) A := by
    unfold sumN
    rw [sum_map]
    apply sum_congr rfl
    intro i _
    change scoreN t u (shapeOf s (orig (e i))) = scoreN t u (shapeOf s ((vertexList s).get i))
    rw [vs]
  rw [←wt]
  exact h.trans (H Q Qmax)

#print axioms raw_dense_upper
end IU.DenseCert
