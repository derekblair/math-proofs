import Sharp5Grid0Compare2
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot12 : ∀ i j : Fin 8, dot data histograms[12]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare12 : ∀ i j : Fin 8, sumTable data 2196336107483 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts12, hist_sound data _ _ counts6] <;> exact dot12 i j
theorem dot13 : ∀ i j : Fin 8, dot data histograms[13]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare13 : ∀ i j : Fin 8, sumTable data 4395359360987 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts13, hist_sound data _ _ counts6] <;> exact dot13 i j
theorem dot14 : ∀ i j : Fin 8, dot data histograms[14]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare14 : ∀ i j : Fin 8, sumTable data 6456944188891 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts14, hist_sound data _ _ counts6] <;> exact dot14 i j
theorem dot15 : ∀ i j : Fin 8, dot data histograms[15]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare15 : ∀ i j : Fin 8, sumTable data 6457346842079 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts15, hist_sound data _ _ counts6] <;> exact dot15 i j
end IU.Sharp5.Cone0
