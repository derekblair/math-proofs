import Trace5Part18
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step304 : NodeGood bank Hit (8793405871579,0,0) := by
  exact leaf bank Hit 8793405871579 0 ⟨8793405871579,by decide +kernel,rfl⟩
theorem step305 : NodeGood bank Hit (8793137436123,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 8793137436123 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8793137436123 268435456 0 ([28] : List (Fin n))=[(8793405871579,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step304
theorem step306 : NodeGood bank Hit (8793137436121,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 8793137436121 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8793137436121 268435458 0 ([1] : List (Fin n))=[(8793137436123,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step305
theorem step307 : NodeGood bank Hit (9015992392177112,0,0) := by
  exact leaf bank Hit 9015992392177112 0 ⟨9015992392177112,by decide +kernel,rfl⟩
theorem step308 : NodeGood bank Hit (8793137436120,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 8793137436120 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8793137436120 9007199523176451 0 ([0,53] : List (Fin n))=[(8793137436121,268435458,0),(9015992392177112,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step306
  · subst C; exact step307
theorem step309 : NodeGood bank Hit (45044789410878936,0,0) := by
  exact leaf bank Hit 45044789410878936 0 ⟨45044789410878936,by decide +kernel,rfl⟩
theorem step310 : NodeGood bank Hit (36037590156137944,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 36037590156137944 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36037590156137944 9007199254740992 0 ([53] : List (Fin n))=[(45044789410878936,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step309
theorem step311 : NodeGood bank Hit (8793137173976,45035996542402563,0) := by
  apply use_pivot bank Hit sym noLoop 8793137173976 45035996542402563 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8793137173976 45035996542402563 0 ([18,55] : List (Fin n))=[(8793137436120,9007199523176451,0),(36037590156137944,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step308
  · subst C; exact step310
theorem step312 : NodeGood bank Hit (45325989509682648,0,0) := by
  exact leaf bank Hit 45325989509682648 0 ⟨45325989509682648,by decide +kernel,rfl⟩
theorem step313 : NodeGood bank Hit (9297192490718680,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 9297192490718680 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9297192490718680 36028797018963968 0 ([55] : List (Fin n))=[(45325989509682648,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step312
theorem step314 : NodeGood bank Hit (289993235977688,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 289993235977688 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 289993235977688 45035996273704960 0 ([53] : List (Fin n))=[(9297192490718680,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step313
theorem step315 : NodeGood bank Hit (8518259267032,45317746397020163,0) := by
  apply use_pivot bank Hit sym noLoop 8518259267032 45317746397020163 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 8518259267032 45317746397020163 0 ([38,48] : List (Fin n))=[(8793137173976,45035996542402563,0),(289993235977688,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step311
  · subst C; exact step314
theorem step316 : NodeGood bank Hit (6319236011480,45319945420277763,0) := by
  apply use_pivot bank Hit sym noLoop 6319236011480 45319945420277763 0 11 [11,41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6319236011480 45319945420277763 0 ([11,41] : List (Fin n))=[(6319236013528,45317746397020163,0),(8518259267032,45317746397020163,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step303
  · subst C; exact step315
theorem step317 : NodeGood bank Hit (117102383448805848,0,0) := by
  exact leaf bank Hit 117102383448805848 0 ⟨117102383448805848,by decide +kernel,rfl⟩
theorem step318 : NodeGood bank Hit (117383583547609560,0,0) := by
  exact leaf bank Hit 117383583547609560 0 ⟨117383583547609560,by decide +kernel,rfl⟩
theorem step319 : NodeGood bank Hit (117102108570898904,281749854617600,0) := by
  apply use_pivot bank Hit sym noLoop 117102108570898904 281749854617600 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 117102108570898904 281749854617600 0 ([38,48] : List (Fin n))=[(117102383448805848,0,0),(117383583547609560,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step317
  · subst C; exact step318
end IU.Trace5
