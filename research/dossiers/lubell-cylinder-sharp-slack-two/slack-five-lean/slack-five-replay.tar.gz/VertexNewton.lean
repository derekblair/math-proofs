import DominanceScore
namespace IU.PolyCert
open Finset
open scoped BigOperators

variable {α : Type}

def vcoeff (T U : Coeff) (v : Shape) (i j : Nat) : Int :=
  ∑ l∈range (j+1), IU.Newton.coeff j l *
    ∑ k∈range (i+1), IU.Newton.coeff i k * (scoreN (param T k l) (param U k l) v:Int)

/-- Newton coefficient of a clique score is the sum of the coefficients
of its vertices. The coefficient table may be verified once per vertex. -/
theorem cert_linear (T U : Coeff) (shape : α → Shape) (A C : Finset α)
    (i j : Nat) :
    certAt T U shape A C i j =
      (∑ v∈A, vcoeff T U (shape v) i j) - ∑ v∈C, vcoeff T U (shape v) i j := by
  have commute (S : Finset α) :
      (∑ l∈range (j+1), ∑ k∈range (i+1), ∑ v∈S, IU.Newton.coeff j l *
        (IU.Newton.coeff i k * (scoreN (param T k l) (param U k l) (shape v):Int))) =
      ∑ v∈S, ∑ l∈range (j+1), ∑ k∈range (i+1), IU.Newton.coeff j l *
        (IU.Newton.coeff i k * (scoreN (param T k l) (param U k l) (shape v):Int)) := by
    calc
      _ = ∑ l∈range (j+1), ∑ v∈S, ∑ k∈range (i+1), IU.Newton.coeff j l *
         (IU.Newton.coeff i k * (scoreN (param T k l) (param U k l) (shape v):Int)) := by
        apply sum_congr rfl
        intro l _
        exact sum_comm
      _ = _ := sum_comm
  unfold certAt diffN sumN vcoeff
  simp only [Nat.cast_sum,mul_sub,sum_sub_distrib,mul_sum]
  rw [commute A,commute C]

#print axioms cert_linear
end IU.PolyCert
