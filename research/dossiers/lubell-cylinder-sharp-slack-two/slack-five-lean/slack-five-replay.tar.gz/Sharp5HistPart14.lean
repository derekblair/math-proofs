import Sharp5HistPart13
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts70 : ∀ q : Fin 20, ((members n 118518262367605080).filter (fun v => code v=q)).card=(histograms[70]!)[q.val]! := by decide +kernel
theorem counts71 : ∀ q : Fin 20, ((members n 120756863746790168).filter (fun v => code v=q)).card=(histograms[71]!)[q.val]! := by decide +kernel
theorem counts72 : ∀ q : Fin 20, ((members n 136523864767287768).filter (fun v => code v=q)).card=(histograms[72]!)[q.val]! := by decide +kernel
theorem counts73 : ∀ q : Fin 20, ((members n 136532660860309848).filter (fun v => code v=q)).card=(histograms[73]!)[q.val]! := by decide +kernel
theorem counts74 : ∀ q : Fin 20, ((members n 136598631557976408).filter (fun v => code v=q)).card=(histograms[74]!)[q.val]! := by decide +kernel
end IU.Sharp5
