import Trace5Part5
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step96 : NodeGood bank Hit (1152922097428820736,12666374102974464,4503599627370496) := by
  apply use_pivot bank Hit sym noLoop 1152922097428820736 12666374102974464 4503599627370496 52 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1152922097428820736 12666374102974464 4503599627370496 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step97 : NodeGood bank Hit (592821973760,1188317281311788255,0) := by
  apply use_pivot bank Hit sym noLoop 592821973760 1188317281311788255 0 3 [3,52,60] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 592821973760 1188317281311788255 0 ([3,52,60] : List (Fin n))=[(592821973768,30892177077570775,0),(4504192449344256,1165587878709821440,0),(1152922097428820736,12666374102974464,4503599627370496)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h
  · subst C; exact step87
  · subst C; exact step95
  · subst C; exact step96
theorem step98 : NodeGood bank Hit (43066159872,1188317831067602143,0) := by
  apply use_pivot bank Hit sym noLoop 43066159872 1188317831067602143 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 43066159872 1188317831067602143 0 ([39] : List (Fin n))=[(592821973760,1188317281311788255,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step97
theorem step99 : NodeGood bank Hit (43066151680,1188317831067610335,0) := by
  apply use_pivot bank Hit sym noLoop 43066151680 1188317831067610335 0 13 [13] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 43066151680 1188317831067610335 0 ([13] : List (Fin n))=[(43066159872,1188317831067602143,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step98
theorem step100 : NodeGood bank Hit (43066151168,1188317831067610847,0) := by
  apply use_pivot bank Hit sym noLoop 43066151168 1188317831067610847 0 9 [9] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 43066151168 1188317831067610847 0 ([9] : List (Fin n))=[(43066151680,1188317831067610335,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step99
theorem step101 : NodeGood bank Hit (410032930783,0,0) := by
  exact leaf bank Hit 410032930783 0 ⟨410032930783,by decide +kernel,rfl⟩
theorem step102 : NodeGood bank Hit (959788711903,0,0) := by
  exact leaf bank Hit 959788711903 0 ⟨959788711903,by decide +kernel,rfl⟩
theorem step103 : NodeGood bank Hit (410032898015,549755846656,0) := by
  apply use_pivot bank Hit sym noLoop 410032898015 549755846656 0 15 [15,39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 410032898015 549755846656 0 ([15,39] : List (Fin n))=[(410032930783,0,0),(959788711903,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step101
  · subst C; exact step102
theorem step104 : NodeGood bank Hit (2059300331487,0,0) := by
  exact leaf bank Hit 2059300331487 0 ⟨2059300331487,by decide +kernel,rfl⟩
theorem step105 : NodeGood bank Hit (1509544517599,549755813888,0) := by
  apply use_pivot bank Hit sym noLoop 1509544517599 549755813888 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1509544517599 549755813888 0 ([39] : List (Fin n))=[(2059300331487,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step104
theorem step106 : NodeGood bank Hit (410032889823,1649267482624,0) := by
  apply use_pivot bank Hit sym noLoop 410032889823 1649267482624 0 13 [13,40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 410032889823 1649267482624 0 ([13,40] : List (Fin n))=[(410032898015,549755846656,0),(1509544517599,549755813888,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step103
  · subst C; exact step105
theorem step107 : NodeGood bank Hit (6457346842079,0,0) := by
  exact leaf bank Hit 6457346842079 0 ⟨6457346842079,by decide +kernel,rfl⟩
theorem step108 : NodeGood bank Hit (5357835214303,1099511627776,0) := by
  apply use_pivot bank Hit sym noLoop 5357835214303 1099511627776 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 5357835214303 1099511627776 0 ([40] : List (Fin n))=[(6457346842079,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step107
theorem step109 : NodeGood bank Hit (4808079400415,1649267441664,0) := by
  apply use_pivot bank Hit sym noLoop 4808079400415 1649267441664 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4808079400415 1649267441664 0 ([39] : List (Fin n))=[(5357835214303,1099511627776,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step108
theorem step110 : NodeGood bank Hit (410032889311,6047313994240,0) := by
  apply use_pivot bank Hit sym noLoop 410032889311 6047313994240 0 9 [9,42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 410032889311 6047313994240 0 ([9,42] : List (Fin n))=[(410032889823,1649267482624,0),(4808079400415,1649267441664,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step106
  · subst C; exact step109
theorem step111 : NodeGood bank Hit (135154982367,6322191901184,0) := by
  apply use_pivot bank Hit sym noLoop 135154982367 6322191901184 0 38 [38] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 135154982367 6322191901184 0 ([38] : List (Fin n))=[(410032889311,6047313994240,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step110
end IU.Trace5
