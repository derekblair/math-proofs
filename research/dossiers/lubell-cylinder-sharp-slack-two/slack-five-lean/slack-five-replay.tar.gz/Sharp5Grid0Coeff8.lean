import Sharp5Grid0Coeff7
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry16 : ∀ i j : Fin 8, vcoeff T U shapeBank[16]! i.val j.val=(data[16]!)[8*i.val+j.val]! := by decide +kernel
theorem entry17 : ∀ i j : Fin 8, vcoeff T U shapeBank[17]! i.val j.val=(data[17]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone0
