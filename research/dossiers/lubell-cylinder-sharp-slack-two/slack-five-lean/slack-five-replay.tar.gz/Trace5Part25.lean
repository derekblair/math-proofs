import Trace5Part24
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step400 : NodeGood bank Hit (621848314464261448,0,0) := by
  exact leaf bank Hit 621848314464261448 0 ⟨621848314464261448,by decide +kernel,rfl⟩
theorem step401 : NodeGood bank Hit (45387562160837960,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 45387562160837960 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 45387562160837960 576460752303423488 0 ([59] : List (Fin n))=[(621848314464261448,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step400
theorem step402 : NodeGood bank Hit (9358765141873992,612489549322387456,0) := by
  apply use_pivot bank Hit sym noLoop 9358765141873992 612489549322387456 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9358765141873992 612489549322387456 0 ([55] : List (Fin n))=[(45387562160837960,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step401
theorem step403 : NodeGood bank Hit (351565887133000,621496748577128448,0) := by
  apply use_pivot bank Hit sym noLoop 351565887133000 621496748577128448 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 351565887133000 621496748577128448 0 ([53] : List (Fin n))=[(9358765141873992,612489549322387456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step402
theorem step404 : NodeGood bank Hit (316381515044168,621531932949217280,0) := by
  apply use_pivot bank Hit sym noLoop 316381515044168 621531932949217280 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 316381515044168 621531932949217280 0 ([45] : List (Fin n))=[(351565887133000,621496748577128448,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step403
theorem step405 : NodeGood bank Hit (34906538333512,621813683072532483,0) := by
  apply use_pivot bank Hit sym noLoop 34906538333512 621813683072532483 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 34906538333512 621813683072532483 0 ([38,48] : List (Fin n))=[(35181416240456,621531933217914883,0),(316381515044168,621531932949217280,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step399
  · subst C; exact step404
theorem step406 : NodeGood bank Hit (693624708403384648,0,0) := by
  exact leaf bank Hit 693624708403384648 0 ⟨693624708403384648,by decide +kernel,rfl⟩
theorem step407 : NodeGood bank Hit (693905908502188360,0,0) := by
  exact leaf bank Hit 693905908502188360 0 ⟨693905908502188360,by decide +kernel,rfl⟩
theorem step408 : NodeGood bank Hit (693624433525477704,281749854617600,0) := by
  apply use_pivot bank Hit sym noLoop 693624433525477704 281749854617600 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 693624433525477704 281749854617600 0 ([38,48] : List (Fin n))=[(693624708403384648,0,0),(693905908502188360,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step406
  · subst C; exact step407
theorem step409 : NodeGood bank Hit (117163681222054216,576742502158041088,0) := by
  apply use_pivot bank Hit sym noLoop 117163681222054216 576742502158041088 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 117163681222054216 576742502158041088 0 ([59] : List (Fin n))=[(693624433525477704,281749854617600,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step408
theorem step410 : NodeGood bank Hit (81134884203090248,612771299177005056,0) := by
  apply use_pivot bank Hit sym noLoop 81134884203090248 612771299177005056 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 81134884203090248 612771299177005056 0 ([55] : List (Fin n))=[(117163681222054216,576742502158041088,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step409
theorem step411 : NodeGood bank Hit (72127684948349256,621778498431746048,0) := by
  apply use_pivot bank Hit sym noLoop 72127684948349256 621778498431746048 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 72127684948349256 621778498431746048 0 ([53] : List (Fin n))=[(81134884203090248,612771299177005056,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step410
theorem step412 : NodeGood bank Hit (72092500576260424,621813682803834880,0) := by
  apply use_pivot bank Hit sym noLoop 72092500576260424 621813682803834880 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 72092500576260424 621813682803834880 0 ([45] : List (Fin n))=[(72127684948349256,621778498431746048,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step411
theorem step413 : NodeGood bank Hit (34906538332488,693871277110461443,0) := by
  apply use_pivot bank Hit sym noLoop 34906538332488 693871277110461443 0 10 [10,56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 34906538332488 693871277110461443 0 ([10,56] : List (Fin n))=[(34906538333512,621813683072532483,0),(72092500576260424,621813682803834880,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step405
  · subst C; exact step412
theorem step414 : NodeGood bank Hit (695031791229161800,0,0) := by
  exact leaf bank Hit 695031791229161800 0 ⟨695031791229161800,by decide +kernel,rfl⟩
theorem step415 : NodeGood bank Hit (118571038925738312,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 118571038925738312 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 118571038925738312 576460752303423488 0 ([59] : List (Fin n))=[(695031791229161800,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step414
end IU.Trace5
