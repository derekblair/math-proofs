import Trace5Part25
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step416 : NodeGood bank Hit (46513444887810376,648518346341351424,0) := by
  apply use_pivot bank Hit sym noLoop 46513444887810376 648518346341351424 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 46513444887810376 648518346341351424 0 ([56] : List (Fin n))=[(118571038925738312,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step415
theorem step417 : NodeGood bank Hit (10484647868846408,684547143360315392,0) := by
  apply use_pivot bank Hit sym noLoop 10484647868846408 684547143360315392 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10484647868846408 684547143360315392 0 ([55] : List (Fin n))=[(46513444887810376,648518346341351424,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step416
theorem step418 : NodeGood bank Hit (1477448614105416,693554342615056384,0) := by
  apply use_pivot bank Hit sym noLoop 1477448614105416 693554342615056384 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1477448614105416 693554342615056384 0 ([53] : List (Fin n))=[(10484647868846408,684547143360315392,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step417
theorem step419 : NodeGood bank Hit (1195973637394760,693835817591767040,0) := by
  apply use_pivot bank Hit sym noLoop 1195973637394760 693835817591767040 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1195973637394760 693835817591767040 0 ([48] : List (Fin n))=[(1477448614105416,693554342615056384,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step418
theorem step420 : NodeGood bank Hit (1160789265305928,693871001963855872,0) := by
  apply use_pivot bank Hit sym noLoop 1160789265305928 693871001963855872 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1160789265305928 693871001963855872 0 ([45] : List (Fin n))=[(1195973637394760,693835817591767040,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step419
theorem step421 : NodeGood bank Hit (34889358463304,694997194197173251,0) := by
  apply use_pivot bank Hit sym noLoop 34889358463304 694997194197173251 0 34 [34,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 34889358463304 694997194197173251 0 ([34,50] : List (Fin n))=[(34906538332488,693871277110461443,0),(1160789265305928,693871001963855872,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step413
  · subst C; exact step420
theorem step422 : NodeGood bank Hit (713046189721866568,0,0) := by
  exact leaf bank Hit 713046189721866568 0 ⟨713046189721866568,by decide +kernel,rfl⟩
theorem step423 : NodeGood bank Hit (136585437418443080,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 136585437418443080 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 136585437418443080 576460752303423488 0 ([59] : List (Fin n))=[(713046189721866568,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step422
theorem step424 : NodeGood bank Hit (64527843380515144,648518346341351424,0) := by
  apply use_pivot bank Hit sym noLoop 64527843380515144 648518346341351424 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 64527843380515144 648518346341351424 0 ([56] : List (Fin n))=[(136585437418443080,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step423
theorem step425 : NodeGood bank Hit (28499046361551176,684547143360315392,0) := by
  apply use_pivot bank Hit sym noLoop 28499046361551176 684547143360315392 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 28499046361551176 684547143360315392 0 ([55] : List (Fin n))=[(64527843380515144,648518346341351424,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step424
theorem step426 : NodeGood bank Hit (19491847106810184,693554342615056384,0) := by
  apply use_pivot bank Hit sym noLoop 19491847106810184 693554342615056384 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 19491847106810184 693554342615056384 0 ([53] : List (Fin n))=[(28499046361551176,684547143360315392,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step425
theorem step427 : NodeGood bank Hit (18365947199967560,694680242521899008,0) := by
  apply use_pivot bank Hit sym noLoop 18365947199967560 694680242521899008 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18365947199967560 694680242521899008 0 ([50] : List (Fin n))=[(19491847106810184,693554342615056384,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step426
theorem step428 : NodeGood bank Hit (18084472223256904,694961717498609664,0) := by
  apply use_pivot bank Hit sym noLoop 18084472223256904 694961717498609664 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18084472223256904 694961717498609664 0 ([48] : List (Fin n))=[(18365947199967560,694680242521899008,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step427
theorem step429 : NodeGood bank Hit (18049287851168072,694996901870698496,0) := by
  apply use_pivot bank Hit sym noLoop 18049287851168072 694996901870698496 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18049287851168072 694996901870698496 0 ([45] : List (Fin n))=[(18084472223256904,694961717498609664,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step428
theorem step430 : NodeGood bank Hit (34889341686088,713011592723432451,0) := by
  apply use_pivot bank Hit sym noLoop 34889341686088 713011592723432451 0 24 [24,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 34889341686088 713011592723432451 0 ([24,54] : List (Fin n))=[(34889358463304,694997194197173251,0),(18049287851168072,694996901870698496,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step421
  · subst C; exact step429
theorem step431 : NodeGood bank Hit (713112160419533128,0,0) := by
  exact leaf bank Hit 713112160419533128 0 ⟨713112160419533128,by decide +kernel,rfl⟩
end IU.Trace5
