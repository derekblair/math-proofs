import Sharp5Grid2Coeff5
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry12 : ∀ i j : Fin 8, vcoeff T U shapeBank[12]! i.val j.val=(data[12]!)[8*i.val+j.val]! := by decide +kernel
theorem entry13 : ∀ i j : Fin 8, vcoeff T U shapeBank[13]! i.val j.val=(data[13]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone2
