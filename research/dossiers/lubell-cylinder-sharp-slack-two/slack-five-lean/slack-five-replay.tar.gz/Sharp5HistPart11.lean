import Sharp5HistPart10
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts55 : ∀ q : Fin 20, ((members n 45880693126070232).filter (fun v => code v=q)).card=(histograms[55]!)[q.val]! := by decide +kernel
theorem counts56 : ∀ q : Fin 20, ((members n 46444175655269336).filter (fun v => code v=q)).card=(histograms[56]!)[q.val]! := by decide +kernel
theorem counts57 : ∀ q : Fin 20, ((members n 47006575853040600).filter (fun v => code v=q)).card=(histograms[57]!)[q.val]! := by decide +kernel
theorem counts58 : ∀ q : Fin 20, ((members n 48695971173987096).filter (fun v => code v=q)).card=(histograms[58]!)[q.val]! := by decide +kernel
theorem counts59 : ∀ q : Fin 20, ((members n 49258371371758360).filter (fun v => code v=q)).card=(histograms[59]!)[q.val]! := by decide +kernel
end IU.Sharp5
