import WalkMaskEquiv

namespace IU.UniversalCount
open IU.Universal

theorem mem_vertices (s r w j : Nat) :
    (r,w,j) ∈ vertexList s ↔
      r≤s/2 ∧ w<2^s ∧ j≤s ∧ bits w s≤j+r ∧ compat s (r,w,j) (r,w,j)=true := by
  simp [vertexList, List.mem_flatMap, List.mem_map, List.mem_range, Nat.lt_succ_iff,
    and_assoc]

def GraphBucket (s r z m : Nat) :=
  {w : Nat // (r,w,m-r+z) ∈ vertexList s ∧ bits w s=m}

/-- An actual slice of the compact graph corresponds exactly to the
walks counted by reflection; both directions preserve the bit mask. -/
def graph_bucket_equiv (s r z m : Nat) (lo : 2*r≤m) (hi : m+2*z≤s) :
    GraphBucket s r z m ≃
      Crosses s (max (2*(r:ℤ)) (2*(m:ℤ)-s+2*(z:ℤ))) (2*(m:ℤ)-s) := by
  let j := m-r+z
  obtain ⟨hr,hj,terminal,deficit⟩ := index_of_deficits s m r z lo hi
  change r≤s/2 at hr
  change j≤s at hj
  change m≤j+r at terminal
  change j+r-m=z at deficit
  let encode (w : GraphBucket s r z m) : Crosses s
      (max (2*(r:ℤ)) (2*(m:ℤ)-s+2*(z:ℤ))) (2*(m:ℤ)-s) := by
    have p := (mem_vertices s r w.val j).mp w.property.1
    refine ⟨maskWalk s w.val, maskWalk_length s w.val, ?_, ?_⟩
    · exact (height_maskWalk s w.val).trans (by rw [w.property.2])
    · have e := (mask_compat_iff s r w.val j p.2.2.2.1).mp p.2.2.2.2
      simpa only [w.property.2,deficit] using e
  let decode (W : Crosses s (max (2*(r:ℤ)) (2*(m:ℤ)-s+2*(z:ℤ)))
      (2*(m:ℤ)-s)) : GraphBucket s r z m := by
    let w := encodeWalk W.val
    have e : maskWalk s w=W.val := by
      simpa only [w,W.property.1] using maskWalk_encode W.val
    have wb : w<2^s := by simpa only [w,W.property.1] using encodeWalk_lt W.val
    have hw : bits w s=m := by
      have v := height_maskWalk s w
      rw [e,W.property.2.1] at v
      omega
    have hterm : bits w s≤j+r := hw.symm ▸ terminal
    have hc : compat s (r,w,j) (r,w,j)=true :=
      (mask_compat_iff s r w j hterm).mpr (by
        simpa only [hw,deficit,e] using W.property.2.2)
    exact ⟨w,(mem_vertices s r w j).mpr ⟨hr,wb,hj,hterm,hc⟩,hw⟩
  refine ⟨encode,decode,?_,?_⟩
  · intro w
    apply Subtype.ext
    apply maskWalk_inj (s:=s)
    · exact ((mem_vertices s r _ j).mp (decode (encode w)).property.1).2.1
    · exact ((mem_vertices s r _ j).mp w.property.1).2.1
    · change maskWalk s (encodeWalk (maskWalk s w.val)) = maskWalk s w.val
      simpa only [maskWalk_length] using maskWalk_encode (maskWalk s w.val)
  · intro W
    apply Subtype.ext
    change maskWalk s (encodeWalk W.val)=W.val
    simpa only [W.property.1] using maskWalk_encode W.val

theorem graph_bucket_card (s r z m : Nat) (lo : 2*r≤m) (hi : m+2*z≤s) :
    Nat.card (GraphBucket s r z m)=s.choose (min (m-2*r) (s-m-2*z)) :=
  (Nat.card_congr (graph_bucket_equiv s r z m lo hi)).trans (bucket_card s m r z lo hi)

#print axioms graph_bucket_card
end IU.UniversalCount
