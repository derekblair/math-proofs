import VertexNewton
import UpperBridge
import RawFactor

namespace IU.Slack
open Finset IU.Universal IU.PolyCert
open scoped BigOperators

def shapeOf (s : Nat) (v : Vertex) : Shape :=
  ⟨s,v.1,v.2.2+v.1-Universal.bits v.2.1 s,v.2.2⟩

theorem shape_weight (t u s : Nat) (v : Vertex) :
    scoreN t u (shapeOf s v) = normalizedWeight (scaledWeight t u s) t u s v := by
  simp only [scoreN,shapeOf,normalizedWeight,scaledWeight]
  rw [show t+v.2.2-t=v.2.2 by omega,show t+s-(t+v.2.2)=s-v.2.2 by omega]

/-- Exact raw Lubell upper bound from maxima on the executable graph.
Finite computations need cover only maximal cliques. -/
theorem raw_bound_from_profile_maxima {t u s k : Nat} {F : Sys}
    (ht : 0<t) (ok : IsIU F (t+u+s) t u)
    (H : ∀ A : Finset (Fin (vertexList s).length),
      BK.MaxClique (Universal.edge s) A →
      sumN t u (fun i => shapeOf s (vertexList s)[i]) A≤k) :
    rawSum (t+u+s) F ≤ normalization t u s * (k:ℚ) := by
  let w := scaledWeight t u s
  obtain ⟨I,ig,up⟩ := original_to_graph w F ht ok
  obtain ⟨J,jg,jW⟩ := transfer w ig
  obtain ⟨A,ag,ja⟩ := BK.extend_to_max jg
  have p := sum_le_sum_of_subset (f:=fun i => normalizedWeight w t u s (vertexList s)[i]) ja
  have eq : (∑ i∈A, normalizedWeight w t u s (vertexList s)[i]) =
      sumN t u (fun i => shapeOf s (vertexList s)[i]) A := by
    exact sum_congr rfl fun i _ => (shape_weight t u s ((vertexList s)[i])).symm
  rw [eq] at p
  have cap : objective w F≤k := up.trans (jW ▸ p.trans (H A ag))
  rw [raw_factor ok]
  exact mul_le_mul_of_nonneg_left (by exact_mod_cast cap) (norm_positive _ _ _).le

#print axioms raw_bound_from_profile_maxima
end IU.Slack
