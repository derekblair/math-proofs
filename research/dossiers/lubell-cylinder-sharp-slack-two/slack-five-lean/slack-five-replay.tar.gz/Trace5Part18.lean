import Trace5Part17
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step288 : NodeGood bank Hit (1354237039576,136729511059524611,0) := by
  apply use_pivot bank Hit sym noLoop 1354237039576 136729511059524611 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1354237039576 136729511059524611 0 ([39] : List (Fin n))=[(1903992853464,136728961303710723,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step287
theorem step289 : NodeGood bank Hit (2453748667352,136727312036267011,1099511627776) := by
  apply use_pivot bank Hit sym noLoop 2453748667352 136727312036267011 1099511627776 40 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2453748667352 136727312036267011 1099511627776 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step290 : NodeGood bank Hit (72057848763339736,64669717729640448,3298534883328) := by
  apply use_pivot bank Hit sym noLoop 72057848763339736 64669717729640448 3298534883328 40 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 72057848763339736 64669717729640448 3298534883328 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step291 : NodeGood bank Hit (254725411800,137293560524745731,0) := by
  apply use_pivot bank Hit sym noLoop 254725411800 137293560524745731 0 13 [13,40,41,56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725411800 137293560524745731 0 ([13,40,41,56] : List (Fin n))=[(254725419992,65232667951926275,0),(1354237039576,136729511059524611,0),(2453748667352,136727312036267011,1099511627776),(72057848763339736,64669717729640448,3298534883328)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step236
  · subst C; exact step288
  · subst C; exact step289
  · subst C; exact step290
theorem step292 : NodeGood bank Hit (6594382618075,0,0) := by
  exact leaf bank Hit 6594382618075 0 ⟨6594382618075,by decide +kernel,rfl⟩
theorem step293 : NodeGood bank Hit (6594114182619,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 6594114182619 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6594114182619 268435456 0 ([28] : List (Fin n))=[(6594382618075,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step292
theorem step294 : NodeGood bank Hit (6594114182617,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 6594114182617 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6594114182617 268435458 0 ([1] : List (Fin n))=[(6594114182619,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step293
theorem step295 : NodeGood bank Hit (9013793368923608,0,0) := by
  exact leaf bank Hit 9013793368923608 0 ⟨9013793368923608,by decide +kernel,rfl⟩
theorem step296 : NodeGood bank Hit (6594114182616,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 6594114182616 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6594114182616 9007199523176451 0 ([0,53] : List (Fin n))=[(6594114182617,268435458,0),(9013793368923608,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step294
  · subst C; exact step295
theorem step297 : NodeGood bank Hit (45042590387625432,0,0) := by
  exact leaf bank Hit 45042590387625432 0 ⟨45042590387625432,by decide +kernel,rfl⟩
theorem step298 : NodeGood bank Hit (36035391132884440,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 36035391132884440 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36035391132884440 9007199254740992 0 ([53] : List (Fin n))=[(45042590387625432,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step297
theorem step299 : NodeGood bank Hit (6594113920472,45035996542402563,0) := by
  apply use_pivot bank Hit sym noLoop 6594113920472 45035996542402563 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6594113920472 45035996542402563 0 ([18,55] : List (Fin n))=[(6594114182616,9007199523176451,0),(36035391132884440,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step296
  · subst C; exact step298
theorem step300 : NodeGood bank Hit (45323790486429144,0,0) := by
  exact leaf bank Hit 45323790486429144 0 ⟨45323790486429144,by decide +kernel,rfl⟩
theorem step301 : NodeGood bank Hit (9294993467465176,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 9294993467465176 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9294993467465176 36028797018963968 0 ([55] : List (Fin n))=[(45323790486429144,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step300
theorem step302 : NodeGood bank Hit (287794212724184,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 287794212724184 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 287794212724184 45035996273704960 0 ([53] : List (Fin n))=[(9294993467465176,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step301
theorem step303 : NodeGood bank Hit (6319236013528,45317746397020163,0) := by
  apply use_pivot bank Hit sym noLoop 6319236013528 45317746397020163 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6319236013528 45317746397020163 0 ([38,48] : List (Fin n))=[(6594113920472,45035996542402563,0),(287794212724184,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step299
  · subst C; exact step302
end IU.Trace5
