import Sharp5HistPart12
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts65 : ∀ q : Fin 20, ((members n 117379185501098968).filter (fun v => code v=q)).card=(histograms[65]!)[q.val]! := by decide +kernel
theorem counts66 : ∀ q : Fin 20, ((members n 117383583547609560).filter (fun v => code v=q)).card=(histograms[66]!)[q.val]! := by decide +kernel
theorem counts67 : ∀ q : Fin 20, ((members n 117392379640631640).filter (fun v => code v=q)).card=(histograms[67]!)[q.val]! := by decide +kernel
theorem counts68 : ∀ q : Fin 20, ((members n 118505068228072408).filter (fun v => code v=q)).card=(histograms[68]!)[q.val]! := by decide +kernel
theorem counts69 : ∀ q : Fin 20, ((members n 118509466274583000).filter (fun v => code v=q)).card=(histograms[69]!)[q.val]! := by decide +kernel
end IU.Sharp5
