import Sharp5Grid2Compare6
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot28 : ∀ i j : Fin 8, dot data histograms[28]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare28 : ∀ i j : Fin 8, sumTable data 9008158372364248 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts28, hist_sound data _ _ counts61] <;> exact dot28 i j
theorem dot29 : ∀ i j : Fin 8, dot data histograms[29]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare29 : ∀ i j : Fin 8, sumTable data 9008295810793432 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts29, hist_sound data _ _ counts61] <;> exact dot29 i j
theorem dot30 : ∀ i j : Fin 8, dot data histograms[30]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare30 : ∀ i j : Fin 8, sumTable data 9009257883983832 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts30, hist_sound data _ _ counts61] <;> exact dot30 i j
theorem dot31 : ∀ i j : Fin 8, dot data histograms[31]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare31 : ∀ i j : Fin 8, sumTable data 9009395322413016 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts31, hist_sound data _ _ counts61] <;> exact dot31 i j
end IU.Sharp5.Cone2
