import Trace5Part26
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step432 : NodeGood bank Hit (136651408116109640,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 136651408116109640 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 136651408116109640 576460752303423488 0 ([59] : List (Fin n))=[(713112160419533128,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step431
theorem step433 : NodeGood bank Hit (64593814078181704,648518346341351424,0) := by
  apply use_pivot bank Hit sym noLoop 64593814078181704 648518346341351424 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 64593814078181704 648518346341351424 0 ([56] : List (Fin n))=[(136651408116109640,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step432
theorem step434 : NodeGood bank Hit (28565017059217736,684547143360315392,0) := by
  apply use_pivot bank Hit sym noLoop 28565017059217736 684547143360315392 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 28565017059217736 684547143360315392 0 ([55] : List (Fin n))=[(64593814078181704,648518346341351424,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step433
theorem step435 : NodeGood bank Hit (10550618549735752,702561541869797376,0) := by
  apply use_pivot bank Hit sym noLoop 10550618549735752 702561541869797376 0 54 [54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10550618549735752 702561541869797376 0 ([54] : List (Fin n))=[(28565017059217736,684547143360315392,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step434
theorem step436 : NodeGood bank Hit (1543419294994760,711568741124538368,0) := by
  apply use_pivot bank Hit sym noLoop 1543419294994760 711568741124538368 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1543419294994760 711568741124538368 0 ([53] : List (Fin n))=[(10550618549735752,702561541869797376,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step435
theorem step437 : NodeGood bank Hit (417519388152136,712694641031380992,0) := by
  apply use_pivot bank Hit sym noLoop 417519388152136 712694641031380992 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 417519388152136 712694641031380992 0 ([50] : List (Fin n))=[(1543419294994760,711568741124538368,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step436
theorem step438 : NodeGood bank Hit (136044411441480,712976116008091648,0) := by
  apply use_pivot bank Hit sym noLoop 136044411441480 712976116008091648 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 136044411441480 712976116008091648 0 ([48] : List (Fin n))=[(417519388152136,712694641031380992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step437
theorem step439 : NodeGood bank Hit (100860039352648,713011300380180480,0) := by
  apply use_pivot bank Hit sym noLoop 100860039352648 713011300380180480 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 100860039352648 713011300380180480 0 ([45] : List (Fin n))=[(136044411441480,712976116008091648,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step438
theorem step440 : NodeGood bank Hit (30491295174984,713086359514121219,0) := by
  apply use_pivot bank Hit sym noLoop 30491295174984 713086359514121219 0 42 [42,46] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 30491295174984 713086359514121219 0 ([42,46] : List (Fin n))=[(34889341686088,713011592723432451,0),(100860039352648,713011300380180480,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step430
  · subst C; exact step439
theorem step441 : NodeGood bank Hit (21695202152776,713095155607143427,0) := by
  apply use_pivot bank Hit sym noLoop 21695202152776 713095155607143427 0 43 [43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 21695202152776 713095155607143427 0 ([43] : List (Fin n))=[(30491295174984,713086359514121219,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step440
theorem step442 : NodeGood bank Hit (19496178897224,713097354630398979,0) := by
  apply use_pivot bank Hit sym noLoop 19496178897224 713097354630398979 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 19496178897224 713097354630398979 0 ([41] : List (Fin n))=[(21695202152776,713095155607143427,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step441
theorem step443 : NodeGood bank Hit (18396667269448,713098454142026755,0) := by
  apply use_pivot bank Hit sym noLoop 18396667269448 713098454142026755 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18396667269448 713098454142026755 0 ([40] : List (Fin n))=[(19496178897224,713097354630398979,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step442
theorem step444 : NodeGood bank Hit (17846911455560,713099003897840643,0) := by
  apply use_pivot bank Hit sym noLoop 17846911455560 713099003897840643 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17846911455560 713099003897840643 0 ([39] : List (Fin n))=[(18396667269448,713098454142026755,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step443
theorem step445 : NodeGood bank Hit (35439097499976,713063819525751809,17592186044416) := by
  apply use_pivot bank Hit sym noLoop 35439097499976 713063819525751809 17592186044416 44 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 35439097499976 713063819525751809 17592186044416 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step446 : NodeGood bank Hit (576461007028834632,136603067222328320,52776558133248) := by
  apply use_pivot bank Hit sym noLoop 576461007028834632 136603067222328320 52776558133248 44 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 576461007028834632 136603067222328320 52776558133248 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step447 : NodeGood bank Hit (254725411144,713820283525836435,0) := by
  apply use_pivot bank Hit sym noLoop 254725411144 713820283525836435 0 4 [4,44,45,59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725411144 713820283525836435 0 ([4,44,45,59] : List (Fin n))=[(254725411160,137306754664279683,0),(17846911455560,713099003897840643,0),(35439097499976,713063819525751809,17592186044416),(576461007028834632,136603067222328320,52776558133248)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step384
  · subst C; exact step444
  · subst C; exact step445
  · subst C; exact step446
end IU.Trace5
