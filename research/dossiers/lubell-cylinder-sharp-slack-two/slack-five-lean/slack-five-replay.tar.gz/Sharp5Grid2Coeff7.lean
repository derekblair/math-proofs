import Sharp5Grid2Coeff6
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry14 : ∀ i j : Fin 8, vcoeff T U shapeBank[14]! i.val j.val=(data[14]!)[8*i.val+j.val]! := by decide +kernel
theorem entry15 : ∀ i j : Fin 8, vcoeff T U shapeBank[15]! i.val j.val=(data[15]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone2
