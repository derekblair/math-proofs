import Trace5Part6
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step112 : NodeGood bank Hit (117975113183,6339371770368,0) := by
  apply use_pivot bank Hit sym noLoop 117975113183 6339371770368 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 117975113183 6339371770368 0 ([34] : List (Fin n))=[(135154982367,6322191901184,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step111
theorem step113 : NodeGood bank Hit (113680145887,6343666737664,0) := by
  apply use_pivot bank Hit sym noLoop 113680145887 6343666737664 0 32 [32] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 113680145887 6343666737664 0 ([32] : List (Fin n))=[(117975113183,6339371770368,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step112
theorem step114 : NodeGood bank Hit (112606404063,6344740479488,0) := by
  apply use_pivot bank Hit sym noLoop 112606404063 6344740479488 0 30 [30] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 112606404063 6344740479488 0 ([30] : List (Fin n))=[(113680145887,6343666737664,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step113
theorem step115 : NodeGood bank Hit (112069533151,6345277350400,0) := by
  apply use_pivot bank Hit sym noLoop 112069533151 6345277350400 0 29 [29] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 112069533151 6345277350400 0 ([29] : List (Fin n))=[(112606404063,6344740479488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step114
theorem step116 : NodeGood bank Hit (111801097695,6345545785856,0) := by
  apply use_pivot bank Hit sym noLoop 111801097695 6345545785856 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111801097695 6345545785856 0 ([28] : List (Fin n))=[(112069533151,6345277350400,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step115
theorem step117 : NodeGood bank Hit (111784320479,6345562563072,0) := by
  apply use_pivot bank Hit sym noLoop 111784320479 6345562563072 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111784320479 6345562563072 0 ([24] : List (Fin n))=[(111801097695,6345545785856,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step116
theorem step118 : NodeGood bank Hit (111783796191,6345563087360,0) := by
  apply use_pivot bank Hit sym noLoop 111783796191 6345563087360 0 19 [19] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783796191 6345563087360 0 ([19] : List (Fin n))=[(111784320479,6345562563072,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step117
theorem step119 : NodeGood bank Hit (111783534047,6345563349504,0) := by
  apply use_pivot bank Hit sym noLoop 111783534047 6345563349504 0 18 [18] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783534047 6345563349504 0 ([18] : List (Fin n))=[(111783796191,6345563087360,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step118
theorem step120 : NodeGood bank Hit (111783531999,6345563351552,0) := by
  apply use_pivot bank Hit sym noLoop 111783531999 6345563351552 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783531999 6345563351552 0 ([11] : List (Fin n))=[(111783534047,6345563349504,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step119
theorem step121 : NodeGood bank Hit (111783530975,6345563352576,0) := by
  apply use_pivot bank Hit sym noLoop 111783530975 6345563352576 0 10 [10] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530975 6345563352576 0 ([10] : List (Fin n))=[(111783531999,6345563351552,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step120
theorem step122 : NodeGood bank Hit (111783530847,6345563352704,0) := by
  apply use_pivot bank Hit sym noLoop 111783530847 6345563352704 0 7 [7] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530847 6345563352704 0 ([7] : List (Fin n))=[(111783530975,6345563352576,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step121
theorem step123 : NodeGood bank Hit (111783530783,6345563352768,0) := by
  apply use_pivot bank Hit sym noLoop 111783530783 6345563352768 0 6 [6] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530783 6345563352768 0 ([6] : List (Fin n))=[(111783530847,6345563352704,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step122
theorem step124 : NodeGood bank Hit (111783530767,6345563352784,0) := by
  apply use_pivot bank Hit sym noLoop 111783530767 6345563352784 0 4 [4] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530767 6345563352784 0 ([4] : List (Fin n))=[(111783530783,6345563352768,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step123
theorem step125 : NodeGood bank Hit (111783530759,6345563352792,0) := by
  apply use_pivot bank Hit sym noLoop 111783530759 6345563352792 0 3 [3] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530759 6345563352792 0 ([3] : List (Fin n))=[(111783530767,6345563352784,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step124
theorem step126 : NodeGood bank Hit (111783530757,6345563352794,0) := by
  apply use_pivot bank Hit sym noLoop 111783530757 6345563352794 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530757 6345563352794 0 ([1] : List (Fin n))=[(111783530759,6345563352792,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step125
theorem step127 : NodeGood bank Hit (111783530756,6345563352795,0) := by
  apply use_pivot bank Hit sym noLoop 111783530756 6345563352795 0 0 [0] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111783530756 6345563352795 0 ([0] : List (Fin n))=[(111783530757,6345563352794,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step126
end IU.Trace5
