import Sharp5HistPart5
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts30 : ∀ q : Fin 20, ((members n 9009257883983832).filter (fun v => code v=q)).card=(histograms[30]!)[q.val]! := by decide +kernel
theorem counts31 : ∀ q : Fin 20, ((members n 9009395322413016).filter (fun v => code v=q)).card=(histograms[31]!)[q.val]! := by decide +kernel
theorem counts32 : ∀ q : Fin 20, ((members n 9011594345666520).filter (fun v => code v=q)).card=(histograms[32]!)[q.val]! := by decide +kernel
theorem counts33 : ∀ q : Fin 20, ((members n 9013655930494424).filter (fun v => code v=q)).card=(histograms[33]!)[q.val]! := by decide +kernel
theorem counts34 : ∀ q : Fin 20, ((members n 9013793368923608).filter (fun v => code v=q)).card=(histograms[34]!)[q.val]! := by decide +kernel
end IU.Sharp5
