import Sharp5Grid2Compare11
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot48 : ∀ i j : Fin 8, dot data histograms[48]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare48 : ∀ i j : Fin 8, sumTable data 45053585503901016 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts48, hist_sound data _ _ counts61] <;> exact dot48 i j
theorem dot49 : ∀ i j : Fin 8, dot data histograms[49]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare49 : ∀ i j : Fin 8, sumTable data 45318292928298968 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts49, hist_sound data _ _ counts61] <;> exact dot49 i j
theorem dot50 : ∀ i j : Fin 8, dot data histograms[50]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare50 : ∀ i j : Fin 8, sumTable data 45319392439918552 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts50, hist_sound data _ _ counts61] <;> exact dot50 i j
theorem dot51 : ∀ i j : Fin 8, dot data histograms[51]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare51 : ∀ i j : Fin 8, sumTable data 45321591463172056 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts51, hist_sound data _ _ counts61] <;> exact dot51 i j
end IU.Sharp5.Cone2
