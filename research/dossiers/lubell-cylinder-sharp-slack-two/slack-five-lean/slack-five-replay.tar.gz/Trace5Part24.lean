import Trace5Part23
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step384 : NodeGood bank Hit (254725411160,137306754664279683,0) := by
  apply use_pivot bank Hit sym noLoop 254725411160 137306754664279683 0 7 [7,43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725411160 137306754664279683 0 ([7,43] : List (Fin n))=[(254725411288,137297958571257347,0),(9050818433368,136594271129306115,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step341
  · subst C; exact step383
theorem step385 : NodeGood bank Hit (35181684938059,0,0) := by
  exact leaf bank Hit 35181684938059 0 ⟨35181684938059,by decide +kernel,rfl⟩
theorem step386 : NodeGood bank Hit (70366057026889,0,0) := by
  exact leaf bank Hit 70366057026889 0 ⟨70366057026889,by decide +kernel,rfl⟩
theorem step387 : NodeGood bank Hit (35181684938057,35184372088834,0) := by
  apply use_pivot bank Hit sym noLoop 35181684938057 35184372088834 0 1 [1,45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 35181684938057 35184372088834 0 ([1,45] : List (Fin n))=[(35181684938059,0,0),(70366057026889,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step385
  · subst C; exact step386
theorem step388 : NodeGood bank Hit (576531118360450376,0,0) := by
  exact leaf bank Hit 576531118360450376 0 ⟨576531118360450376,by decide +kernel,rfl⟩
theorem step389 : NodeGood bank Hit (576495933988361544,35184372088832,0) := by
  apply use_pivot bank Hit sym noLoop 576495933988361544 35184372088832 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 576495933988361544 35184372088832 0 ([45] : List (Fin n))=[(576531118360450376,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step388
theorem step390 : NodeGood bank Hit (35181684938056,576495936675512323,0) := by
  apply use_pivot bank Hit sym noLoop 35181684938056 576495936675512323 0 0 [0,59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 35181684938056 576495936675512323 0 ([0,59] : List (Fin n))=[(35181684938057,35184372088834,0),(576495933988361544,35184372088832,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step387
  · subst C; exact step389
theorem step391 : NodeGood bank Hit (585538317346755912,0,0) := by
  exact leaf bank Hit 585538317346755912 0 ⟨585538317346755912,by decide +kernel,rfl⟩
theorem step392 : NodeGood bank Hit (9077565043332424,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 9077565043332424 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9077565043332424 576460752303423488 0 ([59] : List (Fin n))=[(585538317346755912,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step391
theorem step393 : NodeGood bank Hit (9042380671243592,576495936675512320,0) := by
  apply use_pivot bank Hit sym noLoop 9042380671243592 576495936675512320 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9042380671243592 576495936675512320 0 ([45] : List (Fin n))=[(9077565043332424,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step392
theorem step394 : NodeGood bank Hit (35181416502600,585503136198688771,0) := by
  apply use_pivot bank Hit sym noLoop 35181416502600 585503136198688771 0 28 [28,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 35181416502600 585503136198688771 0 ([28,53] : List (Fin n))=[(35181684938056,576495936675512323,0),(9042380671243592,576495936675512320,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step390
  · subst C; exact step393
theorem step395 : NodeGood bank Hit (621567114365457736,0,0) := by
  exact leaf bank Hit 621567114365457736 0 ⟨621567114365457736,by decide +kernel,rfl⟩
theorem step396 : NodeGood bank Hit (45106362062034248,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 45106362062034248 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 45106362062034248 576460752303423488 0 ([59] : List (Fin n))=[(621567114365457736,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step395
theorem step397 : NodeGood bank Hit (36099162807293256,585467951558164480,0) := by
  apply use_pivot bank Hit sym noLoop 36099162807293256 585467951558164480 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36099162807293256 585467951558164480 0 ([53] : List (Fin n))=[(45106362062034248,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step396
theorem step398 : NodeGood bank Hit (36063978435204424,585503135930253312,0) := by
  apply use_pivot bank Hit sym noLoop 36063978435204424 585503135930253312 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36063978435204424 585503135930253312 0 ([45] : List (Fin n))=[(36099162807293256,585467951558164480,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step397
theorem step399 : NodeGood bank Hit (35181416240456,621531933217914883,0) := by
  apply use_pivot bank Hit sym noLoop 35181416240456 621531933217914883 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 35181416240456 621531933217914883 0 ([18,55] : List (Fin n))=[(35181416502600,585503136198688771,0),(36063978435204424,585503135930253312,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step394
  · subst C; exact step398
end IU.Trace5
