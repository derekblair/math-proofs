import Sharp5Grid2Compare3
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot16 : ∀ i j : Fin 8, dot data histograms[16]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare16 : ∀ i j : Fin 8, sumTable data 6594382618075 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts16, hist_sound data _ _ counts61] <;> exact dot16 i j
theorem dot17 : ∀ i j : Fin 8, dot data histograms[17]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare17 : ∀ i j : Fin 8, sumTable data 8793405871579 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts17, hist_sound data _ _ counts61] <;> exact dot17 i j
theorem dot18 : ∀ i j : Fin 8, dot data histograms[18]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare18 : ∀ i j : Fin 8, sumTable data 17589498893659 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts18, hist_sound data _ _ counts61] <;> exact dot18 i j
theorem dot19 : ∀ i j : Fin 8, dot data histograms[19]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare19 : ∀ i j : Fin 8, sumTable data 35181684938059 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts19, hist_sound data _ _ counts61] <;> exact dot19 i j
end IU.Sharp5.Cone2
