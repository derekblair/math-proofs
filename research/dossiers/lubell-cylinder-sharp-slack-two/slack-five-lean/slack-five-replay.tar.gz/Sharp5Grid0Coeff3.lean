import Sharp5Grid0Coeff2
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry6 : ∀ i j : Fin 8, vcoeff T U shapeBank[6]! i.val j.val=(data[6]!)[8*i.val+j.val]! := by decide +kernel
theorem entry7 : ∀ i j : Fin 8, vcoeff T U shapeBank[7]! i.val j.val=(data[7]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone0
