import Sharp5HistPart4
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts25 : ∀ q : Fin 20, ((members n 9007608616583128).filter (fun v => code v=q)).card=(histograms[25]!)[q.val]! := by decide +kernel
theorem counts26 : ∀ q : Fin 20, ((members n 9007746055012312).filter (fun v => code v=q)).card=(histograms[26]!)[q.val]! := by decide +kernel
theorem counts27 : ∀ q : Fin 20, ((members n 9008089654984664).filter (fun v => code v=q)).card=(histograms[27]!)[q.val]! := by decide +kernel
theorem counts28 : ∀ q : Fin 20, ((members n 9008158372364248).filter (fun v => code v=q)).card=(histograms[28]!)[q.val]! := by decide +kernel
theorem counts29 : ∀ q : Fin 20, ((members n 9008295810793432).filter (fun v => code v=q)).card=(histograms[29]!)[q.val]! := by decide +kernel
end IU.Sharp5
