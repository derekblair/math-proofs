import Trace5Part12
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step208 : NodeGood bank Hit (1096556052443,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 1096556052443 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1096556052443 268435456 0 ([28] : List (Fin n))=[(1096824487899,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step207
theorem step209 : NodeGood bank Hit (1096556052441,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 1096556052441 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1096556052441 268435458 0 ([1] : List (Fin n))=[(1096556052443,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step208
theorem step210 : NodeGood bank Hit (9008295810793432,0,0) := by
  exact leaf bank Hit 9008295810793432 0 ⟨9008295810793432,by decide +kernel,rfl⟩
theorem step211 : NodeGood bank Hit (1096556052440,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 1096556052440 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1096556052440 9007199523176451 0 ([0,53] : List (Fin n))=[(1096556052441,268435458,0),(9008295810793432,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step209
  · subst C; exact step210
theorem step212 : NodeGood bank Hit (45037092829495256,0,0) := by
  exact leaf bank Hit 45037092829495256 0 ⟨45037092829495256,by decide +kernel,rfl⟩
theorem step213 : NodeGood bank Hit (36029893574754264,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 36029893574754264 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36029893574754264 9007199254740992 0 ([53] : List (Fin n))=[(45037092829495256,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step212
theorem step214 : NodeGood bank Hit (1096555790296,45035996542402563,0) := by
  apply use_pivot bank Hit sym noLoop 1096555790296 45035996542402563 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1096555790296 45035996542402563 0 ([18,55] : List (Fin n))=[(1096556052440,9007199523176451,0),(36029893574754264,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step211
  · subst C; exact step213
theorem step215 : NodeGood bank Hit (45318292928298968,0,0) := by
  exact leaf bank Hit 45318292928298968 0 ⟨45318292928298968,by decide +kernel,rfl⟩
theorem step216 : NodeGood bank Hit (9289495909335000,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 9289495909335000 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9289495909335000 36028797018963968 0 ([55] : List (Fin n))=[(45318292928298968,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step215
theorem step217 : NodeGood bank Hit (282296654594008,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 282296654594008 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 282296654594008 45035996273704960 0 ([53] : List (Fin n))=[(9289495909335000,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step216
theorem step218 : NodeGood bank Hit (821677883352,45317746397020163,0) := by
  apply use_pivot bank Hit sym noLoop 821677883352 45317746397020163 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 821677883352 45317746397020163 0 ([38,48] : List (Fin n))=[(1096555790296,45035996542402563,0),(282296654594008,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step214
  · subst C; exact step217
theorem step219 : NodeGood bank Hit (804498014168,45317763576889347,0) := by
  apply use_pivot bank Hit sym noLoop 804498014168 45317763576889347 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 804498014168 45317763576889347 0 ([34] : List (Fin n))=[(821677883352,45317746397020163,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step218
theorem step220 : NodeGood bank Hit (804498012120,45317763576891395,0) := by
  apply use_pivot bank Hit sym noLoop 804498012120 45317763576891395 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 804498012120 45317763576891395 0 ([11] : List (Fin n))=[(804498014168,45317763576889347,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step219
theorem step221 : NodeGood bank Hit (46444175655269336,0,0) := by
  exact leaf bank Hit 46444175655269336 0 ⟨46444175655269336,by decide +kernel,rfl⟩
theorem step222 : NodeGood bank Hit (10415378636305368,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 10415378636305368 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10415378636305368 36028797018963968 0 ([55] : List (Fin n))=[(46444175655269336,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step221
theorem step223 : NodeGood bank Hit (1408179381564376,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 1408179381564376 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1408179381564376 45035996273704960 0 ([53] : List (Fin n))=[(10415378636305368,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step222
end IU.Trace5
