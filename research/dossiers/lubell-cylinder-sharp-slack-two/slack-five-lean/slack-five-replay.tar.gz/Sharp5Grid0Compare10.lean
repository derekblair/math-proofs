import Sharp5Grid0Compare9
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot40 : ∀ i j : Fin 8, dot data histograms[40]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare40 : ∀ i j : Fin 8, sumTable data 19633479896626168 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts40, hist_sound data _ _ counts6] <;> exact dot40 i j
theorem dot41 : ∀ i j : Fin 8, dot data histograms[41]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare41 : ∀ i j : Fin 8, sumTable data 28640677205210072 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts41, hist_sound data _ _ counts6] <;> exact dot41 i j
theorem dot42 : ∀ i j : Fin 8, dot data histograms[42]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare42 : ∀ i j : Fin 8, sumTable data 45036543073714136 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts42, hist_sound data _ _ counts6] <;> exact dot42 i j
theorem dot43 : ∀ i j : Fin 8, dot data histograms[43]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare43 : ∀ i j : Fin 8, sumTable data 45037092829495256 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts43, hist_sound data _ _ counts6] <;> exact dot43 i j
end IU.Sharp5.Cone0
