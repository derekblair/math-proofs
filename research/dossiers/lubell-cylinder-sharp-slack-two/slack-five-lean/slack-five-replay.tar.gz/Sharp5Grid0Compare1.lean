import Sharp5Grid0Compare0
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot4 : ∀ i j : Fin 8, dot data histograms[4]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare4 : ∀ i j : Fin 8, sumTable data 890668679131 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts4, hist_sound data _ _ counts6] <;> exact dot4 i j
theorem dot5 : ∀ i j : Fin 8, dot data histograms[5]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare5 : ∀ i j : Fin 8, sumTable data 891071332319 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts5, hist_sound data _ _ counts6] <;> exact dot5 i j
theorem dot6 : ∀ i j : Fin 8, dot data histograms[6]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare6 : ∀ i j : Fin 8, sumTable data 893151707135 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts6] <;> exact dot6 i j
theorem dot7 : ∀ i j : Fin 8, dot data histograms[7]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare7 : ∀ i j : Fin 8, sumTable data 959386058715 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts7, hist_sound data _ _ counts6] <;> exact dot7 i j
end IU.Sharp5.Cone0
