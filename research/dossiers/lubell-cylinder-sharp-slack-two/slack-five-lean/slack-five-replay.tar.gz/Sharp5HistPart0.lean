import Sharp5HistData
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts0 : ∀ q : Fin 20, ((members n 272190930907).filter (fun v => code v=q)).card=(histograms[0]!)[q.val]! := by decide +kernel
theorem counts1 : ∀ q : Fin 20, ((members n 409630277595).filter (fun v => code v=q)).card=(histograms[1]!)[q.val]! := by decide +kernel
theorem counts2 : ∀ q : Fin 20, ((members n 410032930783).filter (fun v => code v=q)).card=(histograms[2]!)[q.val]! := by decide +kernel
theorem counts3 : ∀ q : Fin 20, ((members n 547068706779).filter (fun v => code v=q)).card=(histograms[3]!)[q.val]! := by decide +kernel
theorem counts4 : ∀ q : Fin 20, ((members n 890668679131).filter (fun v => code v=q)).card=(histograms[4]!)[q.val]! := by decide +kernel
end IU.Sharp5
