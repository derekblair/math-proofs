import Mathlib.Algebra.Order.Ring.Int
namespace IU.UniversalCount

/-- Re-express the self-compatibility inequality in the form used by the
reflection principle. The walk ends at 2*m-s. -/
theorem self_threshold (s m r z j h p : ℕ) (balance : j+r=m+z) :
    ((2*j-s)+2*r+h≤2*p) ↔
      max (2*(r:ℤ)) (2*(m:ℤ)-s+2*(z:ℤ)) ≤ 2*(p:ℤ)-h := by
  rw [max_le_iff]
  omega

theorem reflected_ones (s m r z : ℤ) :
    m-max (2*r) (2*m-s+2*z) = min (m-2*r) (s-m-2*z) := by
  by_cases h : 2*r≤2*m-s+2*z
  · rw [max_eq_right h,min_eq_right (by omega)]
    omega
  · have h' : 2*m-s+2*z≤2*r := by omega
    rw [max_eq_left h',min_eq_left (by omega)]

theorem admissible_middle (s m r z : ℤ) (hr : 0≤r) (hz : 0≤z)
    (hm : 0≤min (m-2*r) (s-m-2*z)) :
    0≤m-r+z ∧ m-r+z≤s ∧ 2*(r+z)≤s := by
  rw [le_min_iff] at hm
  omega

#print axioms self_threshold
#print axioms reflected_ones
end IU.UniversalCount
