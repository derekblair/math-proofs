import Sharp5HistPart15
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts80 : ∀ q : Fin 20, ((members n 280647848936165656).filter (fun v => code v=q)).card=(histograms[80]!)[q.val]! := by decide +kernel
theorem counts81 : ∀ q : Fin 20, ((members n 576531118360450376).filter (fun v => code v=q)).card=(histograms[81]!)[q.val]! := by decide +kernel
theorem counts82 : ∀ q : Fin 20, ((members n 585538317346755912).filter (fun v => code v=q)).card=(histograms[82]!)[q.val]! := by decide +kernel
theorem counts83 : ∀ q : Fin 20, ((members n 621567114365457736).filter (fun v => code v=q)).card=(histograms[83]!)[q.val]! := by decide +kernel
theorem counts84 : ∀ q : Fin 20, ((members n 621848314464261448).filter (fun v => code v=q)).card=(histograms[84]!)[q.val]! := by decide +kernel
end IU.Sharp5
