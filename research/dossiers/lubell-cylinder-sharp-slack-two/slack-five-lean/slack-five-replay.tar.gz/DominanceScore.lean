import ScoreAffine
namespace IU.PolyCert
open Polynomial Finset
open scoped BigOperators

variable {α : Type}

noncomputable def sumP (T U : Coeff) (shape : α → Shape) (C : Finset α) : Bi :=
  ∑ v∈C, scoreP T U (shape v)

def sumN (t u : ℕ) (shape : α → Shape) (C : Finset α) : ℕ :=
  ∑ v∈C, scoreN t u (shape v)

theorem sum_eval (T U : Coeff) (shape : α → Shape) (C : Finset α) (a b : ℕ) :
    ((sumP T U shape C).eval (a:ℚ[X])).eval (b:ℚ) =
      (sumN (param T a b) (param U a b) shape C:ℚ) := by
  simp only [sumP,eval_finsetSum,sumN,Nat.cast_sum]
  exact sum_congr rfl fun v _ => score_eval T U (shape v) a b

theorem sum_degree (T U : Coeff) (shape : α → Shape) (C : Finset α) (d : ℕ)
    (bd : ∀ v∈C, bound (shape v)≤d) : (sumP T U shape C).natDegree≤d :=
  natDegree_sum_le_of_forall_le _ _ (fun v hv => (score_deg T U (shape v)).trans (bd v hv))

theorem sum_inner_degree (T U : Coeff) (shape : α → Shape) (C : Finset α) (d a : ℕ)
    (bd : ∀ v∈C, bound (shape v)≤d) :
      ((sumP T U shape C).eval (a:ℚ[X])).natDegree≤d := by
  simp only [sumP,eval_finsetSum]
  exact natDegree_sum_le_of_forall_le _ _ (fun v hv => (score_inner_deg T U (shape v) a).trans (bd v hv))

def diffN (T U : Coeff) (shape : α → Shape) (A C : Finset α) (a b : ℕ) : ℤ :=
  (sumN (param T a b) (param U a b) shape A:ℤ) -
    (sumN (param T a b) (param U a b) shape C:ℤ)

def certAt (T U : Coeff) (shape : α → Shape) (A C : Finset α) (i j : ℕ) : ℤ :=
  ∑ l∈range (j+1), IU.Newton.coeff j l *
    ∑ k∈range (i+1), IU.Newton.coeff i k * diffN T U shape A C k l

theorem cert_sound (T U : Coeff) (shape : α → Shape) (A C : Finset α) (d : ℕ)
    (bA : ∀ v∈A, bound (shape v)≤d) (bC : ∀ v∈C, bound (shape v)≤d)
    (test : ∀ i≤d, ∀ j≤d, 0≤certAt T U shape A C i j) (a b : ℕ) :
    sumN (param T a b) (param U a b) shape C ≤ sumN (param T a b) (param U a b) shape A := by
  let P := sumP T U shape A - sumP T U shape C
  have dd : P.natDegree≤d := (natDegree_sub_le _ _).trans
    (max_le (sum_degree T U shape A d bA) (sum_degree T U shape C d bC))
  have de (k : ℕ) : (P.eval (k:ℚ[X])).natDegree≤d := by
    simp only [P,eval_sub]
    exact (natDegree_sub_le _ _).trans
      (max_le (sum_inner_degree T U shape A d k bA) (sum_inner_degree T U shape C d k bC))
  have ev (k l : ℕ) : (P.eval (k:ℚ[X])).eval (l:ℚ)=(diffN T U shape A C k l:ℚ) := by
    simp only [P,eval_sub,sum_eval,diffN,Int.cast_sub,Int.cast_natCast]
  have nn := IU.Newton.grid_nonneg P d d dd (fun k _ => de k) _
    (fun k _ l _ => ev k l) ?_ a b
  · rw [ev] at nn
    have nz : 0≤diffN T U shape A C a b := by exact_mod_cast nn
    unfold diffN at nz
    exact_mod_cast sub_nonneg.mp nz
  · intro i hi j hj
    have h := test i hi j hj
    have hq : (0:ℚ)≤(certAt T U shape A C i j:ℚ) := by exact_mod_cast h
    simpa only [certAt,Int.cast_sum,Int.cast_mul,zsmul_eq_mul] using hq

#print axioms cert_sound
end IU.PolyCert
