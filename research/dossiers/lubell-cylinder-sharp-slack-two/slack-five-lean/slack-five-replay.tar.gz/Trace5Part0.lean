import Trace5Setup
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step0 : NodeGood bank Hit (893151707135,0,0) := by
  exact leaf bank Hit 893151707135 0 ⟨893151707135,by decide +kernel,rfl⟩
theorem step1 : NodeGood bank Hit (618273800191,274877906944,0) := by
  apply use_pivot bank Hit sym noLoop 618273800191 274877906944 0 38 [38] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 618273800191 274877906944 0 ([38] : List (Fin n))=[(893151707135,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step0
theorem step2 : NodeGood bank Hit (617736929279,275414777856,0) := by
  apply use_pivot bank Hit sym noLoop 617736929279 275414777856 0 29 [29] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 617736929279 275414777856 0 ([29] : List (Fin n))=[(618273800191,274877906944,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step1
theorem step3 : NodeGood bank Hit (617468493823,275683213312,0) := by
  apply use_pivot bank Hit sym noLoop 617468493823 275683213312 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 617468493823 275683213312 0 ([28] : List (Fin n))=[(617736929279,275414777856,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step2
theorem step4 : NodeGood bank Hit (617467969535,275683737600,0) := by
  apply use_pivot bank Hit sym noLoop 617467969535 275683737600 0 19 [19] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 617467969535 275683737600 0 ([19] : List (Fin n))=[(617468493823,275683213312,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step3
theorem step5 : NodeGood bank Hit (617467707391,275683999744,0) := by
  apply use_pivot bank Hit sym noLoop 617467707391 275683999744 0 18 [18] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 617467707391 275683999744 0 ([18] : List (Fin n))=[(617467969535,275683737600,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step4
theorem step6 : NodeGood bank Hit (617467707387,275683999748,0) := by
  apply use_pivot bank Hit sym noLoop 617467707387 275683999748 0 2 [2] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 617467707387 275683999748 0 ([2] : List (Fin n))=[(617467707391,275683999744,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step5
theorem step7 : NodeGood bank Hit (617467707385,275683999750,0) := by
  apply use_pivot bank Hit sym noLoop 617467707385 275683999750 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 617467707385 275683999750 0 ([1] : List (Fin n))=[(617467707387,275683999748,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step6
theorem step8 : NodeGood bank Hit (282092444418040,0,0) := by
  exact leaf bank Hit 282092444418040 0 ⟨282092444418040,by decide +kernel,rfl⟩
theorem step9 : NodeGood bank Hit (617467707384,281750660710407,0) := by
  apply use_pivot bank Hit sym noLoop 617467707384 281750660710407 0 0 [0,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 617467707384 281750660710407 0 ([0,48] : List (Fin n))=[(617467707385,275683999750,0),(282092444418040,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step7
  · subst C; exact step8
theorem step10 : NodeGood bank Hit (600287838200,281767840579591,0) := by
  apply use_pivot bank Hit sym noLoop 600287838200 281767840579591 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 600287838200 281767840579591 0 ([34] : List (Fin n))=[(617467707384,281750660710407,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step9
theorem step11 : NodeGood bank Hit (600287836152,281767840581639,0) := by
  apply use_pivot bank Hit sym noLoop 600287836152 281767840581639 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 600287836152 281767840581639 0 ([11] : List (Fin n))=[(600287838200,281767840579591,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step10
theorem step12 : NodeGood bank Hit (1407975171388408,0,0) := by
  exact leaf bank Hit 1407975171388408 0 ⟨1407975171388408,by decide +kernel,rfl⟩
theorem step13 : NodeGood bank Hit (1126500194677752,281474976710656,0) := by
  apply use_pivot bank Hit sym noLoop 1126500194677752 281474976710656 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1126500194677752 281474976710656 0 ([48] : List (Fin n))=[(1407975171388408,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step12
theorem step14 : NodeGood bank Hit (600287835128,1407667747425287,0) := by
  apply use_pivot bank Hit sym noLoop 600287835128 1407667747425287 0 10 [10,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 600287835128 1407667747425287 0 ([10,50] : List (Fin n))=[(600287836152,281767840581639,0),(1126500194677752,281474976710656,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step11
  · subst C; exact step13
theorem step15 : NodeGood bank Hit (19633479896626168,0,0) := by
  exact leaf bank Hit 19633479896626168 0 ⟨19633479896626168,by decide +kernel,rfl⟩
end IU.Trace5
