import Sharp5Grid2Compare10
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot44 : ∀ i j : Fin 8, dot data histograms[44]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare44 : ∀ i j : Fin 8, sumTable data 45038192341114840 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts44, hist_sound data _ _ counts61] <;> exact dot44 i j
theorem dot45 : ∀ i j : Fin 8, dot data histograms[45]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare45 : ∀ i j : Fin 8, sumTable data 45040391364368344 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts45, hist_sound data _ _ counts61] <;> exact dot45 i j
theorem dot46 : ∀ i j : Fin 8, dot data histograms[46]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare46 : ∀ i j : Fin 8, sumTable data 45042590387625432 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts46, hist_sound data _ _ counts61] <;> exact dot46 i j
theorem dot47 : ∀ i j : Fin 8, dot data histograms[47]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare47 : ∀ i j : Fin 8, sumTable data 45044789410878936 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts47, hist_sound data _ _ counts61] <;> exact dot47 i j
end IU.Sharp5.Cone2
