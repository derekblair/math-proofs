import Sharp5GridSetup
namespace IU.Sharp5
open Finset IU.Slack IU.Universal IU.PolyCert IU.DenseCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0

def optimalMask (t u : ℕ) : Nat :=
  if 2*t≤u+1 then lowMask else productMask

def optimum (t u : ℕ) : ℚ :=
  normalization t u 5 * (sumN t u shapes (members n (optimalMask t u)):ℚ)

def ConeClaim (T U : Coeff) (chosen : ℕ) : Prop :=
  ∀ R : ℕ, R∈IU.Trace5.output → ∀ a b : ℕ,
    sumN (param T a b) (param U a b) shapes (members n R) ≤
      sumN (param T a b) (param U a b) shapes (members n chosen)

theorem masked_le_of_cones
    (C0 : ConeClaim ⟨1,0,0⟩ ⟨2,0,1⟩ lowMask)
    (C1 : ConeClaim ⟨2,1,0⟩ ⟨3,2,1⟩ lowMask)
    (C2 : ConeClaim ⟨2,1,1⟩ ⟨2,2,1⟩ productMask) (R : ℕ) (h : R∈IU.Trace5.output) {t u : ℕ}
    (ht : 0<t) (hu : 2≤u) (hle : t≤u) :
    sumN t u shapes (members n R) ≤ sumN t u shapes (members n (optimalMask t u)) := by
  by_cases t1 : t=1
  · subst t
    have l : 2*1≤u+1 := by omega
    rw [optimalMask,if_pos l]
    have C := C0 R h 0 (u-2)
    have c0 : param (⟨1,0,0⟩ : Coeff) 0 (u-2)=1 := by simp [param]
    have c1 : param (⟨2,0,1⟩ : Coeff) 0 (u-2)=u := by simp [param]; omega
    rw [c0,c1] at C
    exact C
  · by_cases yes : 2*t≤u+1
    · rw [optimalMask,if_pos yes]
      let a := t-2
      let b := u-(2*t-1)
      have c0 : param (⟨2,1,0⟩ : Coeff) a b=t := by simp [param,a,b] <;> omega
      have c1 : param (⟨3,2,1⟩ : Coeff) a b=u := by simp [param,a,b] <;> omega
      have C := C1 R h a b
      rw [c0,c1] at C
      exact C
    · rw [optimalMask,if_neg yes]
      let a := u-t
      let b := 2*t-u-2
      have c0 : param (⟨2,1,1⟩ : Coeff) a b=t := by simp [param,a,b] <;> omega
      have c1 : param (⟨2,2,1⟩ : Coeff) a b=u := by simp [param,a,b] <;> omega
      have C := C2 R h a b
      rw [c0,c1] at C
      exact C

theorem max_le_of_cones
    (C0 : ConeClaim ⟨1,0,0⟩ ⟨2,0,1⟩ lowMask)
    (C1 : ConeClaim ⟨2,1,0⟩ ⟨3,2,1⟩ lowMask)
    (C2 : ConeClaim ⟨2,1,1⟩ ⟨2,2,1⟩ productMask) (Q : Finset (Fin n)) (h : BK.MaxClique (IU.DenseCert.edge bank5) Q)
    {t u : ℕ} (ht : 0<t) (hu : 2≤u) (hle : t≤u) :
    sumN t u shapes Q≤sumN t u shapes (members n (optimalMask t u)) := by
  obtain ⟨R,r,eq⟩ := IU.Trace5.all_maximal Q h
  rw [←eq]
  exact masked_le_of_cones C0 C1 C2 R r ht hu hle

theorem orig_injective5 : ∀ i j : Fin n, orig5 i=orig5 j → i=j := by decide +kernel

theorem picked_clique_low : ∀ i j : Fin n,
    i∈members n lowMask → j∈members n lowMask → compat 5 (orig5 i) (orig5 j)=true := by
  simp only [mem_members]
  decide +kernel

theorem picked_clique_prod : ∀ i j : Fin n,
    i∈members n productMask → j∈members n productMask → compat 5 (orig5 i) (orig5 j)=true := by
  simp only [mem_members]
  decide +kernel

theorem attained (t u : ℕ) :
    ∃ F : IU.Sys, IU.IsIU F (t+u+5) t u ∧ rawSum (t+u+5) F=optimum t u := by
  let A := members n (optimalMask t u)
  let V := A.image orig5
  have hV : ∀ v∈V,v∈vertexList 5 := by
    intro v hv
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hv
    rw [coords5_eq]
    apply List.get_mem
  have hE : ∀ v∈V, ∀ w∈V, compat 5 v w=true := by
    intro v hv w hw
    obtain ⟨i,hi,rfl⟩ := mem_image.mp hv
    obtain ⟨j,hj,rfl⟩ := mem_image.mp hw
    by_cases d : 2*t≤u+1
    · simp only [A,optimalMask,if_pos d] at hi hj
      exact picked_clique_low _ _ hi hj
    · simp only [A,optimalMask,if_neg d] at hi hj
      exact picked_clique_prod _ _ hi hj
  obtain ⟨F,ok,eq⟩ := attain_profile_score t u 5 V hV hE
  refine ⟨F,ok,?_⟩
  rw [eq]
  have W : sumN t u (shapeOf 5) V=sumN t u shapes A := by
    unfold V sumN
    have inj : Set.InjOn orig5 (↑A : Set (Fin n)) := fun _ _ _ _ q => orig_injective5 _ _ q
    rw [sum_image inj] <;> rfl
  rw [W]
  rfl

theorem sharp_five_ordered_of_cones
    (C0 : ConeClaim ⟨1,0,0⟩ ⟨2,0,1⟩ lowMask)
    (C1 : ConeClaim ⟨2,1,0⟩ ⟨3,2,1⟩ lowMask)
    (C2 : ConeClaim ⟨2,1,1⟩ ⟨2,2,1⟩ productMask) {t u : Nat} (ht : 0<t) (hu : 2≤u) (hle : t≤u) :
    (∃ F : IU.Sys, IU.IsIU F (t+u+5) t u ∧ rawSum (t+u+5) F=optimum t u) ∧
    ∀ F : IU.Sys, IU.IsIU F (t+u+5) t u → rawSum (t+u+5) F≤optimum t u := by
  refine ⟨attained t u,?_⟩
  intro F ok
  let e : Fin (vertexList 5).length ↪ Fin n :=
    (finCongr vertices5).toEmbedding
  apply raw_dense_upper ht ok e bank5 orig5
  · exact cast_vertices5
  · intro a b h
    apply (dense5_edge _ _).mpr
    refine ⟨fun E => h.1 (e.injective E),?_⟩
    change compat 5 (orig5 (Fin.cast vertices5 a)) (orig5 (Fin.cast vertices5 b))=true
    rw [cast_vertices5,cast_vertices5]
    exact h.2
  · intro Q h
    exact max_le_of_cones C0 C1 C2 Q h ht hu hle

#print axioms sharp_five_ordered_of_cones
end IU.Sharp5
