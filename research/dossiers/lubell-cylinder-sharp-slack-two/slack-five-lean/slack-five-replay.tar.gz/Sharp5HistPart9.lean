import Sharp5HistPart8
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts45 : ∀ q : Fin 20, ((members n 45040391364368344).filter (fun v => code v=q)).card=(histograms[45]!)[q.val]! := by decide +kernel
theorem counts46 : ∀ q : Fin 20, ((members n 45042590387625432).filter (fun v => code v=q)).card=(histograms[46]!)[q.val]! := by decide +kernel
theorem counts47 : ∀ q : Fin 20, ((members n 45044789410878936).filter (fun v => code v=q)).card=(histograms[47]!)[q.val]! := by decide +kernel
theorem counts48 : ∀ q : Fin 20, ((members n 45053585503901016).filter (fun v => code v=q)).card=(histograms[48]!)[q.val]! := by decide +kernel
theorem counts49 : ∀ q : Fin 20, ((members n 45318292928298968).filter (fun v => code v=q)).card=(histograms[49]!)[q.val]! := by decide +kernel
end IU.Sharp5
