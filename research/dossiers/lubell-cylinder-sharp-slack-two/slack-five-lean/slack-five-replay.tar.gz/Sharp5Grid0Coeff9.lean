import Sharp5Grid0Coeff8
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry18 : ∀ i j : Fin 8, vcoeff T U shapeBank[18]! i.val j.val=(data[18]!)[8*i.val+j.val]! := by decide +kernel
theorem entry19 : ∀ i j : Fin 8, vcoeff T U shapeBank[19]! i.val j.val=(data[19]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone0
