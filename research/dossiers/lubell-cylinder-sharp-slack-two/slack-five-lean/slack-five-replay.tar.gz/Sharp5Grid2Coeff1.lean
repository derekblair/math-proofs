import Sharp5Grid2Coeff0
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry2 : ∀ i j : Fin 8, vcoeff T U shapeBank[2]! i.val j.val=(data[2]!)[8*i.val+j.val]! := by decide +kernel
theorem entry3 : ∀ i j : Fin 8, vcoeff T U shapeBank[3]! i.val j.val=(data[3]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone2
