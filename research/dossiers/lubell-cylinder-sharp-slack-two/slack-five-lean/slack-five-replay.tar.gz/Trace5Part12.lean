import Trace5Part11
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step192 : NodeGood bank Hit (18014653235065816,47006321110679552,211106232532992) := by
  apply use_pivot bank Hit sym noLoop 18014653235065816 47006321110679552 211106232532992 46 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18014653235065816 47006321110679552 211106232532992 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step193 : NodeGood bank Hit (254725583832,65231843318041603,0) := by
  apply use_pivot bank Hit sym noLoop 254725583832 65231843318041603 0 24 [24,46,47,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725583832 65231843318041603 0 ([24,46,47,54] : List (Fin n))=[(254742361048,47006338559249411,0),(70623469761496,65161457108516864,0),(140992213939160,65020719620161536,70368744177664),(18014653235065816,47006321110679552,211106232532992)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step182
  · subst C; exact step190
  · subst C; exact step191
  · subst C; exact step192
theorem step194 : NodeGood bank Hit (547068706779,0,0) := by
  exact leaf bank Hit 547068706779 0 ⟨547068706779,by decide +kernel,rfl⟩
theorem step195 : NodeGood bank Hit (546800271323,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 546800271323 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 546800271323 268435456 0 ([28] : List (Fin n))=[(547068706779,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step194
theorem step196 : NodeGood bank Hit (546800271321,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 546800271321 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 546800271321 268435458 0 ([1] : List (Fin n))=[(546800271323,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step195
theorem step197 : NodeGood bank Hit (9007746055012312,0,0) := by
  exact leaf bank Hit 9007746055012312 0 ⟨9007746055012312,by decide +kernel,rfl⟩
theorem step198 : NodeGood bank Hit (546800271320,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 546800271320 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 546800271320 9007199523176451 0 ([0,53] : List (Fin n))=[(546800271321,268435458,0),(9007746055012312,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step196
  · subst C; exact step197
theorem step199 : NodeGood bank Hit (45036543073714136,0,0) := by
  exact leaf bank Hit 45036543073714136 0 ⟨45036543073714136,by decide +kernel,rfl⟩
theorem step200 : NodeGood bank Hit (36029343818973144,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 36029343818973144 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36029343818973144 9007199254740992 0 ([53] : List (Fin n))=[(45036543073714136,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step199
theorem step201 : NodeGood bank Hit (546800009176,45035996542402563,0) := by
  apply use_pivot bank Hit sym noLoop 546800009176 45035996542402563 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 546800009176 45035996542402563 0 ([18,55] : List (Fin n))=[(546800271320,9007199523176451,0),(36029343818973144,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step198
  · subst C; exact step200
theorem step202 : NodeGood bank Hit (529620139992,45036013722271747,0) := by
  apply use_pivot bank Hit sym noLoop 529620139992 45036013722271747 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 529620139992 45036013722271747 0 ([34] : List (Fin n))=[(546800009176,45035996542402563,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step201
theorem step203 : NodeGood bank Hit (529603362776,45036013739048963,0) := by
  apply use_pivot bank Hit sym noLoop 529603362776 45036013739048963 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 529603362776 45036013739048963 0 ([24] : List (Fin n))=[(529620139992,45036013722271747,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step202
theorem step204 : NodeGood bank Hit (529603360728,45036013739051011,0) := by
  apply use_pivot bank Hit sym noLoop 529603360728 45036013739051011 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 529603360728 45036013739051011 0 ([11] : List (Fin n))=[(529603362776,45036013739048963,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step203
theorem step205 : NodeGood bank Hit (529603359704,45036013739052035,0) := by
  apply use_pivot bank Hit sym noLoop 529603359704 45036013739052035 0 10 [10] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 529603359704 45036013739052035 0 ([10] : List (Fin n))=[(529603360728,45036013739051011,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step204
theorem step206 : NodeGood bank Hit (254725452760,65232118196079619,0) := by
  apply use_pivot bank Hit sym noLoop 254725452760 65232118196079619 0 17 [17,38] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725452760 65232118196079619 0 ([17,38] : List (Fin n))=[(254725583832,65231843318041603,0),(529603359704,45036013739052035,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step193
  · subst C; exact step205
theorem step207 : NodeGood bank Hit (1096824487899,0,0) := by
  exact leaf bank Hit 1096824487899 0 ⟨1096824487899,by decide +kernel,rfl⟩
end IU.Trace5
