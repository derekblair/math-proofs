import Sharp5HistPart6
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts35 : ∀ q : Fin 20, ((members n 9015992392177112).filter (fun v => code v=q)).card=(histograms[35]!)[q.val]! := by decide +kernel
theorem counts36 : ∀ q : Fin 20, ((members n 9024788485199192).filter (fun v => code v=q)).card=(histograms[36]!)[q.val]! := by decide +kernel
theorem counts37 : ∀ q : Fin 20, ((members n 9289289753001944).filter (fun v => code v=q)).card=(histograms[37]!)[q.val]! := by decide +kernel
theorem counts38 : ∀ q : Fin 20, ((members n 10415172479972312).filter (fun v => code v=q)).card=(histograms[38]!)[q.val]! := by decide +kernel
theorem counts39 : ∀ q : Fin 20, ((members n 12666967998690072).filter (fun v => code v=q)).card=(histograms[39]!)[q.val]! := by decide +kernel
end IU.Sharp5
