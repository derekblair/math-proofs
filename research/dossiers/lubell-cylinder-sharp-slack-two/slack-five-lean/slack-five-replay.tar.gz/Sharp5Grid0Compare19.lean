import Sharp5Grid0Compare18
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot76 : ∀ i j : Fin 8, dot data histograms[76]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare76 : ∀ i j : Fin 8, sumTable data 261226367617683736 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts76, hist_sound data _ _ counts6] <;> exact dot76 i j
theorem dot77 : ∀ i j : Fin 8, dot data histograms[77]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare77 : ∀ i j : Fin 8, sumTable data 261507567716487448 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts77, hist_sound data _ _ counts6] <;> exact dot77 i j
theorem dot78 : ∀ i j : Fin 8, dot data histograms[78]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare78 : ∀ i j : Fin 8, sumTable data 262633450443460888 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts78, hist_sound data _ _ counts6] <;> exact dot78 i j
theorem dot79 : ∀ i j : Fin 8, dot data histograms[79]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare79 : ∀ i j : Fin 8, sumTable data 264885245962178840 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts79, hist_sound data _ _ counts6] <;> exact dot79 i j
end IU.Sharp5.Cone0
