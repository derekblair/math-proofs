import UniversalScore
import Decode
namespace IU.Slack
open Finset IU.Universal IU.PolyCert
open scoped BigOperators

def midUnpack (s mask t : Nat) : Bag := (decode s mask).image (·+t)

theorem mid_unpack_bounds (s mask t : Nat) : midUnpack s mask t⊆mid t s := by
  intro x hx
  obtain ⟨y,ym,rfl⟩ := mem_image.mp hx
  have yr := mem_range.mp (decode_range _ _ ym)
  exact mem_sdiff.mpr ⟨mem_range.mpr (by omega),fun f => by have z := mem_range.mp f; omega⟩

theorem unpack_shift (s mask t : Nat) :
    shiftMiddle (midUnpack s mask t) t=decode s mask := by
  simp [shiftMiddle,midUnpack,image_image,Function.comp_def]

theorem unpack_card (s mask t : Nat) (h : mask<2^s) : (midUnpack s mask t).card=Universal.bits mask s := by
  unfold midUnpack
  rw [card_image_of_injOn]
  · have eq := rank_full (decode_range s mask)
    rw [mask_decode h] at eq
    exact eq.symm
  · intro a _ b _ e
    exact Nat.add_right_cancel e

theorem vertex_info {s : Nat} {v : Vertex} (h : v∈vertexList s) :
    v.2.1<2^s ∧ v.2.2≤s ∧ Universal.bits v.2.1 s≤v.2.2+v.1 ∧ compat s v v=true := by
  obtain ⟨inside,acc⟩ := List.mem_filter.mp h
  obtain ⟨r,_,m1⟩ := List.mem_flatMap.mp inside
  obtain ⟨mm,hm,m2⟩ := List.mem_flatMap.mp m1
  obtain ⟨j,hj,eq⟩ := List.mem_map.mp m2
  subst v
  exact ⟨List.mem_range.mp hm,(show j≤s from Nat.lt_succ_iff.mp (List.mem_range.mp hj)),
    of_decide_eq_true (Bool.and_eq_true_iff.mp acc).1,(Bool.and_eq_true_iff.mp acc).2⟩

def outsideOf (s : Nat) (v : Vertex) : Nat := v.2.2+v.1-Universal.bits v.2.1 s
def unpack (t s : Nat) (v : Vertex) : Q :=
  (t-v.1,midUnpack s v.2.1 t,outsideOf s v)

theorem unpack_adm {t u s : Nat} {v : Vertex} (h : v∈vertexList s)
    (r : v.1≤t) (z : outsideOf s v≤u) :
    Admissible t u s (unpack t s v) := by
  have ⟨ml,jl,mb,self⟩ := vertex_info h
  refine ⟨mid_unpack_bounds ..,Nat.sub_le _ _,z,?_,?_⟩ <;>
    unfold unpack full outsideOf <;> simp only [Prod.fst,Prod.snd] <;>
    rw [unpack_card _ _ _ ml] <;> omega

theorem small_unpack {t s : Nat} {v : Vertex} (h : v∈vertexList s)
    (r : v.1≤t) : small t s (unpack t s v)=v := by
  have ⟨ml,jl,mb,self⟩ := vertex_info h
  rcases v with ⟨ra,ma,j⟩
  refine Prod.ext ?_ (Prod.ext ?_ ?_)
  · simp [small,unpack]; omega
  · simp [small,unpack,unpack_shift,mask_decode ml]
  · change (t-ra+(midUnpack s ma t).card+(j+ra-Universal.bits ma s)-t)=j
    have hma : ma<2^s := ml
    rw [unpack_card s ma t hma]
    change ra≤t at r
    change Universal.bits ma s≤j+ra at mb
    omega

/-- Any chosen clique in the normalized profile graph attains its integer
score in an actual family. Infeasible profiles have zero weight. -/
theorem attain_profile_score (t u s : Nat) (V : Finset Vertex)
    (hV : ∀ v∈V,v∈vertexList s)
    (hE : ∀ v∈V, ∀ w∈V, compat s v w=true) :
    ∃ F : Sys, IsIU F (t+u+s) t u ∧
      rawSum (t+u+s) F=normalization t u s * (sumN t u (shapeOf s) V:ℚ) := by
  classical
  let A := V.filter (fun v => v.1≤t ∧ outsideOf s v≤u)
  let I := A.image (unpack t s)
  have adm (v : Vertex) (hv : v∈A) : Admissible t u s (unpack t s v) := by
    obtain ⟨ha,hb⟩ := mem_filter.mp hv
    exact unpack_adm (hV v ha) hb.1 hb.2
  have back (v : Vertex) (hv : v∈A) : small t s (unpack t s v)=v := by
    obtain ⟨ha,hb⟩ := mem_filter.mp hv
    exact small_unpack (hV v ha) hb.1
  have g : Good I t u s := by
    constructor
    · intro x hx
      obtain ⟨v,va,rfl⟩ := mem_image.mp hx
      exact adm _ va
    · intro x hx y hy
      obtain ⟨v,va,rfl⟩ := mem_image.mp hx
      obtain ⟨w,wa,rfl⟩ := mem_image.mp hy
      apply (compat_small (adm _ va) (adm _ wa)).mp
      rw [back _ va,back _ wa]
      exact hE _ (mem_filter.mp va).1 _ (mem_filter.mp wa).1
  have inj : Set.InjOn (unpack t s) (↑A : Set Vertex) := by
    intro v va w wa eq
    simpa [back _ va,back _ wa] using congrArg (small t s) eq
  have orig : sumN t u (shapeOf s) A = sumN t u (shapeOf s) V := by
    unfold sumN
    apply sum_subset (filter_subset _ _)
    intro v hv no
    have ff : ¬ (v.1≤t ∧ outsideOf s v≤u) := by
      intro pp
      exact no (mem_filter.mpr ⟨hv,pp⟩)
    rcases not_and_or.mp ff with rr|zz
    · simp [scoreN,shapeOf,Nat.choose_eq_zero_of_lt (Nat.lt_of_not_ge rr)]
    · have zz' : u<outsideOf s v := Nat.lt_of_not_ge zz
      have Z : u.choose (v.2.2+v.1-Universal.bits v.2.1 s)=0 :=
        Nat.choose_eq_zero_of_lt zz'
      simp [scoreN,shapeOf,Z]
  have score : Qscore (scaledWeight t u s) I t u=sumN t u (shapeOf s) V := by
    rw [←orig]
    unfold Qscore I sumN
    rw [sum_image inj]
    apply sum_congr rfl
    intro v hv
    rw [shape_weight]
    have E := normalizedWeight_eq (scaledWeight t u s) (adm v hv)
    rw [back v hv] at E
    exact E.symm
  refine ⟨lift I t u s,lift_valid g,?_⟩
  rw [raw_factor (lift_valid g),lift_score _ g,score]

#print axioms attain_profile_score
end IU.Slack
