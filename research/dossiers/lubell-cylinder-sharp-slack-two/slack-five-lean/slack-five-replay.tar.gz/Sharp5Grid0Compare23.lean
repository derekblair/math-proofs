import Sharp5Grid0Compare22
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot92 : ∀ i j : Fin 8, dot data histograms[92]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare92 : ∀ i j : Fin 8, sumTable data 839146979305017608 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts92, hist_sound data _ _ counts6] <;> exact dot92 i j
theorem dot93 : ∀ i j : Fin 8, dot data histograms[93]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare93 : ∀ i j : Fin 8, sumTable data 841398774823735560 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts93, hist_sound data _ _ counts6] <;> exact dot93 i j
theorem dot94 : ∀ i j : Fin 8, dot data histograms[94]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare94 : ∀ i j : Fin 8, sumTable data 857161377797722376 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts94, hist_sound data _ _ counts6] <;> exact dot94 i j
theorem dot95 : ∀ i j : Fin 8, dot data histograms[95]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare95 : ∀ i j : Fin 8, sumTable data 1170092071159165696 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts95, hist_sound data _ _ counts6] <;> exact dot95 i j
end IU.Sharp5.Cone0
