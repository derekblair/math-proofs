import Trace5Part7
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step128 : NodeGood bank Hit (409630277595,0,0) := by
  exact leaf bank Hit 409630277595 0 ⟨409630277595,by decide +kernel,rfl⟩
theorem step129 : NodeGood bank Hit (959386058715,0,0) := by
  exact leaf bank Hit 959386058715 0 ⟨959386058715,by decide +kernel,rfl⟩
theorem step130 : NodeGood bank Hit (409630244827,549755846656,0) := by
  apply use_pivot bank Hit sym noLoop 409630244827 549755846656 0 15 [15,39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 409630244827 549755846656 0 ([15,39] : List (Fin n))=[(409630277595,0,0),(959386058715,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step128
  · subst C; exact step129
theorem step131 : NodeGood bank Hit (2058897678299,0,0) := by
  exact leaf bank Hit 2058897678299 0 ⟨2058897678299,by decide +kernel,rfl⟩
theorem step132 : NodeGood bank Hit (1509141864411,549755813888,0) := by
  apply use_pivot bank Hit sym noLoop 1509141864411 549755813888 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1509141864411 549755813888 0 ([39] : List (Fin n))=[(2058897678299,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step131
theorem step133 : NodeGood bank Hit (409630236635,1649267482624,0) := by
  apply use_pivot bank Hit sym noLoop 409630236635 1649267482624 0 13 [13,40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 409630236635 1649267482624 0 ([13,40] : List (Fin n))=[(409630244827,549755846656,0),(1509141864411,549755813888,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step130
  · subst C; exact step132
theorem step134 : NodeGood bank Hit (6456944188891,0,0) := by
  exact leaf bank Hit 6456944188891 0 ⟨6456944188891,by decide +kernel,rfl⟩
theorem step135 : NodeGood bank Hit (5357432561115,1099511627776,0) := by
  apply use_pivot bank Hit sym noLoop 5357432561115 1099511627776 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 5357432561115 1099511627776 0 ([40] : List (Fin n))=[(6456944188891,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step134
theorem step136 : NodeGood bank Hit (4807676747227,1649267441664,0) := by
  apply use_pivot bank Hit sym noLoop 4807676747227 1649267441664 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4807676747227 1649267441664 0 ([39] : List (Fin n))=[(5357432561115,1099511627776,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step135
theorem step137 : NodeGood bank Hit (409630236123,6047313994240,0) := by
  apply use_pivot bank Hit sym noLoop 409630236123 6047313994240 0 9 [9,42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 409630236123 6047313994240 0 ([9,42] : List (Fin n))=[(409630236635,1649267482624,0),(4807676747227,1649267441664,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step133
  · subst C; exact step136
theorem step138 : NodeGood bank Hit (409361800667,6047582429696,0) := by
  apply use_pivot bank Hit sym noLoop 409361800667 6047582429696 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 409361800667 6047582429696 0 ([28] : List (Fin n))=[(409630236123,6047313994240,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step137
theorem step139 : NodeGood bank Hit (409361800665,6047582429698,0) := by
  apply use_pivot bank Hit sym noLoop 409361800665 6047582429698 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 409361800665 6047582429698 0 ([1] : List (Fin n))=[(409361800667,6047582429696,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step138
theorem step140 : NodeGood bank Hit (9007608616583128,0,0) := by
  exact leaf bank Hit 9007608616583128 0 ⟨9007608616583128,by decide +kernel,rfl⟩
theorem step141 : NodeGood bank Hit (9008158372364248,0,0) := by
  exact leaf bank Hit 9008158372364248 0 ⟨9008158372364248,by decide +kernel,rfl⟩
theorem step142 : NodeGood bank Hit (9007608616550360,549755846656,0) := by
  apply use_pivot bank Hit sym noLoop 9007608616550360 549755846656 0 15 [15,39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9007608616550360 549755846656 0 ([15,39] : List (Fin n))=[(9007608616583128,0,0),(9008158372364248,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step140
  · subst C; exact step141
theorem step143 : NodeGood bank Hit (9009257883983832,0,0) := by
  exact leaf bank Hit 9009257883983832 0 ⟨9009257883983832,by decide +kernel,rfl⟩
end IU.Trace5
