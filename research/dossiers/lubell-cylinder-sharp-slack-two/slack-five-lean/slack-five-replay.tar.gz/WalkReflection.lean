import WalkArithmetic
import Mathlib.Data.Nat.Find
import Mathlib.Algebra.BigOperators.Group.List.Lemmas

namespace IU.UniversalCount

def step (b : Bool) : ℤ := if b then 1 else -1
def height (w : List Bool) : ℤ := (w.map step).sum
def partialHeight (w : List Bool) (k : Nat) : ℤ := height (w.take k)
def reflect (w : List Bool) (k : Nat) : List Bool :=
  w.take k ++ (w.drop k).map (!·)

def FirstHit (w : List Bool) (k : Nat) (H : Int) : Prop :=
   k≤w.length ∧ partialHeight w k=H ∧ ∀ i<k, partialHeight w i≠H

theorem height_append (a b : List Bool) :
    height (a++b)=height a+height b := by
  simp [height,List.sum_append]

theorem height_neg (a : List Bool) : height (a.map (!·)) = -height a := by
  induction a with
  | nil => simp [height]
  | cons v a ih =>
    have eq : step (!v) = -step v := by cases v <;> decide
    simp only [List.map_cons,height,List.sum_cons]
    change step (!v) + height (a.map (!·)) = -(step v+height a)
    rw [eq,ih]
    omega

theorem same_prefix (w : List Bool) {i k : Nat} (ik : i≤k) (kl : k≤w.length) :
    (reflect w k).take i=w.take i := by
  unfold reflect
  rw [List.take_append_of_le_length (by rwa [List.length_take_of_le kl]),
      List.take_take,min_eq_left ik]

theorem reflect_length (w : List Bool) (k : Nat) :
    (reflect w k).length=w.length := by
  simp [reflect]
  omega

theorem reflect_endpoint (w : List Bool) {k : Nat} {H : Int}
    (hit : partialHeight w k=H) :
    height (reflect w k) = 2*H-height w := by
  have e := height_append (w.take k) (w.drop k)
  rw [List.take_append_drop] at e
  rw [reflect,height_append,height_neg]
  unfold partialHeight at hit
  omega

theorem reflect_twice (w : List Bool) {k : Nat} (h : k≤w.length) :
    reflect (reflect w k) k=w := by
  have p := same_prefix w le_rfl h
  have q : (reflect w k).drop k = (w.drop k).map (!·) := by
    unfold reflect
    nth_rw 1 [←List.length_take_of_le h]
    exact List.drop_append_length
  change (reflect w k).take k ++ ((reflect w k).drop k).map (!·) = w
  rw [p,q,List.map_map]
  have e : (!·) ∘ (!·) = (id : Bool → Bool) := by
    funext i; cases i <;> rfl
  rw [e,List.map_id,List.take_append_drop]

theorem preserve_hit {w : List Bool} {k : Nat} {H : Int} (h : FirstHit w k H) :
    FirstHit (reflect w k) k H := by
  obtain ⟨kl,hit,no⟩ := h
  refine ⟨by rwa [reflect_length],?_,?_⟩
  · unfold partialHeight at *
    rwa [same_prefix w le_rfl kl]
  · intro i ik
    unfold partialHeight at *
    rw [same_prefix w (Nat.le_of_lt ik) kl]
    exact no i ik

theorem exists_first {w : List Bool} {H : Int} (h0 : 0≤H)
    (cross : ∃ k≤w.length, H≤partialHeight w k) :
    ∃ k, FirstHit w k H := by
  classical
  let k := Nat.find cross
  have hk : k≤w.length ∧ H≤partialHeight w k := Nat.find_spec cross
  have no (j : ℕ) (jlt : j<k) : ¬ (j≤w.length ∧ H≤partialHeight w j) :=
    Nat.find_min cross jlt
  refine ⟨k,hk.1,?_,?_⟩
  · by_cases e : k=0
    · have H0 := hk.2
      rw [e] at H0 ⊢
      change H≤(0:ℤ) at H0
      change (0:ℤ)=H
      exact le_antisymm h0 H0
    · have prev : k-1<k := by omega
      have ml : k-1<w.length := by omega
      have bad : partialHeight w (k-1)<H := by
        by_contra! q
        exact no _ prev ⟨by omega,q⟩
      have U : (w.take (k-1))++[w[k-1]] = w.take k := by
        have q := List.take_succ_eq_append_getElem ml
        rw [show k-1+1=k by omega] at q
        exact q.symm
      have e1 := height_append (w.take (k-1)) [w[k-1]]
      rw [U] at e1
      have sk : height [w[k-1]]≤1 := by simp [height,step]; split <;> decide
      unfold partialHeight at *
      omega
  · intro j jk Z
    exact no j jk ⟨by omega,Z ▸ le_rfl⟩

#print axioms reflect_twice
#print axioms exists_first
end IU.UniversalCount
