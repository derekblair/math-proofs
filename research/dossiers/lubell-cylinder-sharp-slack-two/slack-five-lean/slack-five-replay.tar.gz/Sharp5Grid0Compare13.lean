import Sharp5Grid0Compare12
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot52 : ∀ i j : Fin 8, dot data histograms[52]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare52 : ∀ i j : Fin 8, sumTable data 45323790486429144 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts52, hist_sound data _ _ counts6] <;> exact dot52 i j
theorem dot53 : ∀ i j : Fin 8, dot data histograms[53]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare53 : ∀ i j : Fin 8, sumTable data 45325989509682648 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts53, hist_sound data _ _ counts6] <;> exact dot53 i j
theorem dot54 : ∀ i j : Fin 8, dot data histograms[54]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare54 : ∀ i j : Fin 8, sumTable data 45334785602704728 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts54, hist_sound data _ _ counts6] <;> exact dot54 i j
theorem dot55 : ∀ i j : Fin 8, dot data histograms[55]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare55 : ∀ i j : Fin 8, sumTable data 45880693126070232 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts55, hist_sound data _ _ counts6] <;> exact dot55 i j
end IU.Sharp5.Cone0
