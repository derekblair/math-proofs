import DenseEnum
import UniversalGraph
import Mathlib.Tactic.FinCases
namespace IU.DenseCert
open IU.Universal
set_option maxHeartbeats 0
set_option maxRecDepth 18000

def coords5 : List Vertex := [
  (0,0,0),(0,0,1),(0,0,2),(0,1,1),(0,1,2),(0,1,3),(0,2,1),(0,2,2),
  (0,3,2),(0,3,3),(0,4,1),(0,4,2),(0,5,2),(0,5,3),(0,6,2),(0,6,3),
  (0,7,3),(0,7,4),(0,8,1),(0,8,2),(0,9,2),(0,9,3),(0,10,2),(0,11,3),
  (0,12,2),(0,13,3),(0,14,3),(0,15,4),(0,16,1),(0,16,2),(0,17,2),(0,17,3),
  (0,18,2),(0,19,3),(0,20,2),(0,21,3),(0,22,3),(0,23,4),(0,24,2),(0,25,3),
  (0,26,3),(0,27,4),(0,28,3),(0,29,4),(0,30,4),(0,31,5),(1,3,1),(1,3,2),
  (1,7,2),(1,7,3),(1,11,2),(1,13,2),(1,14,2),(1,15,3),(1,19,2),(1,23,3),
  (1,27,3),(1,29,3),(1,30,3),(1,31,4),(2,15,2),(2,31,3)]

theorem coords5_len : (coords5).length=62 := by decide

theorem coords5_eq : vertexList 5=coords5 := by decide +kernel

def orig5 (j : Fin 62) : Vertex := (coords5).get (Fin.cast coords5_len.symm j)

theorem row5_0 : ∀ j : Fin 62, edge bank5 0 j ↔ (0≠j ∧ compat 5 (orig5 0) (orig5 j)=true) := by decide +kernel
theorem row5_1 : ∀ j : Fin 62, edge bank5 1 j ↔ (1≠j ∧ compat 5 (orig5 1) (orig5 j)=true) := by decide +kernel
theorem row5_2 : ∀ j : Fin 62, edge bank5 2 j ↔ (2≠j ∧ compat 5 (orig5 2) (orig5 j)=true) := by decide +kernel
theorem row5_3 : ∀ j : Fin 62, edge bank5 3 j ↔ (3≠j ∧ compat 5 (orig5 3) (orig5 j)=true) := by decide +kernel
theorem row5_4 : ∀ j : Fin 62, edge bank5 4 j ↔ (4≠j ∧ compat 5 (orig5 4) (orig5 j)=true) := by decide +kernel
theorem row5_5 : ∀ j : Fin 62, edge bank5 5 j ↔ (5≠j ∧ compat 5 (orig5 5) (orig5 j)=true) := by decide +kernel
theorem row5_6 : ∀ j : Fin 62, edge bank5 6 j ↔ (6≠j ∧ compat 5 (orig5 6) (orig5 j)=true) := by decide +kernel
theorem row5_7 : ∀ j : Fin 62, edge bank5 7 j ↔ (7≠j ∧ compat 5 (orig5 7) (orig5 j)=true) := by decide +kernel
theorem row5_8 : ∀ j : Fin 62, edge bank5 8 j ↔ (8≠j ∧ compat 5 (orig5 8) (orig5 j)=true) := by decide +kernel
theorem row5_9 : ∀ j : Fin 62, edge bank5 9 j ↔ (9≠j ∧ compat 5 (orig5 9) (orig5 j)=true) := by decide +kernel
theorem row5_10 : ∀ j : Fin 62, edge bank5 10 j ↔ (10≠j ∧ compat 5 (orig5 10) (orig5 j)=true) := by decide +kernel
theorem row5_11 : ∀ j : Fin 62, edge bank5 11 j ↔ (11≠j ∧ compat 5 (orig5 11) (orig5 j)=true) := by decide +kernel
theorem row5_12 : ∀ j : Fin 62, edge bank5 12 j ↔ (12≠j ∧ compat 5 (orig5 12) (orig5 j)=true) := by decide +kernel
theorem row5_13 : ∀ j : Fin 62, edge bank5 13 j ↔ (13≠j ∧ compat 5 (orig5 13) (orig5 j)=true) := by decide +kernel
theorem row5_14 : ∀ j : Fin 62, edge bank5 14 j ↔ (14≠j ∧ compat 5 (orig5 14) (orig5 j)=true) := by decide +kernel
theorem row5_15 : ∀ j : Fin 62, edge bank5 15 j ↔ (15≠j ∧ compat 5 (orig5 15) (orig5 j)=true) := by decide +kernel
theorem row5_16 : ∀ j : Fin 62, edge bank5 16 j ↔ (16≠j ∧ compat 5 (orig5 16) (orig5 j)=true) := by decide +kernel
theorem row5_17 : ∀ j : Fin 62, edge bank5 17 j ↔ (17≠j ∧ compat 5 (orig5 17) (orig5 j)=true) := by decide +kernel
theorem row5_18 : ∀ j : Fin 62, edge bank5 18 j ↔ (18≠j ∧ compat 5 (orig5 18) (orig5 j)=true) := by decide +kernel
theorem row5_19 : ∀ j : Fin 62, edge bank5 19 j ↔ (19≠j ∧ compat 5 (orig5 19) (orig5 j)=true) := by decide +kernel
theorem row5_20 : ∀ j : Fin 62, edge bank5 20 j ↔ (20≠j ∧ compat 5 (orig5 20) (orig5 j)=true) := by decide +kernel
theorem row5_21 : ∀ j : Fin 62, edge bank5 21 j ↔ (21≠j ∧ compat 5 (orig5 21) (orig5 j)=true) := by decide +kernel
theorem row5_22 : ∀ j : Fin 62, edge bank5 22 j ↔ (22≠j ∧ compat 5 (orig5 22) (orig5 j)=true) := by decide +kernel
theorem row5_23 : ∀ j : Fin 62, edge bank5 23 j ↔ (23≠j ∧ compat 5 (orig5 23) (orig5 j)=true) := by decide +kernel
theorem row5_24 : ∀ j : Fin 62, edge bank5 24 j ↔ (24≠j ∧ compat 5 (orig5 24) (orig5 j)=true) := by decide +kernel
theorem row5_25 : ∀ j : Fin 62, edge bank5 25 j ↔ (25≠j ∧ compat 5 (orig5 25) (orig5 j)=true) := by decide +kernel
theorem row5_26 : ∀ j : Fin 62, edge bank5 26 j ↔ (26≠j ∧ compat 5 (orig5 26) (orig5 j)=true) := by decide +kernel
theorem row5_27 : ∀ j : Fin 62, edge bank5 27 j ↔ (27≠j ∧ compat 5 (orig5 27) (orig5 j)=true) := by decide +kernel
theorem row5_28 : ∀ j : Fin 62, edge bank5 28 j ↔ (28≠j ∧ compat 5 (orig5 28) (orig5 j)=true) := by decide +kernel
theorem row5_29 : ∀ j : Fin 62, edge bank5 29 j ↔ (29≠j ∧ compat 5 (orig5 29) (orig5 j)=true) := by decide +kernel
theorem row5_30 : ∀ j : Fin 62, edge bank5 30 j ↔ (30≠j ∧ compat 5 (orig5 30) (orig5 j)=true) := by decide +kernel
theorem row5_31 : ∀ j : Fin 62, edge bank5 31 j ↔ (31≠j ∧ compat 5 (orig5 31) (orig5 j)=true) := by decide +kernel
theorem row5_32 : ∀ j : Fin 62, edge bank5 32 j ↔ (32≠j ∧ compat 5 (orig5 32) (orig5 j)=true) := by decide +kernel
theorem row5_33 : ∀ j : Fin 62, edge bank5 33 j ↔ (33≠j ∧ compat 5 (orig5 33) (orig5 j)=true) := by decide +kernel
theorem row5_34 : ∀ j : Fin 62, edge bank5 34 j ↔ (34≠j ∧ compat 5 (orig5 34) (orig5 j)=true) := by decide +kernel
theorem row5_35 : ∀ j : Fin 62, edge bank5 35 j ↔ (35≠j ∧ compat 5 (orig5 35) (orig5 j)=true) := by decide +kernel
theorem row5_36 : ∀ j : Fin 62, edge bank5 36 j ↔ (36≠j ∧ compat 5 (orig5 36) (orig5 j)=true) := by decide +kernel
theorem row5_37 : ∀ j : Fin 62, edge bank5 37 j ↔ (37≠j ∧ compat 5 (orig5 37) (orig5 j)=true) := by decide +kernel
theorem row5_38 : ∀ j : Fin 62, edge bank5 38 j ↔ (38≠j ∧ compat 5 (orig5 38) (orig5 j)=true) := by decide +kernel
theorem row5_39 : ∀ j : Fin 62, edge bank5 39 j ↔ (39≠j ∧ compat 5 (orig5 39) (orig5 j)=true) := by decide +kernel
theorem row5_40 : ∀ j : Fin 62, edge bank5 40 j ↔ (40≠j ∧ compat 5 (orig5 40) (orig5 j)=true) := by decide +kernel
theorem row5_41 : ∀ j : Fin 62, edge bank5 41 j ↔ (41≠j ∧ compat 5 (orig5 41) (orig5 j)=true) := by decide +kernel
theorem row5_42 : ∀ j : Fin 62, edge bank5 42 j ↔ (42≠j ∧ compat 5 (orig5 42) (orig5 j)=true) := by decide +kernel
theorem row5_43 : ∀ j : Fin 62, edge bank5 43 j ↔ (43≠j ∧ compat 5 (orig5 43) (orig5 j)=true) := by decide +kernel
theorem row5_44 : ∀ j : Fin 62, edge bank5 44 j ↔ (44≠j ∧ compat 5 (orig5 44) (orig5 j)=true) := by decide +kernel
theorem row5_45 : ∀ j : Fin 62, edge bank5 45 j ↔ (45≠j ∧ compat 5 (orig5 45) (orig5 j)=true) := by decide +kernel
theorem row5_46 : ∀ j : Fin 62, edge bank5 46 j ↔ (46≠j ∧ compat 5 (orig5 46) (orig5 j)=true) := by decide +kernel
theorem row5_47 : ∀ j : Fin 62, edge bank5 47 j ↔ (47≠j ∧ compat 5 (orig5 47) (orig5 j)=true) := by decide +kernel
theorem row5_48 : ∀ j : Fin 62, edge bank5 48 j ↔ (48≠j ∧ compat 5 (orig5 48) (orig5 j)=true) := by decide +kernel
theorem row5_49 : ∀ j : Fin 62, edge bank5 49 j ↔ (49≠j ∧ compat 5 (orig5 49) (orig5 j)=true) := by decide +kernel
theorem row5_50 : ∀ j : Fin 62, edge bank5 50 j ↔ (50≠j ∧ compat 5 (orig5 50) (orig5 j)=true) := by decide +kernel
theorem row5_51 : ∀ j : Fin 62, edge bank5 51 j ↔ (51≠j ∧ compat 5 (orig5 51) (orig5 j)=true) := by decide +kernel
theorem row5_52 : ∀ j : Fin 62, edge bank5 52 j ↔ (52≠j ∧ compat 5 (orig5 52) (orig5 j)=true) := by decide +kernel
theorem row5_53 : ∀ j : Fin 62, edge bank5 53 j ↔ (53≠j ∧ compat 5 (orig5 53) (orig5 j)=true) := by decide +kernel
theorem row5_54 : ∀ j : Fin 62, edge bank5 54 j ↔ (54≠j ∧ compat 5 (orig5 54) (orig5 j)=true) := by decide +kernel
theorem row5_55 : ∀ j : Fin 62, edge bank5 55 j ↔ (55≠j ∧ compat 5 (orig5 55) (orig5 j)=true) := by decide +kernel
theorem row5_56 : ∀ j : Fin 62, edge bank5 56 j ↔ (56≠j ∧ compat 5 (orig5 56) (orig5 j)=true) := by decide +kernel
theorem row5_57 : ∀ j : Fin 62, edge bank5 57 j ↔ (57≠j ∧ compat 5 (orig5 57) (orig5 j)=true) := by decide +kernel
theorem row5_58 : ∀ j : Fin 62, edge bank5 58 j ↔ (58≠j ∧ compat 5 (orig5 58) (orig5 j)=true) := by decide +kernel
theorem row5_59 : ∀ j : Fin 62, edge bank5 59 j ↔ (59≠j ∧ compat 5 (orig5 59) (orig5 j)=true) := by decide +kernel
theorem row5_60 : ∀ j : Fin 62, edge bank5 60 j ↔ (60≠j ∧ compat 5 (orig5 60) (orig5 j)=true) := by decide +kernel
theorem row5_61 : ∀ j : Fin 62, edge bank5 61 j ↔ (61≠j ∧ compat 5 (orig5 61) (orig5 j)=true) := by decide +kernel

theorem dense5_edge (i j : Fin 62) : edge bank5 i j ↔ (i≠j ∧ compat 5 (orig5 i) (orig5 j)=true) := by
  fin_cases i
  · exact row5_0 j
  · exact row5_1 j
  · exact row5_2 j
  · exact row5_3 j
  · exact row5_4 j
  · exact row5_5 j
  · exact row5_6 j
  · exact row5_7 j
  · exact row5_8 j
  · exact row5_9 j
  · exact row5_10 j
  · exact row5_11 j
  · exact row5_12 j
  · exact row5_13 j
  · exact row5_14 j
  · exact row5_15 j
  · exact row5_16 j
  · exact row5_17 j
  · exact row5_18 j
  · exact row5_19 j
  · exact row5_20 j
  · exact row5_21 j
  · exact row5_22 j
  · exact row5_23 j
  · exact row5_24 j
  · exact row5_25 j
  · exact row5_26 j
  · exact row5_27 j
  · exact row5_28 j
  · exact row5_29 j
  · exact row5_30 j
  · exact row5_31 j
  · exact row5_32 j
  · exact row5_33 j
  · exact row5_34 j
  · exact row5_35 j
  · exact row5_36 j
  · exact row5_37 j
  · exact row5_38 j
  · exact row5_39 j
  · exact row5_40 j
  · exact row5_41 j
  · exact row5_42 j
  · exact row5_43 j
  · exact row5_44 j
  · exact row5_45 j
  · exact row5_46 j
  · exact row5_47 j
  · exact row5_48 j
  · exact row5_49 j
  · exact row5_50 j
  · exact row5_51 j
  · exact row5_52 j
  · exact row5_53 j
  · exact row5_54 j
  · exact row5_55 j
  · exact row5_56 j
  · exact row5_57 j
  · exact row5_58 j
  · exact row5_59 j
  · exact row5_60 j
  · exact row5_61 j

#print axioms dense5_edge
end IU.DenseCert
