import Trace5Part14
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step240 : NodeGood bank Hit (9009395322413016,0,0) := by
  exact leaf bank Hit 9009395322413016 0 ⟨9009395322413016,by decide +kernel,rfl⟩
theorem step241 : NodeGood bank Hit (2196067672024,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 2196067672024 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2196067672024 9007199523176451 0 ([0,53] : List (Fin n))=[(2196067672025,268435458,0),(9009395322413016,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step239
  · subst C; exact step240
theorem step242 : NodeGood bank Hit (45038192341114840,0,0) := by
  exact leaf bank Hit 45038192341114840 0 ⟨45038192341114840,by decide +kernel,rfl⟩
theorem step243 : NodeGood bank Hit (36030993086373848,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 36030993086373848 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36030993086373848 9007199254740992 0 ([53] : List (Fin n))=[(45038192341114840,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step242
theorem step244 : NodeGood bank Hit (2196067409880,45035996542402563,0) := by
  apply use_pivot bank Hit sym noLoop 2196067409880 45035996542402563 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2196067409880 45035996542402563 0 ([18,55] : List (Fin n))=[(2196067672024,9007199523176451,0),(36030993086373848,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step241
  · subst C; exact step243
theorem step245 : NodeGood bank Hit (45319392439918552,0,0) := by
  exact leaf bank Hit 45319392439918552 0 ⟨45319392439918552,by decide +kernel,rfl⟩
theorem step246 : NodeGood bank Hit (9290595420954584,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 9290595420954584 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9290595420954584 36028797018963968 0 ([55] : List (Fin n))=[(45319392439918552,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step245
theorem step247 : NodeGood bank Hit (283396166213592,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 283396166213592 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 283396166213592 45035996273704960 0 ([53] : List (Fin n))=[(9290595420954584,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step246
theorem step248 : NodeGood bank Hit (1921189502936,45317746397020163,0) := by
  apply use_pivot bank Hit sym noLoop 1921189502936 45317746397020163 0 38 [38,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1921189502936 45317746397020163 0 ([38,48] : List (Fin n))=[(2196067409880,45035996542402563,0),(283396166213592,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step244
  · subst C; exact step247
theorem step249 : NodeGood bank Hit (1904009633752,45317763576889347,0) := by
  apply use_pivot bank Hit sym noLoop 1904009633752 45317763576889347 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1904009633752 45317763576889347 0 ([34] : List (Fin n))=[(1921189502936,45317746397020163,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step248
theorem step250 : NodeGood bank Hit (1903992856536,45317763593666563,0) := by
  apply use_pivot bank Hit sym noLoop 1903992856536 45317763593666563 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1903992856536 45317763593666563 0 ([24] : List (Fin n))=[(1904009633752,45317763576889347,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step249
theorem step251 : NodeGood bank Hit (1903992855512,45317763593667587,0) := by
  apply use_pivot bank Hit sym noLoop 1903992855512 45317763593667587 0 10 [10] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1903992855512 45317763593667587 0 ([10] : List (Fin n))=[(1903992856536,45317763593666563,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step250
theorem step252 : NodeGood bank Hit (4395359360987,0,0) := by
  exact leaf bank Hit 4395359360987 0 ⟨4395359360987,by decide +kernel,rfl⟩
theorem step253 : NodeGood bank Hit (4395090925531,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 4395090925531 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4395090925531 268435456 0 ([28] : List (Fin n))=[(4395359360987,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step252
theorem step254 : NodeGood bank Hit (4395090925529,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 4395090925529 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4395090925529 268435458 0 ([1] : List (Fin n))=[(4395090925531,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step253
theorem step255 : NodeGood bank Hit (9011594345666520,0,0) := by
  exact leaf bank Hit 9011594345666520 0 ⟨9011594345666520,by decide +kernel,rfl⟩
end IU.Trace5
