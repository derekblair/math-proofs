import Trace5Part28
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step464 : NodeGood bank Hit (262351975466750216,576795003838267408,0) := by
  apply use_pivot bank Hit sym noLoop 262351975466750216 576795003838267408 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 262351975466750216 576795003838267408 0 ([48] : List (Fin n))=[(262633450443460872,576513528861556752,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step463
theorem step465 : NodeGood bank Hit (261226075559907592,577921195802886160,0) := by
  apply use_pivot bank Hit sym noLoop 261226075559907592 577921195802886160 0 34 [34,50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261226075559907592 577921195802886160 0 ([34,50] : List (Fin n))=[(261226092739776776,576795278716174352,0),(262351975466750216,576795003838267408,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step458
  · subst C; exact step464
theorem step466 : NodeGood bank Hit (280647848936165656,0,0) := by
  exact leaf bank Hit 280647848936165656 0 ⟨280647848936165656,by decide +kernel,rfl⟩
theorem step467 : NodeGood bank Hit (857161377797722376,0,0) := by
  exact leaf bank Hit 857161377797722376 0 ⟨857161377797722376,by decide +kernel,rfl⟩
theorem step468 : NodeGood bank Hit (280700625494298888,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 280700625494298888 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 280700625494298888 576460752303423488 0 ([59] : List (Fin n))=[(857161377797722376,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step467
theorem step469 : NodeGood bank Hit (280665441122210056,576495936675512320,0) := by
  apply use_pivot bank Hit sym noLoop 280665441122210056 576495936675512320 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 280665441122210056 576495936675512320 0 ([45] : List (Fin n))=[(280700625494298888,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step468
theorem step470 : NodeGood bank Hit (280647848936165640,576513528861556752,0) := by
  apply use_pivot bank Hit sym noLoop 280647848936165640 576513528861556752 0 44 [4,44] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 280647848936165640 576513528861556752 0 ([4,44] : List (Fin n))=[(280647848936165656,0,0),(280665441122210056,576495936675512320,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step466
  · subst C; exact step469
theorem step471 : NodeGood bank Hit (279521949029323016,577639428768399376,0) := by
  apply use_pivot bank Hit sym noLoop 279521949029323016 577639428768399376 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 279521949029323016 577639428768399376 0 ([50] : List (Fin n))=[(280647848936165640,576513528861556752,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step470
theorem step472 : NodeGood bank Hit (279240474052612360,577920903745110032,0) := by
  apply use_pivot bank Hit sym noLoop 279240474052612360 577920903745110032 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 279240474052612360 577920903745110032 0 ([48] : List (Fin n))=[(279521949029323016,577639428768399376,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step471
theorem step473 : NodeGood bank Hit (261226075543130376,595935594329145360,0) := by
  apply use_pivot bank Hit sym noLoop 261226075543130376 595935594329145360 0 24 [24,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 261226075543130376 595935594329145360 0 ([24,54] : List (Fin n))=[(261226075559907592,577921195802886160,0),(279240474052612360,577920903745110032,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step465
  · subst C; exact step472
theorem step474 : NodeGood bank Hit (189168481505202440,667993188367073296,0) := by
  apply use_pivot bank Hit sym noLoop 189168481505202440 667993188367073296 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 189168481505202440 667993188367073296 0 ([56] : List (Fin n))=[(261226075543130376,595935594329145360,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step473
theorem step475 : NodeGood bank Hit (153139684486238472,704021985386037264,0) := by
  apply use_pivot bank Hit sym noLoop 153139684486238472 704021985386037264 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 153139684486238472 704021985386037264 0 ([55] : List (Fin n))=[(189168481505202440,667993188367073296,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step474
theorem step476 : NodeGood bank Hit (144132485231497480,713029184640778256,0) := by
  apply use_pivot bank Hit sym noLoop 144132485231497480 713029184640778256 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 144132485231497480 713029184640778256 0 ([53] : List (Fin n))=[(153139684486238472,704021985386037264,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step475
theorem step477 : NodeGood bank Hit (144123689138475272,713037980733800464,0) := by
  apply use_pivot bank Hit sym noLoop 144123689138475272 713037980733800464 0 43 [43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 144123689138475272 713037980733800464 0 ([43] : List (Fin n))=[(144132485231497480,713029184640778256,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step476
theorem step478 : NodeGood bank Hit (144119291091964168,713042378780311568,0) := by
  apply use_pivot bank Hit sym noLoop 144119291091964168 713042378780311568 0 42 [42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 144119291091964168 713042378780311568 0 ([42] : List (Fin n))=[(144123689138475272,713037980733800464,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step477
theorem step479 : NodeGood bank Hit (144117092068708616,713044577803567120,0) := by
  apply use_pivot bank Hit sym noLoop 144117092068708616 713044577803567120 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 144117092068708616 713044577803567120 0 ([41] : List (Fin n))=[(144119291091964168,713042378780311568,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step478
end IU.Trace5
