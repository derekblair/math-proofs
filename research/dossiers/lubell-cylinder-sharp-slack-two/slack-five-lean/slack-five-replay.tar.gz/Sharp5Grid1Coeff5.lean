import Sharp5Grid1Coeff4
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry10 : ∀ i j : Fin 8, vcoeff T U shapeBank[10]! i.val j.val=(data[10]!)[8*i.val+j.val]! := by decide +kernel
theorem entry11 : ∀ i j : Fin 8, vcoeff T U shapeBank[11]! i.val j.val=(data[11]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone1
