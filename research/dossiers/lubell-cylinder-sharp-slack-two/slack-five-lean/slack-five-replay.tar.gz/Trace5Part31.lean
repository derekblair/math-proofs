import Trace5Part30
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step496 : NodeGood bank Hit (333336446139191552,3117898609098489856,0) := by
  apply use_pivot bank Hit sym noLoop 333336446139191552 3117898609098489856 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 333336446139191552 3117898609098489856 0 ([56] : List (Fin n))=[(405394040177119488,3045841015060561920,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step495
theorem step497 : NodeGood bank Hit (297307649120227584,3153927406117453824,0) := by
  apply use_pivot bank Hit sym noLoop 297307649120227584 3153927406117453824 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 297307649120227584 3153927406117453824 0 ([55] : List (Fin n))=[(333336446139191552,3117898609098489856,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step496
theorem step498 : NodeGood bank Hit (288300449865486592,3162934605372194816,0) := by
  apply use_pivot bank Hit sym noLoop 288300449865486592 3162934605372194816 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288300449865486592 3162934605372194816 0 ([53] : List (Fin n))=[(297307649120227584,3153927406117453824,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step497
theorem step499 : NodeGood bank Hit (288265265493397760,3162969789744283648,0) := by
  apply use_pivot bank Hit sym noLoop 288265265493397760 3162969789744283648 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288265265493397760 3162969789744283648 0 ([45] : List (Fin n))=[(288300449865486592,3162934605372194816,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step498
theorem step500 : NodeGood bank Hit (288247673307353344,3162987381930328064,0) := by
  apply use_pivot bank Hit sym noLoop 288247673307353344 3162987381930328064 0 44 [44] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288247673307353344 3162987381930328064 0 ([44] : List (Fin n))=[(288265265493397760,3162969789744283648,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step499
theorem step501 : NodeGood bank Hit (288238877214331136,3162996178023350272,0) := by
  apply use_pivot bank Hit sym noLoop 288238877214331136 3162996178023350272 0 43 [43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288238877214331136 3162996178023350272 0 ([43] : List (Fin n))=[(288247673307353344,3162987381930328064,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step500
theorem step502 : NodeGood bank Hit (288234479167820032,3163000576069861376,0) := by
  apply use_pivot bank Hit sym noLoop 288234479167820032 3163000576069861376 0 42 [42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288234479167820032 3163000576069861376 0 ([42] : List (Fin n))=[(288238877214331136,3162996178023350272,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step501
theorem step503 : NodeGood bank Hit (288232280144564480,3163002775093116928,0) := by
  apply use_pivot bank Hit sym noLoop 288232280144564480 3163002775093116928 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288232280144564480 3163002775093116928 0 ([41] : List (Fin n))=[(288234479167820032,3163000576069861376,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step502
theorem step504 : NodeGood bank Hit (288231180632936704,3163003874604744704,0) := by
  apply use_pivot bank Hit sym noLoop 288231180632936704 3163003874604744704 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288231180632936704 3163003874604744704 0 ([40] : List (Fin n))=[(288232280144564480,3163002775093116928,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step503
theorem step505 : NodeGood bank Hit (288230630877122816,3163004424360558592,0) := by
  apply use_pivot bank Hit sym noLoop 288230630877122816 3163004424360558592 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 288230630877122816 3163004424360558592 0 ([39] : List (Fin n))=[(288231180632936704,3163003874604744704,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step504
theorem step506 : NodeGood bank Hit (2305843263939105024,857161415146864640,288230376151711744) := by
  apply use_pivot bank Hit sym noLoop 2305843263939105024 857161415146864640 288230376151711744 58 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 2305843263939105024 857161415146864640 288230376151711744 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step507 : NodeGood bank Hit (254725411072,3452008856967098075,0) := by
  apply use_pivot bank Hit sym noLoop 254725411072 3452008856967098075 0 3 [3,58,61] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725411072 3452008856967098075 0 ([3,58,61] : List (Fin n))=[(254725411080,857935471601692371,0),(288230630877122816,3163004424360558592,0),(2305843263939105024,857161415146864640,288230376151711744)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h
  · subst C; exact step482
  · subst C; exact step505
  · subst C; exact step506
theorem step508 : NodeGood bank Hit (49258371371758360,0,0) := by
  exact leaf bank Hit 49258371371758360 0 ⟨49258371371758360,by decide +kernel,rfl⟩
theorem step509 : NodeGood bank Hit (48695421418337048,562949953421312,0) := by
  apply use_pivot bank Hit sym noLoop 48695421418337048 562949953421312 0 49 [49] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48695421418337048 562949953421312 0 ([49] : List (Fin n))=[(49258371371758360,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step508
theorem step510 : NodeGood bank Hit (48695421418205976,562949953552384,0) := by
  apply use_pivot bank Hit sym noLoop 48695421418205976 562949953552384 0 17 [17] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48695421418205976 562949953552384 0 ([17] : List (Fin n))=[(48695421418337048,562949953421312,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step509
theorem step511 : NodeGood bank Hit (48695971173987096,0,0) := by
  exact leaf bank Hit 48695971173987096 0 ⟨48695971173987096,by decide +kernel,rfl⟩
end IU.Trace5
