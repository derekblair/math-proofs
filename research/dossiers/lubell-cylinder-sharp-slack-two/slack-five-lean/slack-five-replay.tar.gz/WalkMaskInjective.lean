import WalkMaskBarrier

namespace IU.UniversalCount

theorem maskWalk_get (s m i : Nat) (hi : i<s) :
    (maskWalk s m)[i]'(by simp [hi]) = m.testBit i := by
  simp [maskWalk]

theorem maskWalk_inj {s a b : Nat} (ha : a<2^s) (hb : b<2^s)
    (E : maskWalk s a=maskWalk s b) : a=b := by
  apply Nat.eq_of_testBit_eq
  intro i
  by_cases h : i<s
  · rw [←maskWalk_get s a i h, ←maskWalk_get s b i h]
    exact List.getElem_of_eq E (by simpa using h)
  · have p : 2^s ≤ (2:Nat)^i := Nat.pow_le_pow_right (by decide) (by omega)
    rw [Nat.testBit_lt_two_pow (ha.trans_le p), Nat.testBit_lt_two_pow (hb.trans_le p)]

#print axioms maskWalk_inj
end IU.UniversalCount
