import Sharp5Grid1Data
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry0 : ∀ i j : Fin 8, vcoeff T U shapeBank[0]! i.val j.val=(data[0]!)[8*i.val+j.val]! := by decide +kernel
theorem entry1 : ∀ i j : Fin 8, vcoeff T U shapeBank[1]! i.val j.val=(data[1]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone1
