import Sharp5Grid1Compare17
import Sharp5HistPart20
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot72 : ∀ i j : Fin 8, dot data histograms[72]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare72 : ∀ i j : Fin 8, sumTable data 136523864767287768 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts72, hist_sound data _ _ counts6] <;> exact dot72 i j
theorem dot73 : ∀ i j : Fin 8, dot data histograms[73]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare73 : ∀ i j : Fin 8, sumTable data 136532660860309848 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts73, hist_sound data _ _ counts6] <;> exact dot73 i j
theorem dot74 : ∀ i j : Fin 8, dot data histograms[74]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare74 : ∀ i j : Fin 8, sumTable data 136598631557976408 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts74, hist_sound data _ _ counts6] <;> exact dot74 i j
theorem dot75 : ∀ i j : Fin 8, dot data histograms[75]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare75 : ∀ i j : Fin 8, sumTable data 136730572953310168 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts75, hist_sound data _ _ counts6] <;> exact dot75 i j
end IU.Sharp5.Cone1
