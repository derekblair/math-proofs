import Sharp5Grid0Compare20
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot84 : ∀ i j : Fin 8, dot data histograms[84]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare84 : ∀ i j : Fin 8, sumTable data 621848314464261448 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts84, hist_sound data _ _ counts6] <;> exact dot84 i j
theorem dot85 : ∀ i j : Fin 8, dot data histograms[85]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare85 : ∀ i j : Fin 8, sumTable data 693624708403384648 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts85, hist_sound data _ _ counts6] <;> exact dot85 i j
theorem dot86 : ∀ i j : Fin 8, dot data histograms[86]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare86 : ∀ i j : Fin 8, sumTable data 693905908502188360 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts86, hist_sound data _ _ counts6] <;> exact dot86 i j
theorem dot87 : ∀ i j : Fin 8, dot data histograms[87]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare87 : ∀ i j : Fin 8, sumTable data 695031791229161800 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts87, hist_sound data _ _ counts6] <;> exact dot87 i j
end IU.Sharp5.Cone0
