import DenseEnum
import UniversalGraph
import Mathlib.Tactic.FinCases
namespace IU.DenseCert
open IU.Universal
set_option maxHeartbeats 0
set_option maxRecDepth 18000

def coords4 : List Vertex := [
  (0,0,0),(0,0,1),(0,0,2),(0,1,1),(0,1,2),(0,2,1),(0,2,2),(0,3,2),
  (0,3,3),(0,4,1),(0,4,2),(0,5,2),(0,6,2),(0,7,3),(0,8,1),(0,8,2),
  (0,9,2),(0,10,2),(0,11,3),(0,12,2),(0,13,3),(0,14,3),(0,15,4),(1,3,1),
  (1,3,2),(1,7,2),(1,11,2),(1,13,2),(1,14,2),(1,15,3),(2,15,2)]

theorem coords4_len : (coords4).length=31 := by decide

theorem coords4_eq : vertexList 4=coords4 := by decide +kernel

def orig4 (j : Fin 31) : Vertex := (coords4).get (Fin.cast coords4_len.symm j)

theorem row4_0 : ∀ j : Fin 31, edge bank4 0 j ↔ (0≠j ∧ compat 4 (orig4 0) (orig4 j)=true) := by decide +kernel
theorem row4_1 : ∀ j : Fin 31, edge bank4 1 j ↔ (1≠j ∧ compat 4 (orig4 1) (orig4 j)=true) := by decide +kernel
theorem row4_2 : ∀ j : Fin 31, edge bank4 2 j ↔ (2≠j ∧ compat 4 (orig4 2) (orig4 j)=true) := by decide +kernel
theorem row4_3 : ∀ j : Fin 31, edge bank4 3 j ↔ (3≠j ∧ compat 4 (orig4 3) (orig4 j)=true) := by decide +kernel
theorem row4_4 : ∀ j : Fin 31, edge bank4 4 j ↔ (4≠j ∧ compat 4 (orig4 4) (orig4 j)=true) := by decide +kernel
theorem row4_5 : ∀ j : Fin 31, edge bank4 5 j ↔ (5≠j ∧ compat 4 (orig4 5) (orig4 j)=true) := by decide +kernel
theorem row4_6 : ∀ j : Fin 31, edge bank4 6 j ↔ (6≠j ∧ compat 4 (orig4 6) (orig4 j)=true) := by decide +kernel
theorem row4_7 : ∀ j : Fin 31, edge bank4 7 j ↔ (7≠j ∧ compat 4 (orig4 7) (orig4 j)=true) := by decide +kernel
theorem row4_8 : ∀ j : Fin 31, edge bank4 8 j ↔ (8≠j ∧ compat 4 (orig4 8) (orig4 j)=true) := by decide +kernel
theorem row4_9 : ∀ j : Fin 31, edge bank4 9 j ↔ (9≠j ∧ compat 4 (orig4 9) (orig4 j)=true) := by decide +kernel
theorem row4_10 : ∀ j : Fin 31, edge bank4 10 j ↔ (10≠j ∧ compat 4 (orig4 10) (orig4 j)=true) := by decide +kernel
theorem row4_11 : ∀ j : Fin 31, edge bank4 11 j ↔ (11≠j ∧ compat 4 (orig4 11) (orig4 j)=true) := by decide +kernel
theorem row4_12 : ∀ j : Fin 31, edge bank4 12 j ↔ (12≠j ∧ compat 4 (orig4 12) (orig4 j)=true) := by decide +kernel
theorem row4_13 : ∀ j : Fin 31, edge bank4 13 j ↔ (13≠j ∧ compat 4 (orig4 13) (orig4 j)=true) := by decide +kernel
theorem row4_14 : ∀ j : Fin 31, edge bank4 14 j ↔ (14≠j ∧ compat 4 (orig4 14) (orig4 j)=true) := by decide +kernel
theorem row4_15 : ∀ j : Fin 31, edge bank4 15 j ↔ (15≠j ∧ compat 4 (orig4 15) (orig4 j)=true) := by decide +kernel
theorem row4_16 : ∀ j : Fin 31, edge bank4 16 j ↔ (16≠j ∧ compat 4 (orig4 16) (orig4 j)=true) := by decide +kernel
theorem row4_17 : ∀ j : Fin 31, edge bank4 17 j ↔ (17≠j ∧ compat 4 (orig4 17) (orig4 j)=true) := by decide +kernel
theorem row4_18 : ∀ j : Fin 31, edge bank4 18 j ↔ (18≠j ∧ compat 4 (orig4 18) (orig4 j)=true) := by decide +kernel
theorem row4_19 : ∀ j : Fin 31, edge bank4 19 j ↔ (19≠j ∧ compat 4 (orig4 19) (orig4 j)=true) := by decide +kernel
theorem row4_20 : ∀ j : Fin 31, edge bank4 20 j ↔ (20≠j ∧ compat 4 (orig4 20) (orig4 j)=true) := by decide +kernel
theorem row4_21 : ∀ j : Fin 31, edge bank4 21 j ↔ (21≠j ∧ compat 4 (orig4 21) (orig4 j)=true) := by decide +kernel
theorem row4_22 : ∀ j : Fin 31, edge bank4 22 j ↔ (22≠j ∧ compat 4 (orig4 22) (orig4 j)=true) := by decide +kernel
theorem row4_23 : ∀ j : Fin 31, edge bank4 23 j ↔ (23≠j ∧ compat 4 (orig4 23) (orig4 j)=true) := by decide +kernel
theorem row4_24 : ∀ j : Fin 31, edge bank4 24 j ↔ (24≠j ∧ compat 4 (orig4 24) (orig4 j)=true) := by decide +kernel
theorem row4_25 : ∀ j : Fin 31, edge bank4 25 j ↔ (25≠j ∧ compat 4 (orig4 25) (orig4 j)=true) := by decide +kernel
theorem row4_26 : ∀ j : Fin 31, edge bank4 26 j ↔ (26≠j ∧ compat 4 (orig4 26) (orig4 j)=true) := by decide +kernel
theorem row4_27 : ∀ j : Fin 31, edge bank4 27 j ↔ (27≠j ∧ compat 4 (orig4 27) (orig4 j)=true) := by decide +kernel
theorem row4_28 : ∀ j : Fin 31, edge bank4 28 j ↔ (28≠j ∧ compat 4 (orig4 28) (orig4 j)=true) := by decide +kernel
theorem row4_29 : ∀ j : Fin 31, edge bank4 29 j ↔ (29≠j ∧ compat 4 (orig4 29) (orig4 j)=true) := by decide +kernel
theorem row4_30 : ∀ j : Fin 31, edge bank4 30 j ↔ (30≠j ∧ compat 4 (orig4 30) (orig4 j)=true) := by decide +kernel

theorem dense4_edge (i j : Fin 31) : edge bank4 i j ↔ (i≠j ∧ compat 4 (orig4 i) (orig4 j)=true) := by
  fin_cases i
  · exact row4_0 j
  · exact row4_1 j
  · exact row4_2 j
  · exact row4_3 j
  · exact row4_4 j
  · exact row4_5 j
  · exact row4_6 j
  · exact row4_7 j
  · exact row4_8 j
  · exact row4_9 j
  · exact row4_10 j
  · exact row4_11 j
  · exact row4_12 j
  · exact row4_13 j
  · exact row4_14 j
  · exact row4_15 j
  · exact row4_16 j
  · exact row4_17 j
  · exact row4_18 j
  · exact row4_19 j
  · exact row4_20 j
  · exact row4_21 j
  · exact row4_22 j
  · exact row4_23 j
  · exact row4_24 j
  · exact row4_25 j
  · exact row4_26 j
  · exact row4_27 j
  · exact row4_28 j
  · exact row4_29 j
  · exact row4_30 j

#print axioms dense4_edge
end IU.DenseCert
