import BitSemantics
namespace IU.BitCert
open Finset

abbrev St := ℕ × ℕ × ℕ

def ofSt (n : Nat) (S : St) : BK.State (Fin n) :=
  (members n S.1,members n S.2.1,members n S.2.2)

def childBank (bank : Array Nat) (R P X : Nat) {n : Nat} :
    List (Fin n) → List St
  | [] => []
  | v::vs =>
    let one := 1 <<< v.val
    ((R ||| one),P &&& bank[v.val]!,X &&& bank[v.val]!) ::
      childBank bank R (P ^^^ (P &&& one)) (X ||| one) vs

theorem childBank_map (bank : Array Nat) {n : Nat}
    (R P X : Nat) (vs : List (Fin n)) :
    (childBank bank R P X vs).map (ofSt n) =
     BK.build (IU.DenseCert.edge bank) (members n R) (members n P) (members n X) vs := by
  induction vs generalizing P X with
  | nil => rfl
  | cons v vs ih =>
    simp only [childBank,ofSt,BK.build,List.map_cons]
    have eq := ih (P ^^^ (P &&& (1 <<< v.val))) (X ||| (1 <<< v.val))
    rw [members_add,members_neighbors,members_neighbors,eq,members_clear,members_add]

def NodeGood (bank : Array Nat) {n : Nat} (H : Finset (Fin n) → Prop) (S : St) : Prop :=
  ∀ Q : Finset (Fin n), BK.MaxClique (IU.DenseCert.edge bank) Q →
    BK.Covers Q (members n S.1) (members n S.2.1) (members n S.2.2) → H Q

theorem leaf (bank : Array Nat) {n : Nat} (H : Finset (Fin n) → Prop)
    (R X : Nat) (h : H (members n R)) : NodeGood bank H (R,0,X) := by
  intro Q _ cv
  have eq : Q=members n R := Subset.antisymm (by simpa [members_zero] using cv.2.1) cv.1
  rwa [eq]

theorem use_pivot (bank : Array Nat) {n : Nat} (H : Finset (Fin n) → Prop)
    (sym : Symmetric (IU.DenseCert.edge bank (n:=n)))
    (nr : ∀ i : Fin n, ¬ IU.DenseCert.edge bank i i)
    (R P X : Nat) (pivot : Fin n) (vs : List (Fin n))
    (vR : ∀ w∈members n R, IU.DenseCert.edge bank pivot w)
    (hs : ∀ w∈members n P, ¬ IU.DenseCert.edge bank pivot w → w∈vs)
    (tail : ∀ C∈childBank bank R P X vs, NodeGood bank H C) :
    NodeGood bank H (R,P,X) := by
  intro Q mq cov
  obtain ⟨v,vq,vp,vn⟩ := BK.pivot_branch sym nr mq cov.2.1 vR
  obtain ⟨C,cm,cc⟩ := BK.build_cover _ mq.1 cov vs ⟨v,hs _ vp vn,vq⟩
  rw [←childBank_map] at cm
  obtain ⟨M,mm,e⟩ := List.mem_map.mp cm
  subst C
  exact tail _ mm _ mq cc

#print axioms childBank_map
#print axioms use_pivot
end IU.BitCert
