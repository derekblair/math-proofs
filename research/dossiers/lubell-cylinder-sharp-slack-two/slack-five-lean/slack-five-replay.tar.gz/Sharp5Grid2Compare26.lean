import Sharp5Grid2Compare25
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot104 : ∀ i j : Fin 8, dot data histograms[104]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare104 : ∀ i j : Fin 8, sumTable data 4592897263349616896 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts104, hist_sound data _ _ counts61] <;> exact dot104 i j
end IU.Sharp5.Cone2
