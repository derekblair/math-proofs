import DenseEnum
import Init.Data.Nat.Bitwise.Lemmas
namespace IU.BitCert
open Finset

def members (n bits : ℕ) : Finset (Fin n) := univ.filter (fun j => bits.testBit j.val)

theorem mem_members {n bits : Nat} {j : Fin n} : j∈members n bits ↔ bits.testBit j.val=true := by
  simp [members]

theorem members_zero (n : Nat) : members n 0=∅ := by
  ext a
  simp [mem_members]

theorem members_full (n : Nat) : members n (2^n-1)=univ := by
  ext a
  simp [mem_members,a.isLt]

theorem members_add {n : Nat} (P : Nat) (a : Fin n) :
    members n (P ||| (1<<<a.val))=insert a (members n P) := by
  ext b
  rw [mem_members,Nat.testBit_or, mem_insert,mem_members]
  simp only [Nat.shiftLeft_eq, one_mul,Nat.testBit_two_pow,Bool.or_eq_true,
    decide_eq_true_eq]
  rw [or_comm,Fin.ext_iff]
  exact or_congr_left eq_comm

theorem members_and (n P Q : Nat) :
    members n (P &&& Q)=members n P ∩ members n Q := by
  ext b
  simp [mem_members]

theorem members_clear {n : Nat} (P : Nat) (a : Fin n) :
    members n (P ^^^ (P &&& (1<<<a.val)))=(members n P).erase a := by
  ext b
  rw [mem_members,Nat.testBit_xor,Nat.testBit_and,mem_erase,mem_members]
  by_cases ft : a=b
  · subst b
    simp [Nat.shiftLeft_eq,Nat.testBit_two_pow_self]
  · have ne : a.val≠b.val := fun q => ft (Fin.ext q)
    simp [Nat.shiftLeft_eq,Nat.testBit_two_pow_of_ne ne,Ne.symm ft]

theorem members_neighbors (n : Nat) (bank : Array Nat) (P : Nat) (v : Fin n) :
    members n (P &&& bank[v.val]!)=(members n P).filter (IU.DenseCert.edge bank v) := by
  ext b
  simp [IU.DenseCert.edge,mem_members]

#print axioms members_add
#print axioms members_clear
end IU.BitCert
