import Sharp5Grid0Compare4
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot20 : ∀ i j : Fin 8, dot data histograms[20]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare20 : ∀ i j : Fin 8, sumTable data 70366057026889 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts20, hist_sound data _ _ counts6] <;> exact dot20 i j
theorem dot21 : ∀ i j : Fin 8, dot data histograms[21]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare21 : ∀ i j : Fin 8, sumTable data 282092444418040 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts21, hist_sound data _ _ counts6] <;> exact dot21 i j
theorem dot22 : ∀ i j : Fin 8, dot data histograms[22]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare22 : ∀ i j : Fin 8, sumTable data 1407975171388408 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts22, hist_sound data _ _ counts6] <;> exact dot22 i j
theorem dot23 : ∀ i j : Fin 8, dot data histograms[23]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare23 : ∀ i j : Fin 8, sumTable data 3659770690106168 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts23, hist_sound data _ _ counts6] <;> exact dot23 i j
end IU.Sharp5.Cone0
