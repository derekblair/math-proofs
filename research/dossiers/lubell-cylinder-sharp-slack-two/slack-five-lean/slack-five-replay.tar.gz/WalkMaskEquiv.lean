import WalkMaskInjective

namespace IU.UniversalCount

def encodeWalk : List Bool → Nat
  | [] => 0
  | q::w => 2*(encodeWalk w) + q.toNat

theorem encodeWalk_lt (w : List Bool) : encodeWalk w < 2^w.length := by
  induction w with
  | nil => decide
  | cons q w ih =>
      rw [List.length_cons, pow_succ]
      cases q <;> simp only [encodeWalk,Bool.toNat_false,Bool.toNat_true] <;> omega

theorem maskWalk_encode (w : List Bool) : maskWalk w.length (encodeWalk w)=w := by
  induction w with
  | nil => rfl
  | cons q w ih =>
      have hq : q.toNat < 2^1 := by cases q <;> decide
      have hbit (j : Nat) :
          (encodeWalk (q::w)).testBit j =
            if j<1 then q.toNat.testBit j else (encodeWalk w).testBit (j-1) := by
        exact Nat.testBit_two_pow_mul_add (i:=1) (encodeWalk w) hq j
      have hzero : (encodeWalk (q::w)).testBit 0 = q := by
        rw [hbit,if_pos (by decide : 0<1)]
        cases q <;> decide
      have hsucc (i : Nat) :
          (encodeWalk (q::w)).testBit (i+1) = (encodeWalk w).testBit i := by
        rw [hbit,if_neg (by omega)]
        rfl
      rw [List.length_cons]
      unfold maskWalk at ih ⊢
      rw [List.range_succ_eq_map,List.map_cons,hzero,List.map_map]
      congr 1
      calc
        _ = (List.range w.length).map (encodeWalk w).testBit :=
          List.map_congr_left fun i _ => hsucc i
        _ = w := ih

def maskWalkEquiv (s : Nat) : Fin (2^s) ≃ { w : List Bool // w.length=s } where
  toFun m := ⟨maskWalk s m,maskWalk_length s m⟩
  invFun w := ⟨encodeWalk w.val, by simpa only [w.property] using encodeWalk_lt w.val⟩
  left_inv m := by
    apply Fin.ext
    apply maskWalk_inj (s:=s) (a:=encodeWalk (maskWalk s m)) (b:=m) 
    · simpa only [maskWalk_length] using encodeWalk_lt (maskWalk s m)
    · exact m.isLt
    · have e := maskWalk_encode (maskWalk s m)
      rwa [maskWalk_length] at e
  right_inv w := by
    apply Subtype.ext
    have e := maskWalk_encode w.val
    rwa [w.property] at e

#print axioms maskWalkEquiv
end IU.UniversalCount
