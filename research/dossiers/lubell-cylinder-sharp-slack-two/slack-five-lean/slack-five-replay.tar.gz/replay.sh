#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
: "${MATHLIB_DIR:?Set path to built pinned Mathlib.}"
lib=$(cd "$MATHLIB_DIR" && pwd)
lean=${LEAN_BIN:-lean}
[[ $(git -C "$lib" rev-parse HEAD) == d13f23b723b8a846827a245b89c10fc7d3f11612 ]]
"$lean" --version | grep -F 'version 4.34.1'
(cd "$here" && sha256sum -c SHA256SUMS)
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
libbuild="$lib/.lake/build/lib/lean"
export LEAN_PATH="$out:$libbuild:$(find "$lib/.lake/packages" -type d -path '*/.lake/build/lib/lean' | paste -sd ':' -)"
if [[ ! -f "$libbuild/Mathlib/Algebra/Group/ForwardDiff.olean" ]]; then
  cp -as "$libbuild/Mathlib" "$out/Mathlib"
  mkdir -p "$out/Mathlib/Algebra/Group"
  "$lean" -j1 -M3350 --root="$lib" -o "$out/Mathlib/Algebra/Group/ForwardDiff.olean" \
    "$lib/Mathlib/Algebra/Group/ForwardDiff.lean"
fi
while read -r n; do
  if [[ ${GATE_MIB:-0} -gt 0 ]]; then
    until (( $(awk '/^MemAvailable:/{print $2}' /proc/meminfo) >= GATE_MIB*1024 )); do sleep 5; done
  fi
  echo "CHECK $n"
  "$lean" -j1 -M"${MAX_MIB:-3350}" --root="$here" -o "$out/$n.olean" "$here/$n.lean"
done < "$here/proof-order.txt"
