import Sharp5Grid1Coeff3
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem entry8 : ∀ i j : Fin 8, vcoeff T U shapeBank[8]! i.val j.val=(data[8]!)[8*i.val+j.val]! := by decide +kernel
theorem entry9 : ∀ i j : Fin 8, vcoeff T U shapeBank[9]! i.val j.val=(data[9]!)[8*i.val+j.val]! := by decide +kernel
end IU.Sharp5.Cone1
