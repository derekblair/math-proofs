import Sharp5Grid1Compare19
import Sharp5HistPart20
namespace IU.Sharp5.Cone1
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot80 : ∀ i j : Fin 8, dot data histograms[80]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare80 : ∀ i j : Fin 8, sumTable data 280647848936165656 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts80, hist_sound data _ _ counts6] <;> exact dot80 i j
theorem dot81 : ∀ i j : Fin 8, dot data histograms[81]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare81 : ∀ i j : Fin 8, sumTable data 576531118360450376 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts81, hist_sound data _ _ counts6] <;> exact dot81 i j
theorem dot82 : ∀ i j : Fin 8, dot data histograms[82]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare82 : ∀ i j : Fin 8, sumTable data 585538317346755912 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts82, hist_sound data _ _ counts6] <;> exact dot82 i j
theorem dot83 : ∀ i j : Fin 8, dot data histograms[83]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare83 : ∀ i j : Fin 8, sumTable data 621567114365457736 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts83, hist_sound data _ _ counts6] <;> exact dot83 i j
end IU.Sharp5.Cone1
