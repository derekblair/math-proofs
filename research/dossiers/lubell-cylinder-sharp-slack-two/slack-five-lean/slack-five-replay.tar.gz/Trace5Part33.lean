import Trace5Part32
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step528 : NodeGood bank Hit (192810609494020376,72061442328625152,13194139533312) := by
  apply use_pivot bank Hit sym noLoop 192810609494020376 72061442328625152 13194139533312 42 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 192810609494020376 72061442328625152 13194139533312 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step529 : NodeGood bank Hit (48695421418164504,216752774497608192,0) := by
  apply use_pivot bank Hit sym noLoop 48695421418164504 216752774497608192 0 9 [9,42,43,57] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48695421418164504 216752774497608192 0 ([9,42,43,57] : List (Fin n))=[(48695421418165016,72624392282218496,0),(48699819464675608,216185426497503232,0),(48704217511186712,216176630404481024,4398046511104),(192810609494020376,72061442328625152,13194139533312)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step519
  · subst C; exact step526
  · subst C; exact step527
  · subst C; exact step528
theorem step530 : NodeGood bank Hit (841398774823735560,0,0) := by
  exact leaf bank Hit 841398774823735560 0 ⟨841398774823735560,by decide +kernel,rfl⟩
theorem step531 : NodeGood bank Hit (264938022520312072,576460752303423488,0) := by
  apply use_pivot bank Hit sym noLoop 264938022520312072 576460752303423488 0 59 [59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 264938022520312072 576460752303423488 0 ([59] : List (Fin n))=[(841398774823735560,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step530
theorem step532 : NodeGood bank Hit (120822834444456200,720575940379279360,0) := by
  apply use_pivot bank Hit sym noLoop 120822834444456200 720575940379279360 0 57 [57] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 120822834444456200 720575940379279360 0 ([57] : List (Fin n))=[(264938022520312072,576460752303423488,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step531
theorem step533 : NodeGood bank Hit (48765240406528264,792633534417207296,0) := by
  apply use_pivot bank Hit sym noLoop 48765240406528264 792633534417207296 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48765240406528264 792633534417207296 0 ([56] : List (Fin n))=[(120822834444456200,720575940379279360,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step532
theorem step534 : NodeGood bank Hit (48730056034439432,792668718789296128,0) := by
  apply use_pivot bank Hit sym noLoop 48730056034439432 792668718789296128 0 45 [45] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48730056034439432 792668718789296128 0 ([45] : List (Fin n))=[(48765240406528264,792633534417207296,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step533
theorem step535 : NodeGood bank Hit (48721259941417224,792677514882318336,0) := by
  apply use_pivot bank Hit sym noLoop 48721259941417224 792677514882318336 0 43 [43] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48721259941417224 792677514882318336 0 ([43] : List (Fin n))=[(48730056034439432,792668718789296128,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step534
theorem step536 : NodeGood bank Hit (48716861894906120,792681912928829440,0) := by
  apply use_pivot bank Hit sym noLoop 48716861894906120 792681912928829440 0 42 [42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48716861894906120 792681912928829440 0 ([42] : List (Fin n))=[(48721259941417224,792677514882318336,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step535
theorem step537 : NodeGood bank Hit (48714662871650568,792684111952084992,0) := by
  apply use_pivot bank Hit sym noLoop 48714662871650568 792684111952084992 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48714662871650568 792684111952084992 0 ([41] : List (Fin n))=[(48716861894906120,792681912928829440,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step536
theorem step538 : NodeGood bank Hit (48713563360022792,792685211463712768,0) := by
  apply use_pivot bank Hit sym noLoop 48713563360022792 792685211463712768 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48713563360022792 792685211463712768 0 ([40] : List (Fin n))=[(48714662871650568,792684111952084992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step537
theorem step539 : NodeGood bank Hit (48713013604208904,792685761219526656,0) := by
  apply use_pivot bank Hit sym noLoop 48713013604208904 792685761219526656 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48713013604208904 792685761219526656 0 ([39] : List (Fin n))=[(48713563360022792,792685211463712768,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step538
theorem step540 : NodeGood bank Hit (48730605790253320,792650576847437824,17592186044416) := by
  apply use_pivot bank Hit sym noLoop 48730605790253320 792650576847437824 17592186044416 44 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48730605790253320 792650576847437824 17592186044416 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step541 : NodeGood bank Hit (625156173721587976,216189824544014336,52776558133248) := by
  apply use_pivot bank Hit sym noLoop 625156173721587976 216189824544014336 52776558133248 44 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 625156173721587976 216189824544014336 52776558133248 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step542 : NodeGood bank Hit (48695421418164488,793266303359164944,0) := by
  apply use_pivot bank Hit sym noLoop 48695421418164488 793266303359164944 0 4 [4,44,45,59] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 48695421418164488 793266303359164944 0 ([4,44,45,59] : List (Fin n))=[(48695421418164504,216752774497608192,0),(48713013604208904,792685761219526656,0),(48730605790253320,792650576847437824,17592186044416),(625156173721587976,216189824544014336,52776558133248)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step529
  · subst C; exact step539
  · subst C; exact step540
  · subst C; exact step541
theorem step543 : NodeGood bank Hit (3435472160189141248,0,0) := by
  exact leaf bank Hit 3435472160189141248 0 ⟨3435472160189141248,by decide +kernel,rfl⟩
end IU.Trace5
