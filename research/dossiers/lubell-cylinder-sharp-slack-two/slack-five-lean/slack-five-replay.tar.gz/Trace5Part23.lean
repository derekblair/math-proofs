import Trace5Part22
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step368 : NodeGood bank Hit (28446269803417944,108086391056891904,0) := by
  apply use_pivot bank Hit sym noLoop 28446269803417944 108086391056891904 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 28446269803417944 108086391056891904 0 ([55] : List (Fin n))=[(64475066822381912,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step367
theorem step369 : NodeGood bank Hit (19439070548676952,117093590311632896,0) := by
  apply use_pivot bank Hit sym noLoop 19439070548676952 117093590311632896 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 19439070548676952 117093590311632896 0 ([53] : List (Fin n))=[(28446269803417944,108086391056891904,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step368
theorem step370 : NodeGood bank Hit (18313170641834328,118219490218475520,0) := by
  apply use_pivot bank Hit sym noLoop 18313170641834328 118219490218475520 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18313170641834328 118219490218475520 0 ([50] : List (Fin n))=[(19439070548676952,117093590311632896,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step369
theorem step371 : NodeGood bank Hit (18031695665123672,118500965195186176,0) := by
  apply use_pivot bank Hit sym noLoop 18031695665123672 118500965195186176 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18031695665123672 118500965195186176 0 ([48] : List (Fin n))=[(18313170641834328,118219490218475520,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step370
theorem step372 : NodeGood bank Hit (17297155641688,136515656047920131,0) := by
  apply use_pivot bank Hit sym noLoop 17297155641688 136515656047920131 0 24 [24,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17297155641688 136515656047920131 0 ([24,54] : List (Fin n))=[(17297172418904,118501257521660931,0),(18031695665123672,118500965195186176,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step365
  · subst C; exact step371
theorem step373 : NodeGood bank Hit (136598631557976408,0,0) := by
  exact leaf bank Hit 136598631557976408 0 ⟨136598631557976408,by decide +kernel,rfl⟩
theorem step374 : NodeGood bank Hit (64541037520048472,72057594037927936,0) := by
  apply use_pivot bank Hit sym noLoop 64541037520048472 72057594037927936 0 56 [56] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 64541037520048472 72057594037927936 0 ([56] : List (Fin n))=[(136598631557976408,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step373
theorem step375 : NodeGood bank Hit (28512240501084504,108086391056891904,0) := by
  apply use_pivot bank Hit sym noLoop 28512240501084504 108086391056891904 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 28512240501084504 108086391056891904 0 ([55] : List (Fin n))=[(64541037520048472,72057594037927936,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step374
theorem step376 : NodeGood bank Hit (10497841991602520,126100789566373888,0) := by
  apply use_pivot bank Hit sym noLoop 10497841991602520 126100789566373888 0 54 [54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10497841991602520 126100789566373888 0 ([54] : List (Fin n))=[(28512240501084504,108086391056891904,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step375
theorem step377 : NodeGood bank Hit (1490642736861528,135107988821114880,0) := by
  apply use_pivot bank Hit sym noLoop 1490642736861528 135107988821114880 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1490642736861528 135107988821114880 0 ([53] : List (Fin n))=[(10497841991602520,126100789566373888,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step376
theorem step378 : NodeGood bank Hit (364742830018904,136233888727957504,0) := by
  apply use_pivot bank Hit sym noLoop 364742830018904 136233888727957504 0 50 [50] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 364742830018904 136233888727957504 0 ([50] : List (Fin n))=[(1490642736861528,135107988821114880,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step377
theorem step379 : NodeGood bank Hit (83267853308248,136515363704668160,0) := by
  apply use_pivot bank Hit sym noLoop 83267853308248 136515363704668160 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 83267853308248 136515363704668160 0 ([48] : List (Fin n))=[(364742830018904,136233888727957504,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step378
theorem step380 : NodeGood bank Hit (12899109130584,136590422838608899,0) := by
  apply use_pivot bank Hit sym noLoop 12899109130584 136590422838608899 0 42 [42,46] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 12899109130584 136590422838608899 0 ([42,46] : List (Fin n))=[(17297155641688,136515656047920131,0),(83267853308248,136515363704668160,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step372
  · subst C; exact step379
theorem step381 : NodeGood bank Hit (10700085875032,136592621861864451,0) := by
  apply use_pivot bank Hit sym noLoop 10700085875032 136592621861864451 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 10700085875032 136592621861864451 0 ([41] : List (Fin n))=[(12899109130584,136590422838608899,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step380
theorem step382 : NodeGood bank Hit (9600574247256,136593721373492227,0) := by
  apply use_pivot bank Hit sym noLoop 9600574247256 136593721373492227 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9600574247256 136593721373492227 0 ([40] : List (Fin n))=[(10700085875032,136592621861864451,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step381
theorem step383 : NodeGood bank Hit (9050818433368,136594271129306115,0) := by
  apply use_pivot bank Hit sym noLoop 9050818433368 136594271129306115 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9050818433368 136594271129306115 0 ([39] : List (Fin n))=[(9600574247256,136593721373492227,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step382
end IU.Trace5
