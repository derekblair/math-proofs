import WalkVertexArithmetic
import UniversalGraph

namespace IU.UniversalCount
open IU.Universal

def maskWalk (s m : Nat) := (List.range s).map m.testBit

@[simp] theorem maskWalk_length (s m : Nat) : (maskWalk s m).length=s := by
  simp [maskWalk]

theorem bits_succ (k m : Nat) :
    bits m (k+1)=bits m k+(if m.testBit k then 1 else 0) := by
  unfold bits
  rw [List.range_succ,List.filter_append,List.length_append]
  cases h : m.testBit k <;> simp [h]

theorem height_maskWalk (s m : Nat) :
    height (maskWalk s m)=2*(bits m s:ℤ)-s := by
  induction s with
  | zero => simp [maskWalk,height,bits]
  | succ s ih =>
    have a : maskWalk (s+1) m = maskWalk s m ++ [m.testBit s] := by
      simp [maskWalk,List.range_succ]
    rw [a,height_append,ih,bits_succ]
    cases h : m.testBit s <;> simp [h,height,step] <;> omega

theorem partial_maskWalk (s m k : Nat) (h : k≤s) :
    partialHeight (maskWalk s m) k=2*(bits m k:ℤ)-k := by
  have E : (maskWalk s m).take k=maskWalk k m := by
    simp [maskWalk,← List.map_take,List.take_range,Nat.min_eq_left h]
  rw [partialHeight,E,height_maskWalk]

#print axioms partial_maskWalk
end IU.UniversalCount
