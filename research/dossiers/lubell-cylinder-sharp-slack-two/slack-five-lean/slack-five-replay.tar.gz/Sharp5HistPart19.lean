import Sharp5HistPart18
namespace IU.Sharp5
open Finset IU.BitCert
set_option maxHeartbeats 0
set_option maxRecDepth 35000
theorem counts95 : ∀ q : Fin 20, ((members n 1170092071159165696).filter (fun v => code v=q)).card=(histograms[95]!)[q.val]! := by decide +kernel
theorem counts96 : ∀ q : Fin 20, ((members n 1206121074334462720).filter (fun v => code v=q)).card=(histograms[96]!)[q.val]! := by decide +kernel
theorem counts97 : ∀ q : Fin 20, ((members n 1206683474532233984).filter (fun v => code v=q)).card=(histograms[97]!)[q.val]! := by decide +kernel
theorem counts98 : ∀ q : Fin 20, ((members n 1278181966907265792).filter (fun v => code v=q)).card=(histograms[98]!)[q.val]! := by decide +kernel
theorem counts99 : ∀ q : Fin 20, ((members n 3431813281844646144).filter (fun v => code v=q)).card=(histograms[99]!)[q.val]! := by decide +kernel
end IU.Sharp5
