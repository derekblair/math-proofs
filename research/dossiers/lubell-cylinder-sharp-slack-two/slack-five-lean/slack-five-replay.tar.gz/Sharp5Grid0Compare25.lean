import Sharp5Grid0Compare24
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot100 : ∀ i j : Fin 8, dot data histograms[100]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare100 : ∀ i j : Fin 8, sumTable data 3432094481943449856 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts100, hist_sound data _ _ counts6] <;> exact dot100 i j
theorem dot101 : ∀ i j : Fin 8, dot data histograms[101]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare101 : ∀ i j : Fin 8, sumTable data 3433220364670423296 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts101, hist_sound data _ _ counts6] <;> exact dot101 i j
theorem dot102 : ∀ i j : Fin 8, dot data histograms[102]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare102 : ∀ i j : Fin 8, sumTable data 3435472160189141248 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts102, hist_sound data _ _ counts6] <;> exact dot102 i j
theorem dot103 : ∀ i j : Fin 8, dot data histograms[103]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare103 : ∀ i j : Fin 8, sumTable data 3451234763163128064 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts103, hist_sound data _ _ counts6] <;> exact dot103 i j
end IU.Sharp5.Cone0
