import Trace5Part8
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step144 : NodeGood bank Hit (9008708128169944,549755813888,0) := by
  apply use_pivot bank Hit sym noLoop 9008708128169944 549755813888 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9008708128169944 549755813888 0 ([39] : List (Fin n))=[(9009257883983832,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step143
theorem step145 : NodeGood bank Hit (9007608616542168,1649267482624,0) := by
  apply use_pivot bank Hit sym noLoop 9007608616542168 1649267482624 0 13 [13,40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9007608616542168 1649267482624 0 ([13,40] : List (Fin n))=[(9007608616550360,549755846656,0),(9008708128169944,549755813888,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step142
  · subst C; exact step144
theorem step146 : NodeGood bank Hit (9013655930494424,0,0) := by
  exact leaf bank Hit 9013655930494424 0 ⟨9013655930494424,by decide +kernel,rfl⟩
theorem step147 : NodeGood bank Hit (9012556418866648,1099511627776,0) := by
  apply use_pivot bank Hit sym noLoop 9012556418866648 1099511627776 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9012556418866648 1099511627776 0 ([40] : List (Fin n))=[(9013655930494424,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step146
theorem step148 : NodeGood bank Hit (9012006663052760,1649267441664,0) := by
  apply use_pivot bank Hit sym noLoop 9012006663052760 1649267441664 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9012006663052760 1649267441664 0 ([39] : List (Fin n))=[(9012556418866648,1099511627776,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step147
theorem step149 : NodeGood bank Hit (9007608616541656,6047313994240,0) := by
  apply use_pivot bank Hit sym noLoop 9007608616541656 6047313994240 0 9 [9,42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9007608616541656 6047313994240 0 ([9,42] : List (Fin n))=[(9007608616542168,1649267482624,0),(9012006663052760,1649267441664,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step145
  · subst C; exact step148
theorem step150 : NodeGood bank Hit (409361800664,9013246837170691,0) := by
  apply use_pivot bank Hit sym noLoop 409361800664 9013246837170691 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 409361800664 9013246837170691 0 ([0,53] : List (Fin n))=[(409361800665,6047582429698,0),(9007608616541656,6047313994240,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step139
  · subst C; exact step149
theorem step151 : NodeGood bank Hit (134483893720,9013521715077635,0) := by
  apply use_pivot bank Hit sym noLoop 134483893720 9013521715077635 0 38 [38] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 134483893720 9013521715077635 0 ([38] : List (Fin n))=[(409361800664,9013246837170691,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step150
theorem step152 : NodeGood bank Hit (117304024536,9013538894946819,0) := by
  apply use_pivot bank Hit sym noLoop 117304024536 9013538894946819 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 117304024536 9013538894946819 0 ([34] : List (Fin n))=[(134483893720,9013521715077635,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step151
theorem step153 : NodeGood bank Hit (113009057240,9013543189914115,0) := by
  apply use_pivot bank Hit sym noLoop 113009057240 9013543189914115 0 32 [32] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 113009057240 9013543189914115 0 ([32] : List (Fin n))=[(117304024536,9013538894946819,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step152
theorem step154 : NodeGood bank Hit (111935315416,9013544263655939,0) := by
  apply use_pivot bank Hit sym noLoop 111935315416 9013544263655939 0 30 [30] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111935315416 9013544263655939 0 ([30] : List (Fin n))=[(113009057240,9013543189914115,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step153
theorem step155 : NodeGood bank Hit (111918538200,9013544280433155,0) := by
  apply use_pivot bank Hit sym noLoop 111918538200 9013544280433155 0 24 [24] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918538200 9013544280433155 0 ([24] : List (Fin n))=[(111935315416,9013544263655939,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step154
theorem step156 : NodeGood bank Hit (111918276056,9013544280695299,0) := by
  apply use_pivot bank Hit sym noLoop 111918276056 9013544280695299 0 18 [18] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918276056 9013544280695299 0 ([18] : List (Fin n))=[(111918538200,9013544280433155,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step155
theorem step157 : NodeGood bank Hit (111918274008,9013544280697347,0) := by
  apply use_pivot bank Hit sym noLoop 111918274008 9013544280697347 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918274008 9013544280697347 0 ([11] : List (Fin n))=[(111918276056,9013544280695299,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step156
theorem step158 : NodeGood bank Hit (111918272984,9013544280698371,0) := by
  apply use_pivot bank Hit sym noLoop 111918272984 9013544280698371 0 10 [10] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918272984 9013544280698371 0 ([10] : List (Fin n))=[(111918274008,9013544280697347,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step157
theorem step159 : NodeGood bank Hit (111918272856,9013544280698499,0) := by
  apply use_pivot bank Hit sym noLoop 111918272856 9013544280698499 0 7 [7] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918272856 9013544280698499 0 ([7] : List (Fin n))=[(111918272984,9013544280698371,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step158
end IU.Trace5
