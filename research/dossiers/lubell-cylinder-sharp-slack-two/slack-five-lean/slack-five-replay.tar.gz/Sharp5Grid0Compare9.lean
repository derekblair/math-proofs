import Sharp5Grid0Compare8
import Sharp5HistPart20
namespace IU.Sharp5.Cone0
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot36 : ∀ i j : Fin 8, dot data histograms[36]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare36 : ∀ i j : Fin 8, sumTable data 9024788485199192 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts36, hist_sound data _ _ counts6] <;> exact dot36 i j
theorem dot37 : ∀ i j : Fin 8, dot data histograms[37]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare37 : ∀ i j : Fin 8, sumTable data 9289289753001944 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts37, hist_sound data _ _ counts6] <;> exact dot37 i j
theorem dot38 : ∀ i j : Fin 8, dot data histograms[38]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare38 : ∀ i j : Fin 8, sumTable data 10415172479972312 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts38, hist_sound data _ _ counts6] <;> exact dot38 i j
theorem dot39 : ∀ i j : Fin 8, dot data histograms[39]! i.val j.val ≤ dot data histograms[6]! i.val j.val := by decide +kernel
theorem compare39 : ∀ i j : Fin 8, sumTable data 12666967998690072 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts39, hist_sound data _ _ counts6] <;> exact dot39 i j
end IU.Sharp5.Cone0
