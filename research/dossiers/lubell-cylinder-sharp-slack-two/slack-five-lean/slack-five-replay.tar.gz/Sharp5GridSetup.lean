import DenseWeight
import Trace5Part38

namespace IU.Sharp5
open Finset IU.Slack IU.Universal IU.PolyCert IU.DenseCert IU.BitCert
open scoped BigOperators
set_option maxHeartbeats 0
set_option maxRecDepth 30000

abbrev n := 62
abbrev d := 7
def shapeBank : Array Shape := #[⟨5,0,0,0⟩,⟨5,0,0,1⟩,⟨5,0,0,2⟩,⟨5,0,0,3⟩,⟨5,0,0,4⟩,⟨5,0,0,5⟩,⟨5,0,1,1⟩,⟨5,0,1,2⟩,⟨5,0,1,3⟩,⟨5,0,1,4⟩,⟨5,0,2,2⟩,⟨5,0,2,3⟩,⟨5,1,0,1⟩,⟨5,1,0,2⟩,⟨5,1,0,3⟩,⟨5,1,0,4⟩,⟨5,1,1,2⟩,⟨5,1,1,3⟩,⟨5,2,0,2⟩,⟨5,2,0,3⟩]
def codes : Array Nat := #[0,6,10,1,7,11,1,7,2,8,1,7,2,8,2,8,3,9,1,7,2,8,2,3,2,3,3,4,1,7,2,8,2,3,2,3,3,4,2,3,3,4,3,4,4,5,12,16,13,17,13,13,13,14,13,14,14,14,14,15,18,19]
def shapes (v : Fin n) : Shape := shapeOf 5 (orig5 v)
theorem shape_lookup (v : Fin n) : shapes v=shapeBank[codes[v.val]!]! := by
  fin_cases v <;> rfl
theorem vertex_degree : ∀ v : Fin n, bound (shapes v)≤d := by decide +kernel

abbrev lowMask := 893151707135
abbrev productMask := 65232080578278360
def readTable (tbl : Array (Array Int)) (v : Fin n) (i j : Nat) : Int :=
  (tbl[codes[v.val]!]!)[8*i+j]!
def sumTable (tbl : Array (Array Int)) (R : Nat) (i j : Nat) : Int :=
  ∑ v∈members n R, readTable tbl v i j

end IU.Sharp5
