import Trace5Part2
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step48 : NodeGood bank Hit (598190683101,292880649218,0) := by
  apply use_pivot bank Hit sym noLoop 598190683101 292880649218 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598190683101 292880649218 0 ([1] : List (Fin n))=[(598190683103,292880649216,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step47
theorem step49 : NodeGood bank Hit (598190683100,292880649219,0) := by
  apply use_pivot bank Hit sym noLoop 598190683100 292880649219 0 0 [0] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598190683100 292880649219 0 ([0] : List (Fin n))=[(598190683101,292880649218,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step48
theorem step50 : NodeGood bank Hit (890668679131,0,0) := by
  exact leaf bank Hit 890668679131 0 ⟨890668679131,by decide +kernel,rfl⟩
theorem step51 : NodeGood bank Hit (890400243675,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 890400243675 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 890400243675 268435456 0 ([28] : List (Fin n))=[(890668679131,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step50
theorem step52 : NodeGood bank Hit (890400243673,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 890400243673 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 890400243673 268435458 0 ([1] : List (Fin n))=[(890400243675,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step51
theorem step53 : NodeGood bank Hit (9008089654984664,0,0) := by
  exact leaf bank Hit 9008089654984664 0 ⟨9008089654984664,by decide +kernel,rfl⟩
theorem step54 : NodeGood bank Hit (890400243672,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 890400243672 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 890400243672 9007199523176451 0 ([0,53] : List (Fin n))=[(890400243673,268435458,0),(9008089654984664,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step52
  · subst C; exact step53
theorem step55 : NodeGood bank Hit (615522336728,9007474401083395,0) := by
  apply use_pivot bank Hit sym noLoop 615522336728 9007474401083395 0 38 [38] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 615522336728 9007474401083395 0 ([38] : List (Fin n))=[(890400243672,9007199523176451,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step54
theorem step56 : NodeGood bank Hit (615521812440,9007474401607683,0) := by
  apply use_pivot bank Hit sym noLoop 615521812440 9007474401607683 0 19 [19] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 615521812440 9007474401607683 0 ([19] : List (Fin n))=[(615522336728,9007474401083395,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step55
theorem step57 : NodeGood bank Hit (9289289753001944,0,0) := by
  exact leaf bank Hit 9289289753001944 0 ⟨9289289753001944,by decide +kernel,rfl⟩
theorem step58 : NodeGood bank Hit (282090498260952,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 282090498260952 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 282090498260952 9007199254740992 0 ([53] : List (Fin n))=[(9289289753001944,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step57
theorem step59 : NodeGood bank Hit (615521550296,9288949378580483,0) := by
  apply use_pivot bank Hit sym noLoop 615521550296 9288949378580483 0 18 [18,48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 615521550296 9288949378580483 0 ([18,48] : List (Fin n))=[(615521812440,9007474401607683,0),(282090498260952,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step56
  · subst C; exact step58
theorem step60 : NodeGood bank Hit (598341681112,9288966558449667,0) := by
  apply use_pivot bank Hit sym noLoop 598341681112 9288966558449667 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598341681112 9288966558449667 0 ([34] : List (Fin n))=[(615521550296,9288949378580483,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step59
theorem step61 : NodeGood bank Hit (598341679064,9288966558451715,0) := by
  apply use_pivot bank Hit sym noLoop 598341679064 9288966558451715 0 11 [11] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 598341679064 9288966558451715 0 ([11] : List (Fin n))=[(598341681112,9288966558449667,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step60
theorem step62 : NodeGood bank Hit (10415172479972312,0,0) := by
  exact leaf bank Hit 10415172479972312 0 ⟨10415172479972312,by decide +kernel,rfl⟩
theorem step63 : NodeGood bank Hit (1407973225231320,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 1407973225231320 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 1407973225231320 9007199254740992 0 ([53] : List (Fin n))=[(10415172479972312,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step62
end IU.Trace5
