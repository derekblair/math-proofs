import Trace5Part20
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step336 : NodeGood bank Hit (18022899572101592,118500965195186176,0) := by
  apply use_pivot bank Hit sym noLoop 18022899572101592 118500965195186176 0 48 [48] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18022899572101592 118500965195186176 0 ([48] : List (Fin n))=[(18304374548812248,118219490218475520,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step335
theorem step337 : NodeGood bank Hit (18020700548846040,118503164218441728,0) := by
  apply use_pivot bank Hit sym noLoop 18020700548846040 118503164218441728 0 41 [41] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 18020700548846040 118503164218441728 0 ([41] : List (Fin n))=[(18022899572101592,118500965195186176,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step336
theorem step338 : NodeGood bank Hit (6302039364056,136517855071177731,0) := by
  apply use_pivot bank Hit sym noLoop 6302039364056 136517855071177731 0 24 [24,54] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 6302039364056 136517855071177731 0 ([24,54] : List (Fin n))=[(6302056141272,118503456544918531,0),(18020700548846040,118503164218441728,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step330
  · subst C; exact step337
theorem step339 : NodeGood bank Hit (5202527736280,136518954582805507,0) := by
  apply use_pivot bank Hit sym noLoop 5202527736280 136518954582805507 0 40 [40] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 5202527736280 136518954582805507 0 ([40] : List (Fin n))=[(6302039364056,136517855071177731,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step338
theorem step340 : NodeGood bank Hit (4652771922392,136519504338619395,0) := by
  apply use_pivot bank Hit sym noLoop 4652771922392 136519504338619395 0 39 [39] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 4652771922392 136519504338619395 0 ([39] : List (Fin n))=[(5202527736280,136518954582805507,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step339
theorem step341 : NodeGood bank Hit (254725411288,137297958571257347,0) := by
  apply use_pivot bank Hit sym noLoop 254725411288 137297958571257347 0 9 [9,42] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254725411288 137297958571257347 0 ([9,42] : List (Fin n))=[(254725411800,137293560524745731,0),(4652771922392,136519504338619395,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step291
  · subst C; exact step340
theorem step342 : NodeGood bank Hit (17589498893659,0,0) := by
  exact leaf bank Hit 17589498893659 0 ⟨17589498893659,by decide +kernel,rfl⟩
theorem step343 : NodeGood bank Hit (17589230458203,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 17589230458203 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17589230458203 268435456 0 ([28] : List (Fin n))=[(17589498893659,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step342
theorem step344 : NodeGood bank Hit (17589230458201,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 17589230458201 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17589230458201 268435458 0 ([1] : List (Fin n))=[(17589230458203,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step343
theorem step345 : NodeGood bank Hit (9024788485199192,0,0) := by
  exact leaf bank Hit 9024788485199192 0 ⟨9024788485199192,by decide +kernel,rfl⟩
theorem step346 : NodeGood bank Hit (17589230458200,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 17589230458200 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17589230458200 9007199523176451 0 ([0,53] : List (Fin n))=[(17589230458201,268435458,0),(9024788485199192,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step344
  · subst C; exact step345
theorem step347 : NodeGood bank Hit (45053585503901016,0,0) := by
  exact leaf bank Hit 45053585503901016 0 ⟨45053585503901016,by decide +kernel,rfl⟩
theorem step348 : NodeGood bank Hit (36046386249160024,9007199254740992,0) := by
  apply use_pivot bank Hit sym noLoop 36046386249160024 9007199254740992 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36046386249160024 9007199254740992 0 ([53] : List (Fin n))=[(45053585503901016,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step347
theorem step349 : NodeGood bank Hit (17589230196056,45035996542402563,0) := by
  apply use_pivot bank Hit sym noLoop 17589230196056 45035996542402563 0 18 [18,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 17589230196056 45035996542402563 0 ([18,55] : List (Fin n))=[(17589230458200,9007199523176451,0),(36046386249160024,9007199254740992,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step346
  · subst C; exact step348
theorem step350 : NodeGood bank Hit (45334785602704728,0,0) := by
  exact leaf bank Hit 45334785602704728 0 ⟨45334785602704728,by decide +kernel,rfl⟩
theorem step351 : NodeGood bank Hit (9305988583740760,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 9305988583740760 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9305988583740760 36028797018963968 0 ([55] : List (Fin n))=[(45334785602704728,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step350
end IU.Trace5
