import NewtonGrid
import Mathlib.RingTheory.Polynomial.Pochhammer
import Mathlib.Tactic.Ring

namespace IU.PolyCert
open Polynomial Finset
open scoped BigOperators

abbrev Bi := (ℚ[X])[X]

noncomputable def aff (o x y : ℕ) : Bi :=
  C (C (o:ℚ) + C (y:ℚ) * X) + C (C (x:ℚ)) * X

theorem aff_eval (o x y a b : ℕ) :
    ((aff o x y).eval (a:ℚ[X])).eval (b:ℚ) = ((o+x*a+y*b:ℕ):ℚ) := by
  simp [aff]
  push_cast
  ring

theorem aff_degree (o x y : ℕ) : (aff o x y).natDegree≤1 := by
  exact (natDegree_add_le _ _).trans (by
    simp only [natDegree_C,max_le_iff,zero_le, true_and]
    exact (natDegree_C_mul_le _ _).trans (le_of_eq natDegree_X))

theorem aff_eval_degree (o x y a : ℕ) :
    ((aff o x y).eval (a:ℚ[X])).natDegree≤1 := by
  simp only [aff,eval_add,eval_C,eval_mul,eval_X]
  refine (natDegree_add_le _ _).trans (max_le ?_ ?_)
  · exact (natDegree_add_le _ _).trans (max_le (by simp) ((natDegree_C_mul_le _ _).trans (by simp)))
  · exact (natDegree_C_mul_le _ _).trans (by simp)

noncomputable def fall (P : Bi) (k : ℕ) : Bi :=
  C (C (((k.factorial:ℚ))⁻¹)) * (descPochhammer (ℚ[X]) k).comp P

noncomputable def rise (P : Bi) (k : ℕ) : Bi :=
  (ascPochhammer (ℚ[X]) k).comp (P+1)

theorem fall_eval (P : Bi) (k a b n : ℕ)
    (h : (P.eval (a:ℚ[X])).eval (b:ℚ) = (n:ℚ)) :
    ((fall P k).eval (a:ℚ[X])).eval (b:ℚ) = (n.choose k:ℚ) := by
  simp only [fall,eval_mul,eval_C,eval_comp]
  have m := (eval_map_apply (f:=evalRingHom (b:ℚ))
    (p:=descPochhammer (ℚ[X]) k) (P.eval (a:ℚ[X])))
  change ((descPochhammer (ℚ[X]) k).map (evalRingHom (b:ℚ))).eval
     ((P.eval (a:ℚ[X])).eval (b:ℚ)) = _ at m
  rw [descPochhammer_map,h] at m
  change (descPochhammer ℚ k).eval (n:ℚ) =
    ((descPochhammer (ℚ[X]) k).eval (P.eval (a:ℚ[X]))).eval (b:ℚ) at m
  rw [←m,Nat.cast_choose_eq_descPochhammer_div,div_eq_mul_inv,mul_comm]

theorem rise_eval (P : Bi) (k a b n : ℕ)
    (h : (P.eval (a:ℚ[X])).eval (b:ℚ) = (n:ℚ)) :
    ((rise P k).eval (a:ℚ[X])).eval (b:ℚ) =
      ((n+1).ascFactorial k:ℚ) := by
  simp only [rise,eval_comp,eval_add,eval_one]
  have m := (eval_map_apply (f:=evalRingHom (b:ℚ))
    (p:=ascPochhammer (ℚ[X]) k) (P.eval (a:ℚ[X])+1))
  change ((ascPochhammer (ℚ[X]) k).map (evalRingHom (b:ℚ))).eval
      ((P.eval (a:ℚ[X])+1).eval (b:ℚ)) = _ at m
  rw [ascPochhammer_map,eval_add,eval_one,h,←Nat.cast_one,←Nat.cast_add,←Nat.cast_ascFactorial] at m
  exact m.symm

theorem fall_degree (P : Bi) (k : ℕ) (h : P.natDegree≤1) :
    (fall P k).natDegree≤k := by
  unfold fall
  refine (natDegree_C_mul_le _ _).trans (natDegree_comp_le.trans ?_)
  rw [descPochhammer_natDegree]
  simpa using Nat.mul_le_mul_left k h

theorem rise_degree (P : Bi) (k : ℕ) (h : P.natDegree≤1) :
    (rise P k).natDegree≤k := by
  unfold rise
  apply natDegree_comp_le.trans
  rw [ascPochhammer_natDegree]
  have hj : (P+1).natDegree≤1 := (natDegree_add_le _ _).trans (by simp [h])
  simpa using Nat.mul_le_mul_left k hj

theorem cast_eval_fall_deg (P : Bi) (k a : ℕ) (h : (P.eval (a:ℚ[X])).natDegree≤1) :
    ((fall P k).eval (a:ℚ[X])).natDegree≤k := by
  simp only [fall,eval_mul,eval_C,eval_comp]
  -- Evaluation of a composed polynomial is by ordinary ring algebra;
  -- swap polynomial variables explicitly below in the follow-up module.
  exact (natDegree_C_mul_le _ _).trans (by
    have aux : (descPochhammer (ℚ[X]) k).eval (P.eval (a:ℚ[X])) =
        (descPochhammer ℚ k).comp (P.eval (a:ℚ[X])) := by
      rw [← descPochhammer_map (C : ℚ →+* ℚ[X]),eval_map]
      rfl
    rw [aux]
    refine natDegree_comp_le.trans ?_
    rw [descPochhammer_natDegree]
    simpa using Nat.mul_le_mul_left k h)

#print axioms fall_eval
#print axioms rise_eval
end IU.PolyCert
