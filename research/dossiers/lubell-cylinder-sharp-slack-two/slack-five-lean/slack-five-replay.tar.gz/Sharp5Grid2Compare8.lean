import Sharp5Grid2Compare7
import Sharp5HistPart20
namespace IU.Sharp5.Cone2
open Finset IU.Slack IU.PolyCert IU.BitCert
open scoped BigOperators
set_option maxRecDepth 35000
set_option maxHeartbeats 0
theorem dot32 : ∀ i j : Fin 8, dot data histograms[32]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare32 : ∀ i j : Fin 8, sumTable data 9011594345666520 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts32, hist_sound data _ _ counts61] <;> exact dot32 i j
theorem dot33 : ∀ i j : Fin 8, dot data histograms[33]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare33 : ∀ i j : Fin 8, sumTable data 9013655930494424 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts33, hist_sound data _ _ counts61] <;> exact dot33 i j
theorem dot34 : ∀ i j : Fin 8, dot data histograms[34]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare34 : ∀ i j : Fin 8, sumTable data 9013793368923608 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts34, hist_sound data _ _ counts61] <;> exact dot34 i j
theorem dot35 : ∀ i j : Fin 8, dot data histograms[35]! i.val j.val ≤ dot data histograms[61]! i.val j.val := by decide +kernel
theorem compare35 : ∀ i j : Fin 8, sumTable data 9015992392177112 i.val j.val ≤ sumTable data bestMask i.val j.val := by
  intro i j
  rw [hist_sound data _ _ counts35, hist_sound data _ _ counts61] <;> exact dot35 i j
end IU.Sharp5.Cone2
