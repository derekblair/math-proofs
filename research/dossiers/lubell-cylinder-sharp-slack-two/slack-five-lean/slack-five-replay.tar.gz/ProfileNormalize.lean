import UniversalGraph
import Compact
import Encode

namespace IU.Slack
open Finset
open IU.Universal

def shiftMiddle (M : Bag) (t : Nat) : Bag := M.image (· - t)
def small (t s : Nat) (x : Q) : Vertex :=
  (t-x.1,mask (shiftMiddle x.2.1 t) s,full x-t)

theorem shift_range {M : Bag} {t s : Nat} (h : M⊆mid t s) :
    shiftMiddle M t ⊆ range s := by
  intro k hk
  obtain ⟨x,xm,rfl⟩ := mem_image.mp hk
  obtain ⟨a,b⟩ := mem_sdiff.mp (h xm)
  have ax := mem_range.mp a
  have bx : t≤x := Nat.le_of_not_gt (fun z => b (mem_range.mpr z))
  exact mem_range.mpr (by omega)

theorem shift_card {M : Bag} {t s : Nat} (h : M⊆mid t s) (i : Nat) :
    (below (shiftMiddle M t) i).card = (M.filter (·<t+i)).card := by
  have E : below (shiftMiddle M t) i = (M.filter (·<t+i)).image (· - t) := by
    ext k
    constructor
    · intro h'
      obtain ⟨hx,kv⟩ := mem_filter.mp h'
      obtain ⟨x,xm,rfl⟩ := mem_image.mp hx
      exact mem_image.mpr ⟨x,mem_filter.mpr ⟨xm,by omega⟩,rfl⟩
    · intro h'
      obtain ⟨x,xm,rfl⟩ := mem_image.mp h'
      obtain ⟨a,b⟩ := mem_filter.mp xm
      have c := (mem_sdiff.mp (h a)).2
      have v : t≤x := Nat.le_of_not_gt (fun p => c (mem_range.mpr p))
      exact mem_filter.mpr ⟨mem_image.mpr ⟨x,a,rfl⟩,by omega⟩
  rw [E,card_image_of_injOn]
  intro x hx y hy e
  have xx := (mem_sdiff.mp (h (mem_filter.mp hx).1)).2
  have yy := (mem_sdiff.mp (h (mem_filter.mp hy).1)).2
  have xt : t≤x := Nat.le_of_not_gt (fun p => xx (mem_range.mpr p))
  have yt : t≤y := Nat.le_of_not_gt (fun p => yy (mem_range.mpr p))
  change x-t=y-t at e
  omega

theorem center_bits {M : Bag} {t s i : Nat} (h : M⊆mid t s) (hi : i≤s) :
    Universal.bits (mask (shiftMiddle M t) s) i = (M.filter (·<t+i)).card := by
  change rank (mask (shiftMiddle M t) s) i = _
  rw [rank_mask _ hi]
  exact shift_card h i

theorem compat_small {x y : Q} {t u s : Nat}
    (X : Admissible t u s x) (Y : Admissible t u s y) :
    compat s (small t s x) (small t s y)=true ↔ Qcompat t s x y := by
  unfold compat Qcompat
  simp only [List.any_eq_true,List.mem_range,decide_eq_true_eq]
  constructor
  · rintro ⟨i,hi,h⟩
    simp only [small] at h
    have hi' : i≤s := by omega
    rw [center_bits X.1 hi',center_bits Y.1 hi'] at h
    exact ⟨i,by omega,h⟩
  · rintro ⟨i,hi,h⟩
    refine ⟨i,by omega,?_⟩
    simp only [small]
    rw [center_bits X.1 hi,center_bits Y.1 hi]
    exact h

theorem small_in_vertices {x : Q} {t u s : Nat}
    (h : Admissible t u s x) (self : Qcompat t s x x) :
    small t s x ∈ vertexList s := by
  have B := mass_bounds h self
  have lt := mask_lt (shiftMiddle x.2.1 t) s
  have le := h.2.2.2.2
  have center : x.2.1.filter (·<t+s)=x.2.1 := by
    apply filter_true_of_mem
    intro z zz
    exact mem_range.mp (mem_sdiff.mp (h.1 zz)).1
  unfold vertexList
  refine List.mem_filter.mpr ⟨?_,?_⟩
  · apply List.mem_flatMap.mpr
    refine ⟨t-x.1,List.mem_range.mpr (by omega),?_⟩
    apply List.mem_flatMap.mpr
    refine ⟨mask (shiftMiddle x.2.1 t) s,List.mem_range.mpr lt,?_⟩
    exact List.mem_map.mpr ⟨full x-t,List.mem_range.mpr (by omega),rfl⟩
  · apply Bool.and_eq_true_iff.mpr
    refine ⟨decide_eq_true ?_,(compat_small h h).mpr self⟩
    simp only [small]
    rw [center_bits h.1 le_rfl,center]
    have a := h.2.1
    have b := h.2.2.2.1
    unfold full at *
    omega

#print axioms compat_small
#print axioms small_in_vertices
end IU.Slack
