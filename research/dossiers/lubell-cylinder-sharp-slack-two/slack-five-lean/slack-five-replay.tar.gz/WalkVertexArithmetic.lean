import WalkSupport

namespace IU.UniversalCount

/-- Terminal and prefix cardinalities reduce the graph predicate to
an integer walk barrier, using only the natural range of the indices. -/
theorem barrier_iff (s m r j h b : Nat) (terminal : m≤j+r) :
    j+j-s+r+r+h ≤ b+b ↔
      max (2*(r:ℤ)) (2*(m:ℤ)-s+2*((j+r-m:ℕ):ℤ)) ≤ 2*(b:ℤ)-h := by
  rw [Nat.cast_sub terminal,max_le_iff]
  omega

theorem deficits_of_range (s m r j h b : Nat) (hs : h≤s)
    (p : b≤m) (q : h-b≤s-m) (bh : b≤h) (ms : m≤s)
    (terminal : m≤j+r) (cross : j+j-s+r+r+h≤b+b) :
    2*r≤m ∧ m+2*(j+r-m)≤s := by
  have c := (barrier_iff s m r j h b terminal).mp cross
  rw [max_le_iff,Nat.cast_sub terminal] at c
  omega

theorem index_of_deficits (s m r z : Nat) (l : 2*r≤m) (h : m+2*z≤s) :
    r≤s/2 ∧ m-r+z≤s ∧ m ≤ (m-r+z)+r ∧ (m-r+z)+r-m=z := by
  omega

#print axioms barrier_iff
#print axioms deficits_of_range
#print axioms index_of_deficits
end IU.UniversalCount
