import Trace5Part9
namespace IU.Trace5
open IU.BitCert IU.DenseCert Finset
set_option maxRecDepth 22000
set_option maxHeartbeats 0
theorem step160 : NodeGood bank Hit (111918272792,9013544280698563,0) := by
  apply use_pivot bank Hit sym noLoop 111918272792 9013544280698563 0 6 [6] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918272792 9013544280698563 0 ([6] : List (Fin n))=[(111918272856,9013544280698499,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step159
theorem step161 : NodeGood bank Hit (111918272776,9013544280698579,0) := by
  apply use_pivot bank Hit sym noLoop 111918272776 9013544280698579 0 4 [4] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918272776 9013544280698579 0 ([4] : List (Fin n))=[(111918272792,9013544280698563,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step160
theorem step162 : NodeGood bank Hit (111918272768,9013544280698587,0) := by
  apply use_pivot bank Hit sym noLoop 111918272768 9013544280698587 0 3 [3] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 111918272768 9013544280698587 0 ([3] : List (Fin n))=[(111918272776,9013544280698579,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step161
theorem step163 : NodeGood bank Hit (272190930907,0,0) := by
  exact leaf bank Hit 272190930907 0 ⟨272190930907,by decide +kernel,rfl⟩
theorem step164 : NodeGood bank Hit (271922495451,268435456,0) := by
  apply use_pivot bank Hit sym noLoop 271922495451 268435456 0 28 [28] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 271922495451 268435456 0 ([28] : List (Fin n))=[(272190930907,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step163
theorem step165 : NodeGood bank Hit (271922495449,268435458,0) := by
  apply use_pivot bank Hit sym noLoop 271922495449 268435458 0 1 [1] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 271922495449 268435458 0 ([1] : List (Fin n))=[(271922495451,268435456,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step164
theorem step166 : NodeGood bank Hit (9007471177236440,0,0) := by
  exact leaf bank Hit 9007471177236440 0 ⟨9007471177236440,by decide +kernel,rfl⟩
theorem step167 : NodeGood bank Hit (271922495448,9007199523176451,0) := by
  apply use_pivot bank Hit sym noLoop 271922495448 9007199523176451 0 0 [0,53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 271922495448 9007199523176451 0 ([0,53] : List (Fin n))=[(271922495449,268435458,0),(9007471177236440,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h
  · subst C; exact step165
  · subst C; exact step166
theorem step168 : NodeGood bank Hit (45880693126070232,0,0) := by
  exact leaf bank Hit 45880693126070232 0 ⟨45880693126070232,by decide +kernel,rfl⟩
theorem step169 : NodeGood bank Hit (9851896107106264,36028797018963968,0) := by
  apply use_pivot bank Hit sym noLoop 9851896107106264 36028797018963968 0 55 [55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 9851896107106264 36028797018963968 0 ([55] : List (Fin n))=[(45880693126070232,0,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step168
theorem step170 : NodeGood bank Hit (844696852365272,45035996273704960,0) := by
  apply use_pivot bank Hit sym noLoop 844696852365272 45035996273704960 0 53 [53] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 844696852365272 45035996273704960 0 ([53] : List (Fin n))=[(9851896107106264,36028797018963968,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step169
theorem step171 : NodeGood bank Hit (281746898943960,45598946227126272,0) := by
  apply use_pivot bank Hit sym noLoop 281746898943960 45598946227126272 0 49 [49] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 281746898943960 45598946227126272 0 ([49] : List (Fin n))=[(844696852365272,45035996273704960,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step170
theorem step172 : NodeGood bank Hit (563221875654616,45035996273704960,281474976710656) := by
  apply use_pivot bank Hit sym noLoop 563221875654616 45035996273704960 281474976710656 48 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 563221875654616 45035996273704960 281474976710656 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step173 : NodeGood bank Hit (36029068941197272,9007199254740992,844424930131968) := by
  apply use_pivot bank Hit sym noLoop 36029068941197272 9007199254740992 844424930131968 48 [] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 36029068941197272 9007199254740992 844424930131968 ([] : List (Fin n))=[] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
theorem step174 : NodeGood bank Hit (271922233304,45880421472534531,0) := by
  apply use_pivot bank Hit sym noLoop 271922233304 45880421472534531 0 18 [18,48,49,55] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 271922233304 45880421472534531 0 ([18,48,49,55] : List (Fin n))=[(271922495448,9007199523176451,0),(281746898943960,45598946227126272,0),(563221875654616,45035996273704960,281474976710656),(36029068941197272,9007199254740992,844424930131968)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with h|h|h|h
  · subst C; exact step167
  · subst C; exact step171
  · subst C; exact step172
  · subst C; exact step173
theorem step175 : NodeGood bank Hit (254742364120,45880438652403715,0) := by
  apply use_pivot bank Hit sym noLoop 254742364120 45880438652403715 0 34 [34] (by decide +kernel) (by decide +kernel)
  intro C h
  have eq : childBank bank 254742364120 45880438652403715 0 ([34] : List (Fin n))=[(271922233304,45880421472534531,0)] := by decide +kernel
  rw [eq] at h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  subst C; exact step174
end IU.Trace5
